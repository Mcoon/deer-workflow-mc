# iOS UI Map Report

Builds `graph.json`, `page-index.json`, and an interactive `map.html` from
discovered pages, controls, transitions, and an explicit navigation policy.

The JSON graph is the machine source of truth. HTML is a human-facing
projection and embeds the same graph for inspection.
