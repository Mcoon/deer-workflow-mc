import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

import { phase } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  assetLayout,
  buildNavigationGraph,
  buildPageIndex,
  ensureAssetLayout,
  loadControls,
  loadPages,
  readJson,
  writeJsonAtomic,
} from "../ios-regression-kit";

import type {
  NavigationGraph,
  NavigationPolicy,
  NavigationStatus,
  PageIndex,
  UiControl,
  UiTransitionCollection,
} from "../ios-regression-kit/types";
import type { IosUiMapReportInput, IosUiMapReportResult } from "./types";

type UnifiedNodeKind = "page" | "control" | "outcome";
type UnifiedEdgeKind = "contains" | "interaction";
type UnifiedEdgeStatus = NavigationStatus | "unexplored";

interface UnifiedGraphNode {
  readonly id: string;
  readonly kind: UnifiedNodeKind;
  readonly title: string;
  readonly status: UnifiedEdgeStatus;
  readonly pageId?: string;
  readonly controlId?: string;
  readonly role?: string;
  readonly aliases?: readonly string[];
  readonly fingerprint?: string;
  readonly screenshotPath?: string;
  readonly uiDumpPath?: string;
  readonly selector?: UiControl["selector"];
  readonly bindings?: UiControl["bindings"];
  readonly controlIds?: readonly string[];
  readonly anchorControlIds?: readonly string[];
  readonly variants?: Readonly<Record<string, string>>;
}

interface UnifiedGraphEdge {
  readonly id: string;
  readonly kind: UnifiedEdgeKind;
  readonly from: string;
  readonly to: string;
  readonly status: UnifiedEdgeStatus;
  readonly category?: string;
  readonly action?: NavigationGraph["edges"][number]["action"];
  readonly navigationEdgeId?: string;
  readonly candidate?: boolean;
}

export interface UnifiedUiGraph {
  readonly schemaVersion: "ios-ui-unified-graph/v1";
  readonly bundleId: string;
  readonly generatedAt: string;
  readonly rootPageId: string;
  readonly defaultStartPageId: string;
  readonly nodes: readonly UnifiedGraphNode[];
  readonly edges: readonly UnifiedGraphEdge[];
}

export const meta = {
  name: "ios-ui-map-report",
  description:
    "Builds a machine-readable iOS navigation graph, page index, and interactive HTML map.",
  phases: [
    { title: "Load" },
    { title: "Build" },
    { title: "Render" },
    { title: "Report" },
  ],
  exampleArgs: {
    bundleId: "com.bot.doubao",
  },
};

export default async function iosUiMapReport(
  args: IosUiMapReportInput,
): Promise<IosUiMapReportResult> {
  const input = normalizeInput(args);
  const { layout } = await ensureAssetLayout({
    bundleId: input.bundleId,
    assetRoot: input.assetRoot,
  });

  phase("Load");
  const [pages, controlsCollection, transitions, policy] = await Promise.all([
    loadPages(layout.pagesDirectory),
    loadControls(layout.controlsPath),
    readJson<UiTransitionCollection>(layout.transitionsPath),
    readJson<NavigationPolicy>(input.policyPath),
  ]);
  log(
    [
      "## Loading iOS UI navigation assets",
      `- **Bundle:** \`${input.bundleId}\``,
      `- **Pages:** ${pages.length}`,
      `- **Controls:** ${controlsCollection.controls.length}`,
      `- **Transitions:** ${transitions.transitions.length}`,
      `- **Policy:** \`${input.policyPath}\``,
    ].join("\n"),
  );

  phase("Build");
  const graph = buildNavigationGraph({
    bundleId: input.bundleId,
    pages,
    controls: controlsCollection.controls,
    transitions: transitions.transitions,
    policy,
  });
  const pageIndex = buildPageIndex(graph);
  const unifiedGraph = buildUnifiedUiGraph({
    graph,
    controls: controlsCollection.controls,
  });
  await Promise.all([
    writeJsonAtomic(input.graphPath, graph),
    writeJsonAtomic(input.unifiedGraphPath, unifiedGraph),
    writeJsonAtomic(input.pageIndexPath, pageIndex),
  ]);

  phase("Render");
  await mkdir(dirname(input.htmlPath), { recursive: true });
  await writeFile(
    input.htmlPath,
    renderNavigationMapHtml(graph, pageIndex, unifiedGraph),
    "utf8",
  );

  phase("Report");
  const activeEdgeCount = graph.edges.filter(
    (edge) => edge.status === "active",
  ).length;
  log(
    [
      "## iOS UI map ready",
      `- **Graph:** \`${input.graphPath}\``,
      `- **Unified graph:** \`${input.unifiedGraphPath}\``,
      `- **Page index:** \`${input.pageIndexPath}\``,
      `- **HTML:** \`${input.htmlPath}\``,
      `- **Nodes:** ${graph.nodes.length}`,
      `- **Unified nodes:** ${unifiedGraph.nodes.length}`,
      `- **Edges:** ${graph.edges.length} (${activeEdgeCount} active)`,
      `- **Unified edges:** ${unifiedGraph.edges.length}`,
    ].join("\n"),
  );

  return {
    success: true,
    appAssetRoot: layout.appRoot,
    policyPath: input.policyPath,
    graphPath: input.graphPath,
    unifiedGraphPath: input.unifiedGraphPath,
    pageIndexPath: input.pageIndexPath,
    htmlPath: input.htmlPath,
    nodeCount: graph.nodes.length,
    unifiedNodeCount: unifiedGraph.nodes.length,
    edgeCount: graph.edges.length,
    unifiedEdgeCount: unifiedGraph.edges.length,
    activeEdgeCount,
  };
}

interface NormalizedInput {
  bundleId: string;
  assetRoot?: string;
  policyPath: string;
  graphPath: string;
  unifiedGraphPath: string;
  pageIndexPath: string;
  htmlPath: string;
}

function normalizeInput(args: IosUiMapReportInput): NormalizedInput {
  if (!args) {
    throw new TypeError("iOS UI Map Report requires input arguments.");
  }
  const bundleId = requiredText(args.bundleId, "bundleId");
  const layout = assetLayout(bundleId, args.assetRoot);
  return {
    bundleId,
    assetRoot: args.assetRoot?.trim() || undefined,
    policyPath: resolve(args.policyPath?.trim() || layout.navigationPolicyPath),
    graphPath: resolve(args.graphPath?.trim() || layout.graphPath),
    unifiedGraphPath: resolve(
      args.unifiedGraphPath?.trim() ||
        join(dirname(layout.graphPath), "unified-graph.json"),
    ),
    pageIndexPath: resolve(args.pageIndexPath?.trim() || layout.pageIndexPath),
    htmlPath: resolve(args.htmlPath?.trim() || layout.mapHtmlPath),
  };
}

export function buildUnifiedUiGraph(options: {
  graph: NavigationGraph;
  controls: readonly UiControl[];
}): UnifiedUiGraph {
  const controlsById = new Map(
    options.controls.map((control) => [control.controlId, control]),
  );
  const transitionControlIds = new Set(
    options.graph.edges
      .map((edge) =>
        edge.action.type === "tap" ? edge.action.controlId : undefined,
      )
      .filter((controlId): controlId is string => Boolean(controlId)),
  );
  const anchorControlIds = new Set(
    options.graph.nodes.flatMap((node) => node.anchorControlIds),
  );
  const actionableControls = options.controls.filter((control) =>
    isActionableControl(control, {
      anchorControlIds,
      transitionControlIds,
    }),
  );
  const nodes: UnifiedGraphNode[] = [];
  const edges: UnifiedGraphEdge[] = [];

  for (const page of options.graph.nodes) {
    nodes.push({
      id: pageNodeId(page.pageId),
      kind: "page",
      pageId: page.pageId,
      title: page.title,
      status: page.status,
      aliases: page.aliases,
      fingerprint: page.fingerprint,
      screenshotPath: page.screenshotPath,
      uiDumpPath: page.uiDumpPath,
      controlIds: page.controlIds,
      anchorControlIds: page.anchorControlIds,
      variants: page.variants,
    });
  }

  for (const control of actionableControls) {
    const controlNode = controlNodeId(control.controlId);
    nodes.push({
      id: controlNode,
      kind: "control",
      pageId: control.pageId,
      controlId: control.controlId,
      title: control.title || control.controlId,
      role: control.role,
      status: transitionControlIds.has(control.controlId)
        ? "active"
        : "unexplored",
      selector: control.selector,
      bindings: control.bindings,
    });
    edges.push({
      id: `contains:${control.pageId}:${control.controlId}`,
      kind: "contains",
      from: pageNodeId(control.pageId),
      to: controlNode,
      status: "active",
    });
  }

  for (const edge of options.graph.edges) {
    if (edge.action.type !== "tap") {
      edges.push({
        id: `interaction:${edge.edgeId}`,
        kind: "interaction",
        from: pageNodeId(edge.fromPageId),
        to: pageNodeId(edge.toPageId),
        status: edge.status,
        category: edge.category,
        action: edge.action,
        navigationEdgeId: edge.edgeId,
      });
      continue;
    }

    const controlNode = controlNodeId(edge.action.controlId);
    if (!controlsById.has(edge.action.controlId)) {
      continue;
    }
    edges.push({
      id: `interaction:${edge.edgeId}`,
      kind: "interaction",
      from: controlNode,
      to: pageNodeId(edge.toPageId),
      status: edge.status,
      category: edge.category,
      action: edge.action,
      navigationEdgeId: edge.edgeId,
    });
  }

  for (const control of actionableControls) {
    if (transitionControlIds.has(control.controlId)) {
      continue;
    }
    const outcomeId = outcomeNodeId(control.controlId);
    nodes.push({
      id: outcomeId,
      kind: "outcome",
      pageId: control.pageId,
      controlId: control.controlId,
      title: "未探索",
      status: "unexplored",
    });
    edges.push({
      id: `candidate:${control.controlId}`,
      kind: "interaction",
      from: controlNodeId(control.controlId),
      to: outcomeId,
      status: "unexplored",
      category: "candidate",
      action: { type: "tap", controlId: control.controlId },
      candidate: true,
    });
  }

  return {
    schemaVersion: "ios-ui-unified-graph/v1",
    bundleId: options.graph.bundleId,
    generatedAt: options.graph.generatedAt,
    rootPageId: options.graph.rootPageId,
    defaultStartPageId: options.graph.defaultStartPageId,
    nodes: nodes.sort((left, right) => left.id.localeCompare(right.id)),
    edges: edges.sort((left, right) => left.id.localeCompare(right.id)),
  };
}

function isActionableControl(
  control: UiControl,
  context: {
    anchorControlIds: ReadonlySet<string>;
    transitionControlIds: ReadonlySet<string>;
  },
): boolean {
  if (context.transitionControlIds.has(control.controlId)) {
    return true;
  }
  if (context.anchorControlIds.has(control.controlId)) {
    return true;
  }
  if (control.role === "Button") {
    return true;
  }
  if (control.role === "Image") {
    return /(^|[._-])(btn|button|close|camera|album|photo|selection|send|more|mic|voice|attachment)([._-]|$)/iu.test(
      `${control.controlId} ${control.title} ${JSON.stringify(control.selector)}`,
    );
  }
  return false;
}

function pageNodeId(pageId: string): string {
  return `page:${pageId}`;
}

function controlNodeId(controlId: string): string {
  return `control:${controlId}`;
}

function outcomeNodeId(controlId: string): string {
  return `outcome:${controlId}:unexplored`;
}

export function renderNavigationMapHtml(
  graph: NavigationGraph,
  pageIndex: PageIndex,
  unifiedGraph = buildUnifiedUiGraph({ graph, controls: [] }),
): string {
  const graphJson = safeEmbeddedJson(graph);
  const unifiedGraphJson = safeEmbeddedJson(unifiedGraph);
  const pageIndexJson = safeEmbeddedJson(pageIndex);
  return `<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>iOS UI Navigation Map · ${escapeHtml(graph.bundleId)}</title>
<style>
:root{font-family:Inter,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:#17202a;background:#f5f7fa}
*{box-sizing:border-box}body{margin:0;overflow:hidden}.app{height:100vh;display:grid;grid-template-rows:54px 1fr}
header{display:flex;align-items:center;gap:12px;padding:0 16px;background:#fff;border-bottom:1px solid #dfe3e8}
h1{font-size:16px;margin:0;letter-spacing:0}.meta{color:#657180;font-size:12px}
.toolbar{margin-left:auto;display:flex;gap:8px;align-items:center}.toolbar input{width:240px;height:32px;border:1px solid #ccd2d9;border-radius:5px;padding:0 10px}
button{height:32px;border:1px solid #c9d0d8;background:#fff;border-radius:5px;padding:0 10px;cursor:pointer}
.main{display:grid;grid-template-columns:minmax(0,1fr) 340px;min-height:0}.viewport{position:relative;overflow:hidden;background:#eef1f5}
svg{width:100%;height:100%;touch-action:none}.edge{stroke:#9aa5b1;stroke-width:2;fill:none;marker-end:url(#arrow)}.edge.contains{stroke:#cbd5e1;stroke-width:1;stroke-dasharray:3 5;marker-end:none}.edge.active{stroke:#2574d9}.edge.selection{stroke:#8b5cf6}.edge.permission{stroke:#d97706}.edge.mutation{stroke:#c2415d}.edge.unexplored{stroke:#94a3b8;stroke-dasharray:4 5}.edge.stale,.edge.blocked{stroke-dasharray:6 5;opacity:.55}
.node{cursor:pointer}.node rect{fill:#fff;stroke:#bcc5cf;stroke-width:1.5;rx:6;pointer-events:all}.node.page rect{stroke:#2574d9}.node.control rect{fill:#fff;stroke:#94a3b8}.node.outcome rect{fill:#f8fafc;stroke:#cbd5e1;stroke-dasharray:4 4}.node.active rect{stroke:#2574d9}.node.cold rect{fill:#17202a;stroke:#17202a}.node text{font-size:12px;fill:#17202a;pointer-events:none}.node.control text,.node.outcome text{font-size:11px}.node .sub{fill:#64748b;font-size:10px}.node.cold text{fill:#fff}.node.selected rect{stroke:#e11d48;stroke-width:3;stroke-dasharray:none}
.panel{background:#fff;border-left:1px solid #dfe3e8;padding:16px;overflow:auto}.panel h2{font-size:16px;margin:0 0 12px}.panel h3{font-size:13px;margin:18px 0 8px}.muted{color:#697586;font-size:12px}.pill{display:inline-block;padding:3px 7px;margin:2px 4px 2px 0;border:1px solid #d9dee5;border-radius:999px;font-size:11px}
.preview{width:100%;border:1px solid #e1e5ea;border-radius:5px;background:#f6f7f9;min-height:120px;object-fit:contain}.list{margin:0;padding-left:18px;font-size:12px}.list li{margin:6px 0}.kv{display:grid;grid-template-columns:92px 1fr;gap:6px;font-size:12px;margin:6px 0}.path{font-family:ui-monospace,SFMono-Regular,Menlo,monospace;font-size:11px;word-break:break-all}
.legend{display:flex;gap:8px;flex-wrap:wrap;font-size:11px;color:#5e6976}.dot{width:9px;height:9px;display:inline-block;border-radius:2px;margin-right:4px}.navigation-dot{background:#2574d9}.selection-dot{background:#8b5cf6}.permission-dot{background:#d97706}.mutation-dot{background:#c2415d}.candidate-dot{background:#94a3b8}
@media(max-width:760px){.main{grid-template-columns:1fr}.panel{display:none}.toolbar input{width:140px}}
</style>
</head>
<body>
<div class="app">
<header>
  <h1>iOS UI Navigation Map</h1>
  <span class="meta">${escapeHtml(graph.bundleId)} · ${graph.nodes.length} pages · ${unifiedGraph.nodes.length} unified nodes · ${unifiedGraph.edges.length} unified edges</span>
  <div class="legend"><span><i class="dot navigation-dot"></i>navigation</span><span><i class="dot selection-dot"></i>selection</span><span><i class="dot permission-dot"></i>permission</span><span><i class="dot mutation-dot"></i>mutation</span><span><i class="dot candidate-dot"></i>unexplored</span></div>
  <div class="toolbar"><input id="search" placeholder="搜索 pageId / controlId / 标题"><button id="fit">Fit</button></div>
</header>
<div class="main">
  <div class="viewport"><svg id="map" aria-label="iOS UI navigation graph"></svg></div>
  <aside class="panel" id="details"><h2>统一图详情</h2><p class="muted">点击页面或控件查看详情。页面、元素、已验证跳转和未探索候选都在同一张 graph 里。</p></aside>
</div>
</div>
<script type="application/json" id="graph-data">${graphJson}</script>
<script type="application/json" id="unified-graph-data">${unifiedGraphJson}</script>
<script type="application/json" id="page-index-data">${pageIndexJson}</script>
<script>
const graph=JSON.parse(document.getElementById("graph-data").textContent);
const unified=JSON.parse(document.getElementById("unified-graph-data").textContent);
const svg=document.getElementById("map");
const details=document.getElementById("details");
const ns="http://www.w3.org/2000/svg";
const nodeById=new Map(unified.nodes.map(n=>[n.id,n]));
const pageNodes=unified.nodes.filter(n=>n.kind==="page");
const controlNodes=unified.nodes.filter(n=>n.kind==="control");
const outcomeNodes=unified.nodes.filter(n=>n.kind==="outcome");
const edges=unified.edges||[];
const controlsByPage=new Map();
for(const control of controlNodes){if(!controlsByPage.has(control.pageId))controlsByPage.set(control.pageId,[]);controlsByPage.get(control.pageId).push(control)}
const interactionsByFrom=new Map();
for(const edge of edges.filter(e=>e.kind==="interaction")){if(!interactionsByFrom.has(edge.from))interactionsByFrom.set(edge.from,[]);interactionsByFrom.get(edge.from).push(edge)}
const pageW=190,pageH=64,controlW=164,controlH=38,outcomeW=96,outcomeH=32,gapX=330,columnGapY=84,controlGap=44;
const rootNodeId="page:"+unified.rootPageId;
const depths=new Map([[rootNodeId,0]]);
const queue=[rootNodeId];
while(queue.length){
  const current=queue.shift();
  const depth=depths.get(current)||0;
  for(const edge of edges.filter(e=>e.kind==="interaction"&&e.from===current&&nodeById.get(e.to)?.kind==="page")){
    if(!depths.has(edge.to)){depths.set(edge.to,depth+1);queue.push(edge.to)}
  }
  const currentPage=nodeById.get(current);
  const controls=controlsByPage.get(currentPage?.pageId)||[];
  for(const control of controls){
    for(const edge of (interactionsByFrom.get(control.id)||[]).filter(e=>nodeById.get(e.to)?.kind==="page")){
      if(!depths.has(edge.to)){depths.set(edge.to,depth+1);queue.push(edge.to)}
    }
  }
}
for(const page of pageNodes){if(!depths.has(page.id))depths.set(page.id,Math.max(...depths.values())+1)}
const columns=new Map();
for(const page of pageNodes){const depth=depths.get(page.id)||0;if(!columns.has(depth))columns.set(depth,[]);columns.get(depth).push(page)}
const positions=new Map();
for(const [depth,list] of columns){
  let y=40;
  list.sort((a,b)=>String(a.pageId||a.id).localeCompare(String(b.pageId||b.id)));
  for(const page of list){
    const x=40+depth*gapX;
    positions.set(page.id,{x,y,w:pageW,h:pageH});
    const controls=(controlsByPage.get(page.pageId)||[]).sort((a,b)=>controlRank(a)-controlRank(b)||a.id.localeCompare(b.id));
    controls.forEach((control,index)=>positions.set(control.id,{x:x+18,y:y+pageH+26+index*controlGap,w:controlW,h:controlH}));
    y+=Math.max(columnGapY,pageH+26+controls.length*controlGap+54);
  }
}
for(const outcome of outcomeNodes){
  const controlPosition=positions.get("control:"+(outcome.controlId||""));
  if(controlPosition){positions.set(outcome.id,{x:controlPosition.x+controlW+34,y:controlPosition.y+3,w:outcomeW,h:outcomeH})}
}
const allPositions=[...positions.values()];
const width=Math.max(900,...allPositions.map(p=>p.x+p.w))+90;
const height=Math.max(520,...allPositions.map(p=>p.y+p.h))+90;
svg.setAttribute("viewBox","0 0 "+width+" "+height);
const defs=document.createElementNS(ns,"defs");defs.innerHTML='<marker id="arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 z" fill="context-stroke"/></marker>';svg.appendChild(defs);
function controlRank(node){const outgoing=interactionsByFrom.get(node.id)||[];if(outgoing.some(e=>!e.candidate&&e.status==="active"))return 0;if(outgoing.some(e=>!e.candidate))return 1;if(node.role==="Button")return 2;return 3}
function pointRight(p){return{x:p.x+p.w,y:p.y+p.h/2}}
function pointLeft(p){return{x:p.x,y:p.y+p.h/2}}
function pointBottom(p){return{x:p.x+p.w/2,y:p.y+p.h}}
function pointTop(p){return{x:p.x+p.w/2,y:p.y}}
function edgeClass(edge){return["edge",edge.kind,edge.category||"",edge.status||""].join(" ")}
function drawEdge(edge){const from=positions.get(edge.from),to=positions.get(edge.to);if(!from||!to)return;let pathData;if(edge.kind==="contains"){const a=pointBottom(from),b=pointTop(to);pathData="M "+a.x+" "+a.y+" L "+b.x+" "+b.y}else{const a=pointRight(from),b=pointLeft(to);const dx=Math.max(36,(b.x-a.x)/2);pathData="M "+a.x+" "+a.y+" C "+(a.x+dx)+" "+a.y+", "+(b.x-dx)+" "+b.y+", "+b.x+" "+b.y}const path=document.createElementNS(ns,"path");path.setAttribute("d",pathData);path.setAttribute("class",edgeClass(edge));path.dataset.edgeId=edge.id;const title=document.createElementNS(ns,"title");title.textContent=[edge.id,edge.kind,edge.status,edge.category||""].filter(Boolean).join(" · ");path.appendChild(title);svg.appendChild(path)}
for(const edge of edges.filter(e=>e.kind==="contains"))drawEdge(edge);
for(const edge of edges.filter(e=>e.kind==="interaction"))drawEdge(edge);
function drawNode(node){const p=positions.get(node.id);if(!p)return;const group=document.createElementNS(ns,"g");group.setAttribute("class",["node",node.kind,node.status,node.pageId===unified.rootPageId?"cold":""].join(" "));group.setAttribute("transform","translate("+p.x+","+p.y+")");group.dataset.nodeId=node.id;const rect=document.createElementNS(ns,"rect");rect.setAttribute("width",p.w);rect.setAttribute("height",p.h);const title=document.createElementNS(ns,"text");title.setAttribute("x","10");title.setAttribute("y",node.kind==="page"?"24":"16");title.textContent=short(node.title||node.id,node.kind==="page"?22:20);const sub=document.createElementNS(ns,"text");sub.setAttribute("x","10");sub.setAttribute("y",node.kind==="page"?"46":"31");sub.setAttribute("class","sub");sub.textContent=short(node.kind==="control"?(node.controlId||""):node.kind==="outcome"?"candidate":(node.pageId||node.id),node.kind==="page"?24:22);group.append(rect,title,sub);svg.appendChild(group)}
for(const node of [...pageNodes,...controlNodes,...outcomeNodes])drawNode(node);
function selectNode(nodeId){const node=nodeById.get(nodeId);if(!node)return;document.querySelectorAll(".node").forEach(item=>item.classList.toggle("selected",item.dataset.nodeId===nodeId));const incoming=edges.filter(e=>e.to===nodeId);const outgoing=edges.filter(e=>e.from===nodeId);if(node.kind==="page")renderPageDetails(node,incoming,outgoing);else if(node.kind==="control")renderControlDetails(node,incoming,outgoing);else renderOutcomeDetails(node,incoming,outgoing)}
function renderPageDetails(node,incoming,outgoing){const controls=controlsByPage.get(node.pageId)||[];const linked=controls.filter(control=>(interactionsByFrom.get(control.id)||[]).some(edge=>!edge.candidate));const unexplored=controls.filter(control=>(interactionsByFrom.get(control.id)||[]).some(edge=>edge.candidate));details.innerHTML='<h2>'+escape(node.title)+'</h2><div class="kv"><b>type</b><span>page</span><b>pageId</b><span class="path">'+escape(node.pageId||'')+'</span><b>status</b><span>'+escape(node.status)+'</span><b>fingerprint</b><span class="path">'+escape(node.fingerprint||'-')+'</span><b>controls</b><span>'+controls.length+' total · '+linked.length+' linked · '+unexplored.length+' unexplored</span></div>'+(node.screenshotPath?'<h3>Baseline</h3><img class="preview" src="'+toFileUrl(node.screenshotPath)+'">':'')+'<h3>Aliases</h3><div>'+((node.aliases||[]).map(alias=>'<span class="pill">'+escape(alias)+'</span>').join('')||'<span class="muted">none</span>')+'</div><h3>Controls</h3><p class="section-note">控件节点属于同一张统一图；linked 表示已有页面跳转，unexplored 表示可作为下一轮 discovery 候选。</p><ul class="list">'+(controls.slice(0,80).map(control=>'<li><span class="badge">'+(((interactionsByFrom.get(control.id)||[]).some(edge=>edge.candidate))?'unexplored':'linked')+'</span><span class="path">'+escape(control.controlId||control.id)+'</span><br>'+escape(control.title||'')+'</li>').join('')||'<li>none</li>')+'</ul><h3>Outgoing</h3><ul class="list">'+(outgoing.filter(edge=>edge.kind==="interaction").map(edgeLine).join('')||'<li>none</li>')+'</ul><h3>Incoming</h3><ul class="list">'+(incoming.filter(edge=>edge.kind==="interaction").map(edgeLine).join('')||'<li>none</li>')+'</ul>'}
function renderControlDetails(node,incoming,outgoing){void incoming;details.innerHTML='<h2>'+escape(node.title)+'</h2><div class="kv"><b>type</b><span>control</span><b>controlId</b><span class="path">'+escape(node.controlId||'')+'</span><b>pageId</b><span class="path">'+escape(node.pageId||'')+'</span><b>role</b><span>'+escape(node.role||'-')+'</span><b>status</b><span>'+escape(node.status)+'</span><b>selector</b><span class="path">'+escape(JSON.stringify(node.selector||{}))+'</span></div><h3>Interactions</h3><ul class="list">'+(outgoing.map(edgeLine).join('')||'<li>none</li>')+'</ul><h3>Bindings</h3><ul class="list">'+((node.bindings||[]).map(binding=>'<li><span class="path">'+escape(binding.deviceProfileId)+'</span><br>'+escape(JSON.stringify(binding.normalizedPoint||{}))+'</li>').join('')||'<li>none</li>')+'</ul>'}
function renderOutcomeDetails(node,incoming,outgoing){void outgoing;details.innerHTML='<h2>'+escape(node.title)+'</h2><p class="section-note">这个节点代表控件点击结果尚未探索。可以基于它生成下一轮 ios-ui-discovery route。</p><div class="kv"><b>controlId</b><span class="path">'+escape(node.controlId||'')+'</span><b>pageId</b><span class="path">'+escape(node.pageId||'')+'</span></div><h3>Incoming</h3><ul class="list">'+(incoming.map(edgeLine).join('')||'<li>none</li>')+'</ul>'}
function edgeLine(edge){const from=nodeById.get(edge.from),to=nodeById.get(edge.to);return '<li><b>'+escape(edge.category||edge.kind)+'</b> <span class="muted">'+escape(edge.status)+'</span><br><span class="path">'+escape(from?.title||edge.from)+'</span> → <span class="path">'+escape(to?.title||edge.to)+'</span><br><span class="path">'+escape(edge.navigationEdgeId||edge.id)+'</span></li>'}
function escape(value){return String(value).replace(/[&<>"']/g,char=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[char]))}
function short(value,max){const text=String(value||"");return text.length<=max?text:text.slice(0,max-3)+"..."}
function toFileUrl(path){if(location.protocol==="file:")return "file://"+path.split("/").map((segment,index)=>index===0?"":encodeURIComponent(segment)).join("/");const marker="/baselines/";const index=path.indexOf(marker);if(index<0)return "";return "../baselines/"+path.slice(index+marker.length).split("/").map(encodeURIComponent).join("/")}
document.getElementById("search").addEventListener("input",event=>{const query=event.target.value.trim().toLowerCase();for(const element of document.querySelectorAll(".node")){const node=nodeById.get(element.dataset.nodeId);const haystack=[node?.id,node?.pageId,node?.controlId,node?.title,...(node?.aliases||[])].filter(Boolean).join(" ").toLowerCase();element.style.opacity=!query||haystack.includes(query)?"1":".16"}});
let drag=false,lastX=0,lastY=0,startX=0,startY=0,moved=false,view=[0,0,width,height];
function closestNodeElement(target){return target&&target.closest?target.closest(".node"):null}
function nodeAtPoint(x,y){return document.elementFromPoint?closestNodeElement(document.elementFromPoint(x,y)):null}
document.getElementById("fit").addEventListener("click",()=>{view=[0,0,width,height];svg.setAttribute("viewBox",view.join(" "))});
svg.addEventListener("pointerdown",event=>{drag=true;moved=false;startX=event.clientX;startY=event.clientY;lastX=event.clientX;lastY=event.clientY;svg.setPointerCapture?.(event.pointerId)});
svg.addEventListener("pointermove",event=>{if(!drag)return;const distance=Math.hypot(event.clientX-startX,event.clientY-startY);if(distance<4){lastX=event.clientX;lastY=event.clientY;return}moved=true;const scaleX=view[2]/svg.clientWidth,scaleY=view[3]/svg.clientHeight;view[0]-=(event.clientX-lastX)*scaleX;view[1]-=(event.clientY-lastY)*scaleY;lastX=event.clientX;lastY=event.clientY;svg.setAttribute("viewBox",view.join(" "))});
svg.addEventListener("pointerup",event=>{if(!drag)return;drag=false;svg.releasePointerCapture?.(event.pointerId);if(moved)return;const node=nodeAtPoint(event.clientX,event.clientY)||closestNodeElement(event.target);if(node?.dataset?.nodeId)selectNode(node.dataset.nodeId)});
svg.addEventListener("wheel",event=>{event.preventDefault();const factor=event.deltaY>0?1.12:.89;const rect=svg.getBoundingClientRect(),rx=(event.clientX-rect.left)/rect.width,ry=(event.clientY-rect.top)/rect.height;view[0]+=view[2]*rx*(1-factor);view[1]+=view[3]*ry*(1-factor);view[2]*=factor;view[3]*=factor;svg.setAttribute("viewBox",view.join(" "))},{passive:false});
</script>
</body>
</html>`;
}

function safeEmbeddedJson(value: unknown): string {
  return JSON.stringify(value)
    .replaceAll("<", "\\u003c")
    .replaceAll(">", "\\u003e")
    .replaceAll("&", "\\u0026");
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function requiredText(value: string | undefined, name: string): string {
  const trimmed = value?.trim();
  if (!trimmed) {
    throw new TypeError(`iOS UI Map Report requires ${name}.`);
  }
  return trimmed;
}
