# iOS UI Map Report

这个 Workflow 把 UI discovery 的 `pages`、`controls`、`transitions` 和
`navigation-policy.json` 编译为：

- `graph.json`：导航和执行的唯一机器事实源；
- `page-index.json`：供模型做页面名称/别名解析的精简索引；
- `map.html`：供人查看的可缩放、可搜索交互图。

```bash
deer-workflow run \
  /Users/bytedance/Documents/deer-workflow-mc/examples/ios-ui-map-report/workflow.ts \
  --input '{
    "bundleId": "com.bot.doubao",
    "assetRoot": "/Users/bytedance/Documents/BDWorkSpace/ios-perf-optimizer/assets/app-regression"
  }'
```

规划器只消费 policy 中标记为 `active` 的边。原始 transition 没有 policy 时只是
`candidate`，不会被自动执行。
