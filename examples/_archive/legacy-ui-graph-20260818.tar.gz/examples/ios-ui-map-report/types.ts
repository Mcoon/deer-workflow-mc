export interface IosUiMapReportInput {
  readonly bundleId: string;
  readonly assetRoot?: string;
  readonly policyPath?: string;
  readonly graphPath?: string;
  readonly unifiedGraphPath?: string;
  readonly pageIndexPath?: string;
  readonly htmlPath?: string;
}

export interface IosUiMapReportResult {
  readonly success: boolean;
  readonly appAssetRoot: string;
  readonly policyPath: string;
  readonly graphPath: string;
  readonly unifiedGraphPath: string;
  readonly pageIndexPath: string;
  readonly htmlPath: string;
  readonly nodeCount: number;
  readonly unifiedNodeCount: number;
  readonly edgeCount: number;
  readonly unifiedEdgeCount: number;
  readonly activeEdgeCount: number;
}
