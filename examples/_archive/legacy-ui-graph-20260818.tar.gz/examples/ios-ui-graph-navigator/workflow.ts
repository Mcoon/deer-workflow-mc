import { mkdir } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

import { agent } from "@deerwork-ai/deer-workflow/agents";
import type {
  AgentFunction,
  JsonSchema,
} from "@deerwork-ai/deer-workflow/agents";
import { getWorkflowContext, phase } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  DEFAULT_ARTIFACT_ROOT,
  buildMobilecliPreflightCommand,
  writeJsonAtomic,
} from "../ios-regression-kit";
import {
  captureAgentVerifierEvidence,
  captureTargetedDiscoveryObservation,
  centerOfBounds,
  classifyTargetedDiscoveryScene,
  compileAndEvaluateAgentVerifier,
  compileOperatorStep,
  executeStrictResetStrategy,
  executeTargetedDiscoveryAction,
  persistOperatorExecutionOutcomes,
  readGraph,
  resolveGuardedStep,
  runAgentWithTimeout,
  runTimedCommand,
  synthesizeAndPersistTargetedDiscoveryGraph,
  targetedDiscoverySafetyIssue,
  validateGraph,
  verifyTargetedDiscoveryCompletion,
  writeGraphAtomic,
} from "../ios-ui-graph-experiment/workflow";

import type {
  AgentTargetedDiscoveryDecision,
  OperatorExecutionOutcome,
} from "../ios-ui-graph-experiment/workflow";
import type {
  ExecutableUiGraphExperiment,
  ExperimentElement,
  ExperimentOperator,
  GraphEntityStatus,
  TargetedDiscoveryAction,
  TargetedDiscoveryObservation,
  TimedExperimentCommand,
} from "../ios-ui-graph-experiment/types";
import type {
  IosUiGraphNavigatorFailureResult,
  IosUiGraphNavigatorInput,
  IosUiGraphNavigatorOutput,
  IosUiGraphNavigatorResult,
  NavigatorActionPlan,
  NavigatorCompletionOracle,
  NavigatorPerception,
  NavigatorStatus,
  NavigatorStepRecord,
} from "./types";

const DEFAULT_GRAPH_PATH = resolve(
  dirname(import.meta.path),
  "../ios-ui-graph-experiment/graph-chat-full.json",
);
const DEFAULT_PROJECT_ROOT = resolve(dirname(import.meta.path), "../..");
const DEFAULT_UDID = "00008030-001A286A2229802E";
const DEFAULT_MAX_STEPS = 12;
const DEFAULT_AGENT_TIMEOUT_MS = 60_000;

const navigatorDecisionSchema = {
  type: "object",
  properties: {
    sceneId: { type: "string" },
    sceneConfidence: { type: "number", minimum: 0, maximum: 1 },
    decision: {
      type: "string",
      enum: ["operator", "candidate", "complete", "blocked"],
    },
    operatorId: { type: "string" },
    candidateId: { type: "string" },
    actionType: {
      type: "string",
      enum: ["tap", "long_press", "swipe_left", "swipe_right", "input_text"],
    },
    inputValue: { type: "string" },
    durationMs: { type: "number", minimum: 300, maximum: 3000 },
    targetElementTitle: { type: "string" },
    targetSemanticRole: { type: "string" },
    operatorTitle: { type: "string" },
    risk: {
      type: "string",
      enum: [
        "navigation",
        "interaction",
        "selection",
        "permission",
        "mutation",
        "destructive",
      ],
    },
    expectedOutcome: { type: "string" },
    expectedSceneTitle: { type: "string" },
    visualTextAnchors: { type: "array", items: { type: "string" } },
    completionEvidence: { type: "array", items: { type: "string" } },
    completionOracleType: {
      type: "string",
      enum: [
        "text_absent",
        "text_visible",
        "scene_changed",
        "region_stable",
        "none",
      ],
    },
    completionOracleValue: { type: "string" },
    reason: { type: "string" },
  },
  required: [
    "sceneId",
    "sceneConfidence",
    "decision",
    "operatorId",
    "candidateId",
    "actionType",
    "inputValue",
    "durationMs",
    "targetElementTitle",
    "targetSemanticRole",
    "operatorTitle",
    "risk",
    "expectedOutcome",
    "expectedSceneTitle",
    "visualTextAnchors",
    "completionEvidence",
    "completionOracleType",
    "completionOracleValue",
    "reason",
  ],
  additionalProperties: false,
} as const satisfies JsonSchema;

const observationKnowledgeSchema = {
  type: "object",
  properties: {
    sceneId: { type: "string" },
    sceneTitle: { type: "string" },
    sceneAliases: { type: "array", items: { type: "string" } },
    visualTextAnchors: { type: "array", items: { type: "string" } },
    elements: {
      type: "array",
      items: {
        type: "object",
        properties: {
          candidateId: { type: "string" },
          elementId: { type: "string" },
          title: { type: "string" },
          semanticRole: { type: "string" },
        },
        required: ["candidateId", "elementId", "title", "semanticRole"],
        additionalProperties: false,
      },
    },
    reason: { type: "string" },
  },
  required: [
    "sceneId",
    "sceneTitle",
    "sceneAliases",
    "visualTextAnchors",
    "elements",
    "reason",
  ],
  additionalProperties: false,
} as const satisfies JsonSchema;

interface AgentNavigatorDecision {
  readonly sceneId: string;
  readonly sceneConfidence: number;
  readonly decision: "operator" | "candidate" | "complete" | "blocked";
  readonly operatorId: string;
  readonly candidateId: string;
  readonly actionType:
    "tap" | "long_press" | "swipe_left" | "swipe_right" | "input_text";
  readonly inputValue: string;
  readonly durationMs: number;
  readonly targetElementTitle: string;
  readonly targetSemanticRole: string;
  readonly operatorTitle: string;
  readonly risk: ExperimentOperator["risk"];
  readonly expectedOutcome: string;
  readonly expectedSceneTitle: string;
  readonly visualTextAnchors: readonly string[];
  readonly completionEvidence: readonly string[];
  readonly completionOracleType:
    "text_absent" | "text_visible" | "scene_changed" | "region_stable" | "none";
  readonly completionOracleValue: string;
  readonly reason: string;
}

interface ObservationKnowledgeProposal {
  readonly sceneId: string;
  readonly sceneTitle: string;
  readonly sceneAliases: readonly string[];
  readonly visualTextAnchors: readonly string[];
  readonly elements: readonly {
    readonly candidateId: string;
    readonly elementId: string;
    readonly title: string;
    readonly semanticRole: string;
  }[];
  readonly reason: string;
}

/** Injectable seams used by unit tests; defaults reuse the production engine. */
export interface NavigatorDependencies {
  readonly agentRunner: AgentFunction;
  readonly captureObservation: typeof captureTargetedDiscoveryObservation;
  readonly executeReset: typeof executeStrictResetStrategy;
  readonly executeCandidate: typeof executeTargetedDiscoveryAction;
  readonly runTimed: typeof runTimedCommand;
  readonly captureVerifierEvidence: typeof captureAgentVerifierEvidence;
  readonly compileVerifier: typeof compileAndEvaluateAgentVerifier;
}

const defaultDependencies: NavigatorDependencies = {
  agentRunner: agent,
  captureObservation: captureTargetedDiscoveryObservation,
  executeReset: executeStrictResetStrategy,
  executeCandidate: executeTargetedDiscoveryAction,
  runTimed: runTimedCommand,
  captureVerifierEvidence: captureAgentVerifierEvidence,
  compileVerifier: compileAndEvaluateAgentVerifier,
};

export const meta = {
  name: "ios-ui-graph-navigator",
  description:
    "Executes arbitrary iOS UI goals through a live perception, Agent planning, action, verification, and Graph-learning loop.",
  phases: [
    { title: "Load" },
    { title: "Preflight" },
    { title: "Reset" },
    { title: "Perceive" },
    { title: "Plan" },
    { title: "Act" },
    { title: "Verify" },
    { title: "Learn" },
    { title: "Report" },
  ],
  exampleArgs: {
    goal: "从对话页进入相机拍一张照片，并确认预览页标记入口可见",
    planOnly: true,
  },
};

/** Runs one arbitrary semantic UI goal through the step-wise navigator. */
export default async function iosUiGraphNavigator(
  args: IosUiGraphNavigatorInput,
): Promise<IosUiGraphNavigatorOutput> {
  return runIosUiGraphNavigator(args);
}

/** Testable navigator core with injectable device and Agent dependencies. */
export async function runIosUiGraphNavigator(
  args: IosUiGraphNavigatorInput,
  dependencyOverrides: Partial<NavigatorDependencies> = {},
): Promise<IosUiGraphNavigatorOutput> {
  const dependencies = { ...defaultDependencies, ...dependencyOverrides };
  const runId = safeSegment(args?.runId?.trim() || timestampForPath());
  const outputDir = resolve(
    args?.outputDir?.trim() ||
      join(DEFAULT_ARTIFACT_ROOT, "ios-ui-graph-navigator", runId),
  );
  const graphPath = resolve(args?.graphPath?.trim() || DEFAULT_GRAPH_PATH);
  const projectRoot = resolve(
    args?.projectRoot?.trim() || DEFAULT_PROJECT_ROOT,
  );
  const udid = args?.udid?.trim() || DEFAULT_UDID;
  const planOnly = args?.planOnly === true;
  const goal = buildNavigatorGoal(args);
  const resultPath = join(outputDir, "result.json");
  const reportPath = join(outputDir, "report.json");
  await mkdir(outputDir, { recursive: true });

  let activeStage = "Load";
  try {
    setPhase(activeStage);
    if (!goal) {
      return writeFailure({
        outputDir,
        graphPath,
        resultPath,
        runId,
        goal,
        planOnly,
        code: "goal_missing",
        stage: activeStage,
        message: "Provide a non-empty goal or structured case.",
        recoverable: true,
      });
    }
    const graph = await readGraph(graphPath);
    validateGraph(graph);
    const deviceProfileId =
      args.deviceProfileId?.trim() || graph.defaultDeviceProfileId;
    const profile = graph.deviceProfiles.find(
      (candidate) => candidate.profileId === deviceProfileId,
    );
    const resetStrategy = graph.resetStrategies.find(
      (candidate) => candidate.strategyId === graph.defaultResetStrategyId,
    );
    if (!profile || !resetStrategy) {
      throw new Error(
        `Graph is missing device profile ${deviceProfileId} or reset strategy ${graph.defaultResetStrategyId}.`,
      );
    }

    const commands: TimedExperimentCommand[] = [];
    if (!planOnly) {
      activeStage = "Preflight";
      setPhase(activeStage);
      const preflight = await dependencies.runTimed({
        stepId: "navigator-preflight",
        command: buildMobilecliPreflightCommand(),
        outputDir: join(outputDir, "preflight"),
        cwd: projectRoot,
      });
      commands.push(preflight);
      if (preflight.exitCode !== 0) {
        return writeFailure({
          outputDir,
          graphPath,
          resultPath,
          runId,
          goal,
          planOnly,
          code: "preflight_failed",
          stage: activeStage,
          message: `mobilecli preflight failed with exit code ${preflight.exitCode}.`,
          recoverable: true,
          evidencePaths: [preflight.stderrPath],
        });
      }
      activeStage = "Reset";
      setPhase(activeStage);
      await dependencies.executeReset({
        strategy: resetStrategy,
        udid,
        outputDir: join(outputDir, "reset"),
        cwd: projectRoot,
        commands,
        stepPrefix: "navigator-reset",
      });
    }

    activeStage = "Perceive";
    setPhase(activeStage);
    let currentObservation: TargetedDiscoveryObservation;
    try {
      currentObservation = await captureObservationWithFallback({
        capture: dependencies.captureObservation,
        graph,
        udid,
        outputDir: join(outputDir, "observations"),
        index: 0,
        preferredSceneId: resetStrategy.entrySceneId,
        preferUiDump: planOnly,
      });
    } catch (error) {
      if (!planOnly) {
        throw error;
      }
      currentObservation = await buildStaticEntryObservation({
        graph,
        sceneId: resetStrategy.entrySceneId,
        deviceProfileId,
        outputDir: join(outputDir, "observations"),
        error,
      });
    }
    const observations: TargetedDiscoveryObservation[] = [currentObservation];
    const actions: TargetedDiscoveryAction[] = [];
    const steps: NavigatorStepRecord[] = [];
    const operatorOutcomes: OperatorExecutionOutcome[] = [];
    const maxSteps = boundedInteger(args.maxSteps, 1, 40, DEFAULT_MAX_STEPS);
    const timeoutMs = boundedInteger(
      args.agentTimeoutMs,
      1_000,
      300_000,
      DEFAULT_AGENT_TIMEOUT_MS,
    );
    let completionOracle: NavigatorCompletionOracle | undefined;
    let completionEvidence: string[] = [];
    let consecutiveFailures = 0;
    let loopIssue: string | undefined;

    for (let stepIndex = 0; stepIndex < maxSteps; stepIndex += 1) {
      activeStage = "Plan";
      setPhase(activeStage);
      const planned = await planNavigatorStep({
        graph,
        goal,
        observation: currentObservation,
        previousActions: actions,
        previousSteps: steps,
        cwd: projectRoot,
        model: args.model,
        timeoutMs,
        agentRunner: dependencies.agentRunner,
      });
      const correctedObservation = applyPerceptionToObservation(
        currentObservation,
        planned.perception,
        graph,
      );
      currentObservation = correctedObservation;
      observations[observations.length - 1] = correctedObservation;
      const staticPlan =
        planOnly && correctedObservation.observationId === "static-entry"
          ? markStaticGraphPlan(planned)
          : planned;
      const effectivePerception = staticPlan.perception;
      const effectivePlan = staticPlan.plan;
      const evidencePaths = observationEvidencePaths(correctedObservation);

      if (effectivePlan.kind === "complete") {
        const proven = await verifyTargetedDiscoveryCompletion({
          oracle: effectivePlan.oracle,
          initialObservation: observations[0]!,
          currentObservation: correctedObservation,
        });
        steps.push({
          stepIndex,
          beforeObservationId: correctedObservation.observationId,
          perception: effectivePerception,
          plan: effectivePlan,
          evidencePaths,
        });
        if (proven) {
          completionOracle = effectivePlan.oracle;
          completionEvidence = [...effectivePlan.completionEvidence];
        } else {
          loopIssue =
            "Agent reported completion, but the deterministic completion oracle did not pass.";
        }
        break;
      }
      if (effectivePlan.kind === "blocked") {
        steps.push({
          stepIndex,
          beforeObservationId: correctedObservation.observationId,
          perception: effectivePerception,
          plan: effectivePlan,
          evidencePaths,
        });
        loopIssue = effectivePlan.reason;
        break;
      }
      if (planOnly) {
        steps.push({
          stepIndex,
          beforeObservationId: correctedObservation.observationId,
          perception: effectivePerception,
          plan: effectivePlan,
          evidencePaths,
        });
        break;
      }

      activeStage = "Act";
      setPhase(activeStage);
      let exitCode: number;
      let command: readonly string[];
      let afterObservation: TargetedDiscoveryObservation;
      if (effectivePlan.kind === "known_operator") {
        const operator = graph.operators.find(
          (candidate) => candidate.operatorId === effectivePlan.operatorId,
        )!;
        const parameters = {
          text: effectivePlan.inputValue ?? "",
          question: effectivePlan.inputValue ?? "",
          value: effectivePlan.inputValue ?? "",
        };
        let compiled = compileOperatorStep({
          graph,
          operator,
          index: stepIndex,
          parameters,
          udid,
          deviceProfileId,
          profile,
          elements: new Map(
            graph.elements.map((element) => [element.elementId, element]),
          ),
          stepPrefix: "navigator-",
          allowCandidate: true,
          appVersion: args.appVersion,
        });
        if (compiled.requiresLiveResolution) {
          compiled = await resolveGuardedStep({
            graph,
            step: compiled,
            deviceProfileId,
            udid,
            outputDir: join(
              outputDir,
              "guarded-resolution",
              safeSegment(compiled.stepId),
            ),
            commandCwd: projectRoot,
            agentCwd: projectRoot,
            model: args.model,
            timeoutMs,
          });
        }
        const timed = await dependencies.runTimed({
          stepId: compiled.stepId,
          command: compiled.command,
          outputDir: join(outputDir, "commands"),
          cwd: projectRoot,
        });
        commands.push(timed);
        exitCode = timed.exitCode;
        command = compiled.command;
        if (compiled.settleMs > 0) {
          await Bun.sleep(compiled.settleMs);
        }
        activeStage = "Perceive";
        setPhase(activeStage);
        afterObservation = await captureObservationWithFallback({
          capture: dependencies.captureObservation,
          graph,
          udid,
          outputDir: join(outputDir, "observations"),
          index: observations.length,
          preferredSceneId: compiled.expectedToSceneId,
        });
        operatorOutcomes.push({
          operatorId: operator.operatorId,
          success: exitCode === 0,
          evidencePath: afterObservation.uiDumpPath,
          failure:
            exitCode === 0 ? undefined : `Command exited with ${exitCode}.`,
          liveResolution: compiled.liveResolution,
        });
      } else {
        const candidate = correctedObservation.candidates.find(
          (item) => item.candidateId === effectivePlan.candidateId,
        )!;
        const decision = candidatePlanToDiscoveryDecision(effectivePlan);
        const safetyIssue = targetedDiscoverySafetyIssue({
          goal,
          decision,
          candidate,
          previousActions: actions,
        });
        if (safetyIssue) {
          steps.push({
            stepIndex,
            beforeObservationId: correctedObservation.observationId,
            perception: effectivePerception,
            plan: {
              kind: "blocked",
              reason: safetyIssue,
              agentUsed: true,
            },
            evidencePaths,
          });
          loopIssue = safetyIssue;
          break;
        }
        const executed = await dependencies.executeCandidate({
          graph,
          decision,
          candidate,
          currentObservation: correctedObservation,
          udid,
          outputDir: join(outputDir, "candidate-actions"),
          observationIndex: observations.length,
          stepIdPrefix: "navigator",
          stepIndex,
          purpose: "advance_goal",
          cwd: projectRoot,
          commands,
          fallbackToUiDump: true,
        });
        actions.push(executed.action);
        exitCode = executed.action.exitCode;
        command = executed.action.command;
        afterObservation = executed.observation;
      }

      observations.push(afterObservation);
      currentObservation = afterObservation;
      steps.push({
        stepIndex,
        beforeObservationId: correctedObservation.observationId,
        afterObservationId: afterObservation.observationId,
        perception: effectivePerception,
        plan: effectivePlan,
        exitCode,
        command,
        evidencePaths: [
          ...evidencePaths,
          ...observationEvidencePaths(afterObservation),
        ],
      });
      if (exitCode === 0) {
        consecutiveFailures = 0;
      } else {
        const failureState = nextActionFailureState(
          consecutiveFailures,
          exitCode,
        );
        consecutiveFailures = failureState.consecutiveFailures;
        if (!failureState.canRecover) {
          loopIssue =
            "Two consecutive actions failed; navigation stopped after the recovery opportunity.";
          break;
        }
      }
    }

    if (planOnly) {
      const result: IosUiGraphNavigatorResult = {
        success: false,
        mode: "navigation",
        planOnly: true,
        status: "needs_review",
        runId,
        outputDir,
        graphPath,
        resultPath,
        reportPath,
        goal,
        stepsUsed: steps.length,
        steps,
        observations,
        actions,
        commands,
        completionEvidence,
        evidencePaths: unique(observations.flatMap(observationEvidencePaths)),
      };
      return writeResult(result);
    }

    activeStage = "Verify";
    setPhase(activeStage);
    const verifierEvidence = await dependencies.captureVerifierEvidence({
      graph,
      goal,
      observation: currentObservation,
      udid,
    });
    const verifier = await dependencies.compileVerifier({
      graph,
      goal,
      evidence: verifierEvidence,
      legacySuccess: Boolean(completionOracle),
      pathSuccess: consecutiveFailures === 0,
      outputDir: join(outputDir, "verification"),
      cwd: projectRoot,
      model: args.model,
      timeoutMs,
    });
    if (!completionOracle && verifier.success) {
      completionOracle = deriveOracleFromVerifier(verifier);
      completionEvidence = verifier.assertionResults
        .filter((result) => result.success)
        .flatMap((result) => result.evidence);
    }
    const status = navigatorStatusFromVerifier(
      verifier.classification,
      loopIssue,
    );
    let learnedGraphPatchPath: string | undefined;
    let executionLearningPatchPath: string | undefined;

    activeStage = "Learn";
    setPhase(activeStage);
    if (args.allowLearning !== false && status === "pass") {
      const patchPaths: string[] = [];
      if (completionOracle && actions.length > 0) {
        const synthesis = await synthesizeAndPersistTargetedDiscoveryGraph({
          graph,
          graphPath,
          outputDir: join(outputDir, "learning", "actions"),
          goal,
          observations,
          actions,
          completionOracle,
          completionEvidence,
          evidencePath: verifier.evidencePath,
          deviceProfileId,
          agentCwd: projectRoot,
          model: args.model,
          timeoutMs,
          verifier: verifier.spec,
          initialEntityStatus: "candidate",
        });
        patchPaths.push(synthesis.graphPatchPath);
      }
      const observationPatch = await persistObservedKnowledge({
        graphPath,
        outputDir: join(outputDir, "learning", "observation"),
        observation: currentObservation,
        goal,
        deviceProfileId,
        model: args.model,
        timeoutMs,
        agentRunner: dependencies.agentRunner,
      });
      if (observationPatch) {
        patchPaths.push(observationPatch);
      }
      if (operatorOutcomes.length > 0) {
        executionLearningPatchPath = await persistOperatorExecutionOutcomes({
          graphPath,
          outcomes: operatorOutcomes,
          appVersion: args.appVersion,
          outputDir: join(outputDir, "learning", "operators"),
        });
      }
      if (patchPaths.length > 0) {
        learnedGraphPatchPath = join(
          outputDir,
          "learning",
          "navigator-learning-patch.json",
        );
        await writeJsonAtomic(learnedGraphPatchPath, {
          schemaVersion: "ios-ui-navigator-learning-patch/v1",
          graphPath,
          patchPaths,
          generatedAt: new Date().toISOString(),
        });
      }
    } else if (operatorOutcomes.length > 0) {
      executionLearningPatchPath = await persistOperatorExecutionOutcomes({
        graphPath,
        outcomes: operatorOutcomes,
        appVersion: args.appVersion,
        outputDir: join(outputDir, "learning", "operators"),
      });
    }

    const result: IosUiGraphNavigatorResult = {
      success: status === "pass",
      mode: "navigation",
      planOnly: false,
      status,
      runId,
      outputDir,
      graphPath,
      resultPath,
      reportPath,
      goal,
      stepsUsed: steps.length,
      steps,
      observations,
      actions,
      commands,
      completionOracle,
      completionEvidence,
      agentVerifier: verifier,
      learnedGraphPatchPath,
      executionLearningPatchPath,
      evidencePaths: unique([
        ...observations.flatMap(observationEvidencePaths),
        verifier.evidencePath,
        ...(learnedGraphPatchPath ? [learnedGraphPatchPath] : []),
        ...(executionLearningPatchPath ? [executionLearningPatchPath] : []),
      ]),
      failure:
        status === "pass"
          ? undefined
          : {
              code:
                verifier.classification === "path_failed"
                  ? "navigation_path_failed"
                  : "navigation_unproven",
              stage: "Verify",
              message:
                loopIssue ??
                `Verifier classified the final evidence as ${verifier.classification}.`,
              recoverable: true,
              evidencePaths: [verifier.evidencePath],
            },
    };
    return writeResult(result);
  } catch (error) {
    return writeFailure({
      outputDir,
      graphPath,
      resultPath,
      runId,
      goal,
      planOnly,
      code: failureCode(activeStage),
      stage: activeStage,
      message: error instanceof Error ? error.message : String(error),
      recoverable: activeStage !== "Load",
    });
  }
}

function markStaticGraphPlan(planned: {
  perception: NavigatorPerception;
  plan: NavigatorActionPlan;
}): { perception: NavigatorPerception; plan: NavigatorActionPlan } {
  return {
    perception: {
      ...planned.perception,
      source: "static_graph",
      confidence: Math.min(planned.perception.confidence, 0.7),
      reason: `Live read-only capture was unavailable; static reset-entry Graph planning was used. ${planned.perception.reason}`,
    },
    plan: planned.plan,
  };
}

/** Produces one bounded Agent plan from the current real observation. */
export async function planNavigatorStep(options: {
  graph: ExecutableUiGraphExperiment;
  goal: string;
  observation: TargetedDiscoveryObservation;
  previousActions: readonly TargetedDiscoveryAction[];
  previousSteps: readonly NavigatorStepRecord[];
  cwd: string;
  model?: string;
  timeoutMs: number;
  agentRunner: AgentFunction;
}): Promise<{ perception: NavigatorPerception; plan: NavigatorActionPlan }> {
  const sceneCandidates = buildSceneCandidates(
    options.graph,
    options.observation,
  );
  const deterministic = chooseDeterministicOperator({
    graph: options.graph,
    goal: options.goal,
    observation: options.observation,
    sceneCandidates,
    previousSteps: options.previousSteps,
  });
  if (deterministic) {
    return deterministic;
  }
  const operatorCards = buildRelevantOperatorCards(
    options.graph,
    options.observation,
    sceneCandidates.map((scene) => scene.sceneId),
  );
  const prompt = [
    "Plan exactly one bounded step for an iOS UI goal.",
    "Return only schema-backed JSON.",
    "First identify the current Scene from Scene candidates and live UI candidates.",
    "The deterministic matchedSceneId is only a hint and may be wrong.",
    "For an existing Graph capability choose decision=operator and an operatorId only from Known Operators.",
    "For an unknown capability choose decision=candidate and a candidateId only from Live candidates.",
    "Coordinates are forbidden. The executor derives coordinates from candidate bounds or Graph bindings.",
    "Use complete only when the current live evidence already proves the requested user-visible outcome.",
    "A complete decision must provide a deterministic text/scene/region completion oracle.",
    "Do not skip required intermediate actions from the user's described steps.",
    "Do not choose send, payment, purchase, permission approval, or destructive actions unless the goal explicitly requires them.",
    "Use input_text only with an existing Graph input Operator and put the exact text in inputValue.",
    "Use blocked only when no safe goal-relevant action exists.",
    "",
    `Goal: ${options.goal}`,
    `Scene candidates: ${JSON.stringify(sceneCandidates)}`,
    `Known Operators: ${JSON.stringify(operatorCards)}`,
    `Live candidates: ${JSON.stringify(options.observation.candidates)}`,
    `Previous actions: ${JSON.stringify(options.previousActions)}`,
    `Previous steps: ${JSON.stringify(
      options.previousSteps.map((step) => ({
        sceneId: step.perception.sceneId,
        plan: step.plan,
        exitCode: step.exitCode,
      })),
    )}`,
  ].join("\n");
  const decision = await runAgentWithTimeout<AgentNavigatorDecision>(
    prompt,
    {
      cwd: options.cwd,
      model: options.model,
      sandbox: "read-only",
      schema: navigatorDecisionSchema,
      env: { CODEX_HOME: undefined },
    },
    options.timeoutMs,
    "navigator perception and planning",
    options.agentRunner,
  );
  return normalizeNavigatorDecision({
    graph: options.graph,
    observation: options.observation,
    sceneCandidates,
    operatorCards,
    decision,
  });
}

/** Selects one unambiguous known Graph Operator without invoking an Agent. */
export function chooseDeterministicOperator(options: {
  graph: ExecutableUiGraphExperiment;
  goal: string;
  observation: TargetedDiscoveryObservation;
  sceneCandidates: readonly ReturnType<typeof buildSceneCandidates>[number][];
  previousSteps: readonly NavigatorStepRecord[];
}): { perception: NavigatorPerception; plan: NavigatorActionPlan } | null {
  const [currentScene, secondScene] = options.sceneCandidates;
  if (
    !currentScene ||
    currentScene.score < 3 ||
    currentScene.score - (secondScene?.score ?? 0) < 2
  ) {
    return null;
  }
  const cards = buildRelevantOperatorCards(options.graph, options.observation, [
    currentScene.sceneId,
  ]).filter((card) => card.fromSceneId === currentScene.sceneId);
  const previousPlan = options.previousSteps.at(-1)?.plan;
  const previousOperatorId =
    previousPlan?.kind === "known_operator"
      ? previousPlan.operatorId
      : undefined;
  const scored = cards
    .map((card) => ({
      card,
      score: operatorGoalScore(options.graph, options.goal, card),
    }))
    .filter(
      (candidate) =>
        candidate.score >= 4 &&
        !(
          candidate.card.operatorId === previousOperatorId &&
          candidate.card.fromSceneId !== candidate.card.toSceneId
        ),
    )
    .sort(
      (left, right) =>
        right.score - left.score ||
        left.card.operatorId.localeCompare(right.card.operatorId),
    );
  const selected = scored[0];
  if (!selected || selected.score === scored[1]?.score) {
    return null;
  }
  const operator = options.graph.operators.find(
    (candidate) => candidate.operatorId === selected.card.operatorId,
  )!;
  return {
    perception: {
      sceneId: currentScene.sceneId,
      sceneTitle: currentScene.title,
      source: "deterministic",
      confidence: Math.min(1, currentScene.score / 6),
      agentUsed: false,
      candidateSceneIds: options.sceneCandidates.map(
        (candidate) => candidate.sceneId,
      ),
      reason: `Live anchors uniquely identify ${currentScene.sceneId}; Operator ${operator.operatorId} uniquely matches the goal.`,
    },
    plan: {
      kind: "known_operator",
      operatorId: operator.operatorId,
      actionType:
        operator.operation.type === "input_text"
          ? "input_text"
          : operator.operation.type === "long_press"
            ? "long_press"
            : operator.operation.type === "swipe"
              ? "swipe_left"
              : "tap",
      reason: `Deterministic Graph fast path selected ${operator.operatorId}.`,
      agentUsed: false,
    },
  };
}

/** Converts the schema-backed Agent decision into a constrained plan. */
export function normalizeNavigatorDecision(options: {
  graph: ExecutableUiGraphExperiment;
  observation: TargetedDiscoveryObservation;
  sceneCandidates: readonly ReturnType<typeof buildSceneCandidates>[number][];
  operatorCards: readonly ReturnType<
    typeof buildRelevantOperatorCards
  >[number][];
  decision: AgentNavigatorDecision;
}): { perception: NavigatorPerception; plan: NavigatorActionPlan } {
  const selectedScene = options.sceneCandidates.find(
    (candidate) => candidate.sceneId === options.decision.sceneId,
  );
  const perception: NavigatorPerception = {
    sceneId: selectedScene?.sceneId ?? null,
    sceneTitle: selectedScene?.title ?? options.observation.candidateSceneTitle,
    source: selectedScene
      ? options.decision.sceneConfidence >= 0.8
        ? "agent"
        : "unknown"
      : "unknown",
    confidence: selectedScene ? options.decision.sceneConfidence : 0,
    agentUsed: true,
    candidateSceneIds: options.sceneCandidates.map(
      (candidate) => candidate.sceneId,
    ),
    reason: options.decision.reason,
  };
  if (!selectedScene) {
    return {
      perception,
      plan: {
        kind: "blocked",
        reason: `Agent selected unknown Scene ${options.decision.sceneId}.`,
        agentUsed: true,
      },
    };
  }
  if (options.decision.decision === "complete") {
    if (
      options.decision.completionOracleType === "none" ||
      !options.decision.completionOracleValue.trim()
    ) {
      return {
        perception,
        plan: {
          kind: "blocked",
          reason: "Agent completion did not include an executable oracle.",
          agentUsed: true,
        },
      };
    }
    return {
      perception,
      plan: {
        kind: "complete",
        oracle: {
          type: options.decision.completionOracleType,
          value: options.decision.completionOracleValue,
        },
        completionEvidence: options.decision.completionEvidence,
        reason: options.decision.reason,
        agentUsed: true,
      },
    };
  }
  if (options.decision.decision === "blocked") {
    return {
      perception,
      plan: {
        kind: "blocked",
        reason: options.decision.reason,
        agentUsed: true,
      },
    };
  }
  if (options.decision.decision === "operator") {
    const card = options.operatorCards.find(
      (candidate) => candidate.operatorId === options.decision.operatorId,
    );
    const operator = options.graph.operators.find(
      (candidate) => candidate.operatorId === card?.operatorId,
    );
    if (!card || !operator) {
      return {
        perception,
        plan: {
          kind: "blocked",
          reason: `Agent selected unavailable Operator ${options.decision.operatorId}.`,
          agentUsed: true,
        },
      };
    }
    if (
      operator.risk === "destructive" &&
      !/删除|移除|清空/.test(options.decision.expectedOutcome)
    ) {
      return {
        perception,
        plan: {
          kind: "blocked",
          reason: `Destructive Operator ${operator.operatorId} is not explicitly authorized.`,
          agentUsed: true,
        },
      };
    }
    return {
      perception,
      plan: {
        kind: "known_operator",
        operatorId: operator.operatorId,
        actionType:
          operator.operation.type === "input_text"
            ? "input_text"
            : operator.operation.type === "long_press"
              ? "long_press"
              : operator.operation.type === "swipe"
                ? "swipe_left"
                : "tap",
        inputValue: options.decision.inputValue || undefined,
        reason: options.decision.reason,
        agentUsed: true,
      },
    };
  }
  const candidate = options.observation.candidates.find(
    (item) => item.candidateId === options.decision.candidateId,
  );
  if (!candidate || options.decision.actionType === "input_text") {
    return {
      perception,
      plan: {
        kind: "blocked",
        reason: `Agent selected unavailable or unsupported live candidate ${options.decision.candidateId}.`,
        agentUsed: true,
      },
    };
  }
  return {
    perception,
    plan: {
      kind: "candidate",
      candidateId: candidate.candidateId,
      actionType: options.decision.actionType,
      durationMs: options.decision.durationMs,
      targetElementTitle: options.decision.targetElementTitle,
      targetSemanticRole: options.decision.targetSemanticRole,
      operatorTitle: options.decision.operatorTitle,
      risk: options.decision.risk,
      expectedOutcome: options.decision.expectedOutcome,
      sceneTitle: options.decision.expectedSceneTitle,
      visualTextAnchors: options.decision.visualTextAnchors,
      reason: options.decision.reason,
      agentUsed: true,
    },
  };
}

/** Builds ranked Scene candidates from the real live observation. */
export function buildSceneCandidates(
  graph: ExecutableUiGraphExperiment,
  observation: TargetedDiscoveryObservation,
): Array<{
  sceneId: string;
  title: string;
  score: number;
  evidence: readonly string[];
}> {
  const observedTexts = observation.candidates
    .map(candidateText)
    .filter(Boolean);
  const semantic = classifyTargetedDiscoveryScene(observation.candidates);
  return graph.scenes
    .map((scene) => {
      const textHits = (scene.visualTextAnchors ?? []).filter((anchor) =>
        observedTexts.some((text) =>
          normalized(text).includes(normalized(anchor)),
        ),
      );
      const elementHits = scene.anchorElementIds.filter((elementId) => {
        const element = graph.elements.find(
          (candidate) => candidate.elementId === elementId,
        );
        return Boolean(
          element &&
          observation.candidates.some((candidate) =>
            selectorMatchesCandidate(element, candidate),
          ),
        );
      });
      const score =
        textHits.length * 2 +
        elementHits.length * 3 +
        (observation.matchedSceneId === scene.sceneId ? 1 : 0) +
        (semantic?.sceneId === scene.sceneId ? 4 : 0);
      return {
        sceneId: scene.sceneId,
        title: scene.title,
        score,
        evidence: [...textHits, ...elementHits],
      };
    })
    .filter((scene) => scene.score > 0)
    .sort(
      (left, right) =>
        right.score - left.score || left.sceneId.localeCompare(right.sceneId),
    )
    .slice(0, 12);
}

/** Returns known Operators relevant to the current candidate Scenes/elements. */
export function buildRelevantOperatorCards(
  graph: ExecutableUiGraphExperiment,
  observation: TargetedDiscoveryObservation,
  sceneIds: readonly string[],
): Array<{
  operatorId: string;
  title: string;
  fromSceneId: string;
  toSceneId: string;
  operationType: string;
  risk: ExperimentOperator["risk"];
  elementTitle?: string;
  elementVisible: boolean;
}> {
  const sceneSet = new Set(sceneIds);
  return graph.operators
    .map((operator) => {
      const elementId =
        operator.operation.type === "tap" ||
        operator.operation.type === "long_press" ||
        operator.operation.type === "tap_restart_app"
          ? operator.operation.elementId
          : undefined;
      const element = elementId
        ? graph.elements.find((candidate) => candidate.elementId === elementId)
        : undefined;
      const elementVisible = Boolean(
        element &&
        observation.candidates.some((candidate) =>
          selectorMatchesCandidate(element, candidate),
        ),
      );
      return {
        operatorId: operator.operatorId,
        title: operator.title,
        fromSceneId: operator.fromSceneId,
        toSceneId: operator.toSceneId,
        operationType: operator.operation.type,
        risk: operator.risk,
        elementTitle: element?.title,
        elementVisible,
        relevant:
          sceneSet.has(operator.fromSceneId) ||
          elementVisible ||
          (operator.operation.type === "input_text" &&
            sceneSet.has(operator.fromSceneId)),
      };
    })
    .filter(
      (card) =>
        card.relevant &&
        !["stale", "blocked", "disabled"].includes(
          graph.operators.find(
            (operator) => operator.operatorId === card.operatorId,
          )!.status,
        ),
    )
    .sort(
      (left, right) =>
        Number(right.elementVisible) - Number(left.elementVisible) ||
        left.operatorId.localeCompare(right.operatorId),
    )
    .slice(0, 80)
    .map((card) => ({
      operatorId: card.operatorId,
      title: card.title,
      fromSceneId: card.fromSceneId,
      toSceneId: card.toSceneId,
      operationType: card.operationType,
      risk: card.risk,
      elementTitle: card.elementTitle,
      elementVisible: card.elementVisible,
    }));
}

function operatorGoalScore(
  graph: ExecutableUiGraphExperiment,
  goal: string,
  card: ReturnType<typeof buildRelevantOperatorCards>[number],
): number {
  const normalizedGoal = normalized(goal);
  const targetScene = graph.scenes.find(
    (scene) => scene.sceneId === card.toSceneId,
  );
  const phrases = [
    { value: card.title, weight: 6 },
    { value: card.elementTitle, weight: 4 },
    { value: targetScene?.title, weight: 4 },
    ...(targetScene?.aliases ?? []).map((value) => ({ value, weight: 3 })),
  ];
  return phrases.reduce((score, phrase) => {
    const value = phrase.value ? normalized(phrase.value) : "";
    if (!value || value.length < 2) {
      return score;
    }
    if (normalizedGoal.includes(value)) {
      return score + phrase.weight;
    }
    const tokens = semanticTokens(value);
    const hits = tokens.filter((token) =>
      normalizedGoal.includes(token),
    ).length;
    return score + Math.min(phrase.weight - 1, hits);
  }, Number(card.elementVisible));
}

function semanticTokens(value: string): string[] {
  if (/^[a-z0-9]+$/i.test(value)) {
    return value.length >= 3 ? [value] : [];
  }
  const tokens = new Set<string>();
  for (let index = 0; index < value.length - 1; index += 1) {
    tokens.add(value.slice(index, index + 2));
  }
  return [...tokens];
}

/** Maps verifier classification to the user-facing navigator verdict. */
export function navigatorStatusFromVerifier(
  classification:
    | "pass"
    | "oracle_stale"
    | "uncertain"
    | "path_failed"
    | "evidence_insufficient",
  loopIssue?: string,
): NavigatorStatus {
  if (classification === "pass" || classification === "oracle_stale") {
    return "pass";
  }
  if (classification === "path_failed") {
    return "fail";
  }
  if (loopIssue?.includes("consecutive actions failed")) {
    return "blocked";
  }
  return "needs_review";
}

/** Decides whether successful evidence is safe to write back to the Graph. */
export function shouldPersistLearning(options: {
  status: NavigatorStatus;
  allowLearning: boolean;
  hasEvidence: boolean;
}): boolean {
  return (
    options.status === "pass" && options.allowLearning && options.hasEvidence
  );
}

/** Applies the one-step recovery policy after an action command. */
export function nextActionFailureState(
  previousConsecutiveFailures: number,
  exitCode: number,
): { consecutiveFailures: number; canRecover: boolean } {
  if (exitCode === 0) {
    return { consecutiveFailures: 0, canRecover: true };
  }
  const consecutiveFailures = previousConsecutiveFailures + 1;
  return {
    consecutiveFailures,
    canRecover: consecutiveFailures < 2,
  };
}

function applyPerceptionToObservation(
  observation: TargetedDiscoveryObservation,
  perception: NavigatorPerception,
  graph: ExecutableUiGraphExperiment,
): TargetedDiscoveryObservation {
  if (!perception.sceneId) {
    return observation;
  }
  const knownScene = graph.scenes.find(
    (scene) => scene.sceneId === perception.sceneId,
  );
  return knownScene
    ? {
        ...observation,
        matchedSceneId: knownScene.sceneId,
        candidateSceneId: knownScene.sceneId,
        candidateSceneTitle: knownScene.title,
      }
    : {
        ...observation,
        matchedSceneId: null,
        candidateSceneId: perception.sceneId,
        candidateSceneTitle: perception.sceneTitle,
      };
}

function candidatePlanToDiscoveryDecision(
  plan: Extract<NavigatorActionPlan, { kind: "candidate" }>,
): AgentTargetedDiscoveryDecision {
  return {
    status: "action",
    candidateId: plan.candidateId,
    actionType: plan.actionType,
    durationMs: plan.durationMs,
    targetElementTitle: plan.targetElementTitle,
    targetSemanticRole: plan.targetSemanticRole,
    operatorTitle: plan.operatorTitle,
    risk: plan.risk,
    expectedOutcome: plan.expectedOutcome,
    sceneTitle: plan.sceneTitle,
    visualTextAnchors: plan.visualTextAnchors,
    completionEvidence: [],
    completionOracleType: "none",
    completionOracleValue: "",
    reason: plan.reason,
  };
}

async function captureObservationWithFallback(options: {
  capture: typeof captureTargetedDiscoveryObservation;
  graph: ExecutableUiGraphExperiment;
  udid: string;
  outputDir: string;
  index: number;
  preferredSceneId?: string;
  preferUiDump?: boolean;
}): Promise<TargetedDiscoveryObservation> {
  if (options.preferUiDump) {
    return options.capture({
      graph: options.graph,
      udid: options.udid,
      outputDir: options.outputDir,
      index: options.index,
      preferredSceneId: options.preferredSceneId,
      evidenceLevel: "ui_dump",
    });
  }
  try {
    return await options.capture({
      graph: options.graph,
      udid: options.udid,
      outputDir: options.outputDir,
      index: options.index,
      preferredSceneId: options.preferredSceneId,
      evidenceLevel: "full",
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    const diagnosticsPath = join(
      options.outputDir,
      `observation-${String(options.index).padStart(2, "0")}`,
      "full-capture-failure.json",
    );
    await writeJsonAtomic(diagnosticsPath, {
      schemaVersion: "ios-ui-navigator-capture-fallback/v1",
      error: message,
      fallback: "ui_dump",
      generatedAt: new Date().toISOString(),
    });
    const observation = await options.capture({
      graph: options.graph,
      udid: options.udid,
      outputDir: options.outputDir,
      index: options.index,
      preferredSceneId: options.preferredSceneId,
      evidenceLevel: "ui_dump",
    });
    return {
      ...observation,
      screenshotPath: diagnosticsPath,
    };
  }
}

async function buildStaticEntryObservation(options: {
  graph: ExecutableUiGraphExperiment;
  sceneId: string;
  deviceProfileId: string;
  outputDir: string;
  error: unknown;
}): Promise<TargetedDiscoveryObservation> {
  const scene = options.graph.scenes.find(
    (candidate) => candidate.sceneId === options.sceneId,
  );
  const profile = options.graph.deviceProfiles.find(
    (candidate) => candidate.profileId === options.deviceProfileId,
  );
  if (!scene || !profile) {
    throw options.error;
  }
  const directory = join(options.outputDir, "static-entry");
  const evidencePath = join(directory, "static-entry.json");
  const elements = options.graph.elements.filter(
    (element) => element.sceneId === scene.sceneId,
  );
  const candidates = elements.flatMap((element, index) => {
    const binding = element.bindings
      .filter(
        (candidate) =>
          candidate.deviceProfileId === options.deviceProfileId &&
          (candidate.status === "verified" || candidate.status === "candidate"),
      )
      .sort((left, right) => right.reliability - left.reliability)[0];
    if (!binding) {
      return [];
    }
    const center = {
      x: binding.normalizedPoint.x * profile.viewportWidth,
      y: binding.normalizedPoint.y * profile.viewportHeight,
    };
    return [
      {
        candidateId: `static-${index + 1}`,
        source: "ui_dump" as const,
        role: element.selector.role,
        accessibilityId: element.selector.accessibilityId,
        label: element.selector.label ?? element.title,
        text: element.selector.text,
        value: element.selector.value,
        bounds: {
          x: Math.max(0, center.x - 22),
          y: Math.max(0, center.y - 22),
          width: 44,
          height: 44,
        },
      },
    ];
  });
  const errorMessage =
    options.error instanceof Error
      ? options.error.message
      : String(options.error);
  await writeJsonAtomic(evidencePath, {
    schemaVersion: "ios-ui-navigator-static-entry/v1",
    sceneId: scene.sceneId,
    reason: "Live read-only capture failed; generated from reset-entry Graph.",
    liveCaptureError: errorMessage,
    candidateCount: candidates.length,
    generatedAt: new Date().toISOString(),
  });
  return {
    observationId: "static-entry",
    screenshotPath: evidencePath,
    uiDumpPath: evidencePath,
    ocrPath: evidencePath,
    matchedSceneId: scene.sceneId,
    candidateSceneId: scene.sceneId,
    candidateSceneTitle: scene.title,
    visualTextAnchors: scene.visualTextAnchors ?? [],
    candidates,
  };
}

async function persistObservedKnowledge(options: {
  graphPath: string;
  outputDir: string;
  observation: TargetedDiscoveryObservation;
  goal: string;
  deviceProfileId: string;
  model?: string;
  timeoutMs: number;
  agentRunner: AgentFunction;
}): Promise<string | undefined> {
  const graph = await readGraph(options.graphPath);
  const prompt = [
    "Extract reusable, stable Scene and Element knowledge from one proven iOS UI observation.",
    "Return only schema-backed JSON.",
    "Reuse an existing Scene ID when the observation is that Scene.",
    "Choose element candidateId only from the Observation.",
    "Keep only stable, reusable, goal-relevant controls or visible result indicators.",
    "Do not invent candidates, coordinates, or account-specific labels.",
    "Use concise lower-case dot-separated IDs.",
    "",
    `Goal: ${options.goal}`,
    `Existing scenes: ${JSON.stringify(
      graph.scenes.map((scene) => ({
        sceneId: scene.sceneId,
        title: scene.title,
        aliases: scene.aliases,
      })),
    )}`,
    `Observation: ${JSON.stringify(options.observation)}`,
  ].join("\n");
  const proposal = await runAgentWithTimeout<ObservationKnowledgeProposal>(
    prompt,
    {
      cwd: DEFAULT_PROJECT_ROOT,
      model: options.model,
      sandbox: "read-only",
      schema: observationKnowledgeSchema,
      env: { CODEX_HOME: undefined },
    },
    options.timeoutMs,
    "navigator observation knowledge synthesis",
    options.agentRunner,
  );
  const candidates = new Map(
    options.observation.candidates.map((candidate) => [
      candidate.candidateId,
      candidate,
    ]),
  );
  const validElements = proposal.elements.filter(
    (element) =>
      candidates.has(element.candidateId) &&
      stableId(element.elementId) &&
      element.title.trim() &&
      element.semanticRole.trim(),
  );
  if (!stableId(proposal.sceneId) || validElements.length === 0) {
    return undefined;
  }
  const sceneExists = graph.scenes.some(
    (scene) => scene.sceneId === proposal.sceneId,
  );
  const scenes = sceneExists
    ? graph.scenes
    : [
        ...graph.scenes,
        {
          sceneId: proposal.sceneId,
          title: proposal.sceneTitle,
          aliases: proposal.sceneAliases,
          status: "candidate" as GraphEntityStatus,
          anchorElementIds: [],
          visualTextAnchors: proposal.visualTextAnchors.slice(0, 3),
          referenceAssets: [
            {
              screenshotPath: options.observation.screenshotPath,
              uiDumpPath: options.observation.uiDumpPath,
              recordPath: options.observation.ocrPath,
            },
          ],
        },
      ];
  const profile = graph.deviceProfiles.find(
    (candidate) => candidate.profileId === options.deviceProfileId,
  );
  if (!profile) {
    return undefined;
  }
  const addedElements: ExperimentElement[] = [];
  for (const element of validElements) {
    if (
      graph.elements.some(
        (existing) => existing.elementId === element.elementId,
      )
    ) {
      continue;
    }
    const candidate = candidates.get(element.candidateId)!;
    const point = centerOfBounds(candidate.bounds);
    addedElements.push({
      elementId: element.elementId,
      sceneId: proposal.sceneId,
      title: element.title,
      semanticRole: element.semanticRole,
      selector: {
        accessibilityId: candidate.accessibilityId,
        label: candidate.label,
        text: candidate.text,
        value: candidate.value,
        role: candidate.role,
      },
      bindings: [
        {
          bindingId: `${element.elementId}.${options.deviceProfileId}`,
          deviceProfileId: options.deviceProfileId,
          normalizedPoint: {
            x: point.x / profile.viewportWidth,
            y: point.y / profile.viewportHeight,
          },
          source: candidate.source === "ui_dump" ? "ui_dump" : "manual",
          status: "candidate",
          reliability: 0.7,
          observedAt: new Date().toISOString(),
        },
      ],
    });
  }
  if (!addedElements.length && sceneExists) {
    return undefined;
  }
  await writeGraphAtomic(options.graphPath, {
    ...graph,
    scenes,
    elements: [...graph.elements, ...addedElements],
  });
  const patchPath = join(options.outputDir, "observed-knowledge-patch.json");
  await writeJsonAtomic(patchPath, {
    schemaVersion: "ios-ui-navigator-observed-knowledge-patch/v1",
    graphPath: options.graphPath,
    proposal,
    addedScene: sceneExists ? null : proposal.sceneId,
    addedElements,
    generatedAt: new Date().toISOString(),
  });
  return patchPath;
}

function deriveOracleFromVerifier(
  verifier: NonNullable<IosUiGraphNavigatorResult["agentVerifier"]>,
): NavigatorCompletionOracle | undefined {
  for (const result of verifier.assertionResults) {
    if (!result.success) {
      continue;
    }
    if (result.assertion.type === "all_text_visible") {
      return {
        type: "text_visible",
        value: result.assertion.values.join(" && "),
      };
    }
    if (result.assertion.type === "any_text_visible") {
      return {
        type: "text_visible",
        value: result.assertion.values[0] ?? "",
      };
    }
    if (result.assertion.type === "text_absent") {
      return {
        type: "text_absent",
        value: result.assertion.value,
      };
    }
  }
  return undefined;
}

function buildNavigatorGoal(args: IosUiGraphNavigatorInput): string {
  if (args?.goal?.trim()) {
    return args.goal.trim();
  }
  const structuredCase = args?.case;
  if (!structuredCase) {
    return "";
  }
  return [
    `测试用例：${structuredCase.title.trim()}`,
    structuredCase.precondition?.trim()
      ? `前置条件（含冷启动恢复）：\n${structuredCase.precondition.trim()}`
      : "",
    `执行步骤：\n${structuredCase.step.trim()}`,
    `预期结果（必须逐条验证）：\n${structuredCase.expected.trim()}`,
  ]
    .filter(Boolean)
    .join("\n\n");
}

function candidateText(
  candidate: TargetedDiscoveryObservation["candidates"][number],
): string {
  return (
    candidate.text ??
    candidate.label ??
    candidate.value ??
    candidate.accessibilityId ??
    ""
  );
}

function selectorMatchesCandidate(
  element: ExperimentElement,
  candidate: TargetedDiscoveryObservation["candidates"][number],
): boolean {
  const selector = element.selector;
  const exactPairs: Array<[string | undefined, string | undefined]> = [
    [selector.accessibilityId, candidate.accessibilityId],
    [selector.label, candidate.label],
    [selector.text, candidate.text],
    [selector.value, candidate.value],
  ];
  const exactMatch = exactPairs.some(
    ([expected, actual]) =>
      Boolean(expected?.trim()) &&
      Boolean(actual?.trim()) &&
      normalized(expected!) === normalized(actual!),
  );
  const roleMatches =
    !selector.role ||
    !candidate.role ||
    normalized(selector.role) === normalized(candidate.role);
  return exactMatch && roleMatches;
}

function normalized(value: string): string {
  return value
    .toLocaleLowerCase()
    .replaceAll(/[\s\u00a0，。、“”"'`~!！?？:：;；._\-<>＜＞〈〉《》›»]+/g, "");
}

function stableId(value: string): boolean {
  return /^[a-z0-9]+(?:[._-][a-z0-9]+)+$/.test(value);
}

function observationEvidencePaths(
  observation: TargetedDiscoveryObservation,
): string[] {
  return [
    observation.screenshotPath,
    observation.uiDumpPath,
    observation.ocrPath,
  ].filter(Boolean);
}

async function writeResult(
  result: IosUiGraphNavigatorResult,
): Promise<IosUiGraphNavigatorResult> {
  setPhase("Report");
  await writeJsonAtomic(result.reportPath, {
    schemaVersion: "ios-ui-graph-navigator-report/v1",
    runId: result.runId,
    status: result.status,
    goal: result.goal,
    stepsUsed: result.stepsUsed,
    evidencePaths: result.evidencePaths,
    failure: result.failure ?? null,
    generatedAt: new Date().toISOString(),
  });
  await writeJsonAtomic(result.resultPath, result);
  logProgress(
    [
      "## iOS UI graph navigator result",
      `- **Status:** ${result.status}`,
      `- **Steps:** ${result.stepsUsed}`,
      `- **Result:** \`${result.resultPath}\``,
    ].join("\n"),
  );
  return result;
}

async function writeFailure(options: {
  outputDir: string;
  graphPath: string;
  resultPath: string;
  runId: string;
  goal: string;
  planOnly: boolean;
  code: string;
  stage: string;
  message: string;
  recoverable: boolean;
  evidencePaths?: readonly string[];
}): Promise<IosUiGraphNavigatorFailureResult> {
  const result: IosUiGraphNavigatorFailureResult = {
    success: false,
    mode: "workflow_failure",
    planOnly: options.planOnly,
    runId: options.runId,
    outputDir: options.outputDir,
    graphPath: options.graphPath,
    resultPath: options.resultPath,
    goal: options.goal,
    failure: {
      code: options.code,
      stage: options.stage,
      message: options.message,
      recoverable: options.recoverable,
      evidencePaths: options.evidencePaths ?? [options.resultPath],
    },
  };
  await writeJsonAtomic(options.resultPath, result);
  logProgress(
    [
      "## iOS UI graph navigator result",
      "- **Status:** blocked",
      `- **Failure:** \`${options.code}\` at ${options.stage}`,
      `- **Message:** ${options.message}`,
      `- **Result:** \`${options.resultPath}\``,
    ].join("\n"),
  );
  return result;
}

function failureCode(stage: string): string {
  return `${safeSegment(stage).toLocaleLowerCase()}_failed`;
}

function setPhase(title: string): void {
  if (getWorkflowContext()) {
    phase(title);
  }
}

function logProgress(message: string): void {
  if (getWorkflowContext()) {
    log(message);
  }
}

function boundedInteger(
  value: number | undefined,
  minimum: number,
  maximum: number,
  fallback: number,
): number {
  if (!Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(maximum, Math.max(minimum, Math.floor(value!)));
}

function unique(values: readonly string[]): string[] {
  return [...new Set(values.filter(Boolean))];
}

function safeSegment(value: string): string {
  const normalizedValue = value
    .trim()
    .replace(/[^A-Za-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return normalizedValue || "unnamed";
}

function timestampForPath(): string {
  return new Date().toISOString().replace(/[:.]/g, "-");
}
