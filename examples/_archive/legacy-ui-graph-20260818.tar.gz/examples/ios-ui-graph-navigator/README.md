# iOS UI Graph Navigator

[简体中文](./README.zh-CN.md)

This Workflow executes arbitrary iOS UI goals through a live
perception → planning → action → verification → learning loop.

It does not require the request to match a pre-recorded Task. The reusable
knowledge is the Graph's Scene, Element, and Operator data; a Task is only an
optional historical shortcut.

## Execution Model

1. Strictly relaunch the app through `xcrun devicectl` and prove the old PID
   exited and a new PID started.
2. Capture a screenshot, UI dump, Vision OCR, and actionable live candidates.
3. Rank possible Scenes from real anchors and visible Elements.
4. Use a deterministic known Operator when the Scene and goal match
   unambiguously.
5. Otherwise ask an Agent to identify the current Scene and choose exactly one
   action from:
   - a real Graph Operator;
   - a real live candidate id.
6. Execute the action and capture the next Observation.
7. A failed action gets one new perception/planning opportunity rather than
   immediately stopping the workflow.
8. The Agent may propose completion, but deterministic code must execute its
   completion Oracle.
9. A separate Agent compiles typed final assertions; deterministic code
   executes those assertions and determines the final verdict.

The Agent cannot invent coordinates, candidate ids, Operator ids, or a PASS.

## Learning

Successful evidence can update the Graph:

- known Operators record success/failure and move through guarded/fast/
  quarantined execution tiers;
- newly observed Scenes and Elements are stored as `candidate`;
- successful live candidate actions may synthesize candidate Operators and a
  candidate Task;
- repeated independent evidence is still required before promotion.

Use `allowLearning: false` to disable all Graph write-back.

## Input

```json
{
  "goal": "从对话页进入相机拍一张照片，并确认预览页标记入口可见",
  "planOnly": true,
  "maxSteps": 12
}
```

Alternatively provide a structured `case` with `title`, `precondition`,
`step`, and `expected`; the Workflow preserves all three semantic segments.

## Plan-only

`planOnly: true`:

- does not reset or mutate the app;
- captures the current UI;
- ranks current Scenes;
- chooses the next constrained action;
- returns `needs_review`, because no on-device business outcome was executed.

```bash
deer-workflow run \
  examples/ios-ui-graph-navigator/workflow.ts \
  --input '{
    "goal": "从对话页进入相机拍一张照片，并确认预览页标记入口可见",
    "planOnly": true
  }'
```

Artifacts are written below
`/tmp/ios_perf-opt/ios-ui-graph-navigator/<runId>/`.

## Result

The Workflow always returns JSON. Business failures are structured results,
not process exceptions.

```json
{
  "success": false,
  "mode": "navigation",
  "status": "needs_review",
  "steps": [],
  "observations": [],
  "actions": [],
  "evidencePaths": []
}
```

Statuses are `pass`, `fail`, `needs_review`, and `blocked`.
