import type {
  ExperimentVerifierEvaluation,
  TargetedDiscoveryAction,
  TargetedDiscoveryObservation,
  TimedExperimentCommand,
} from "../ios-ui-graph-experiment/types";

/** A structured case that can be converted into one navigator goal. */
export interface NavigatorCase {
  readonly case_id?: string | number;
  readonly title: string;
  readonly precondition?: string;
  readonly step: string;
  readonly expected: string;
  readonly priority?: string;
  readonly tags?: readonly string[];
}

/** Input accepted by the step-wise semantic UI navigator. */
export interface IosUiGraphNavigatorInput {
  readonly goal?: string;
  readonly case?: NavigatorCase;
  readonly graphPath?: string;
  readonly projectRoot?: string;
  readonly udid?: string;
  readonly deviceProfileId?: string;
  readonly outputDir?: string;
  readonly runId?: string;
  readonly planOnly?: boolean;
  readonly maxSteps?: number;
  readonly allowLearning?: boolean;
  readonly model?: string;
  readonly agentTimeoutMs?: number;
  readonly appVersion?: string;
}

/** How the current live screen was identified. */
export interface NavigatorPerception {
  readonly sceneId: string | null;
  readonly sceneTitle: string;
  readonly source: "deterministic" | "agent" | "static_graph" | "unknown";
  readonly confidence: number;
  readonly agentUsed: boolean;
  readonly candidateSceneIds: readonly string[];
  readonly reason: string;
}

/** A deterministic completion oracle proposed by the planner. */
export interface NavigatorCompletionOracle {
  readonly type:
    "text_absent" | "text_visible" | "scene_changed" | "region_stable";
  readonly value: string;
}

/** One bounded next-step decision. */
export type NavigatorActionPlan =
  | {
      readonly kind: "known_operator";
      readonly operatorId: string;
      readonly actionType:
        "tap" | "long_press" | "swipe_left" | "swipe_right" | "input_text";
      readonly inputValue?: string;
      readonly reason: string;
      readonly agentUsed: boolean;
    }
  | {
      readonly kind: "candidate";
      readonly candidateId: string;
      readonly actionType: "tap" | "long_press" | "swipe_left" | "swipe_right";
      readonly durationMs: number;
      readonly targetElementTitle: string;
      readonly targetSemanticRole: string;
      readonly operatorTitle: string;
      readonly risk:
        | "navigation"
        | "interaction"
        | "selection"
        | "permission"
        | "mutation"
        | "destructive";
      readonly expectedOutcome: string;
      readonly sceneTitle: string;
      readonly visualTextAnchors: readonly string[];
      readonly reason: string;
      readonly agentUsed: true;
    }
  | {
      readonly kind: "complete";
      readonly oracle: NavigatorCompletionOracle;
      readonly completionEvidence: readonly string[];
      readonly reason: string;
      readonly agentUsed: true;
    }
  | {
      readonly kind: "blocked";
      readonly reason: string;
      readonly agentUsed: boolean;
    };

/** Evidence and outcome for one perception-plan-action cycle. */
export interface NavigatorStepRecord {
  readonly stepIndex: number;
  readonly beforeObservationId: string;
  readonly afterObservationId?: string;
  readonly perception: NavigatorPerception;
  readonly plan: NavigatorActionPlan;
  readonly exitCode?: number;
  readonly command?: readonly string[];
  readonly evidencePaths: readonly string[];
}

/** Final navigator verdict. */
export type NavigatorStatus = "pass" | "fail" | "needs_review" | "blocked";

/** Completed navigator run. */
export interface IosUiGraphNavigatorResult {
  readonly success: boolean;
  readonly mode: "navigation";
  readonly planOnly: boolean;
  readonly status: NavigatorStatus;
  readonly runId: string;
  readonly outputDir: string;
  readonly graphPath: string;
  readonly resultPath: string;
  readonly reportPath: string;
  readonly goal: string;
  readonly stepsUsed: number;
  readonly steps: readonly NavigatorStepRecord[];
  readonly observations: readonly TargetedDiscoveryObservation[];
  readonly actions: readonly TargetedDiscoveryAction[];
  readonly commands: readonly TimedExperimentCommand[];
  readonly completionOracle?: NavigatorCompletionOracle;
  readonly completionEvidence: readonly string[];
  readonly agentVerifier?: ExperimentVerifierEvaluation;
  readonly learnedGraphPatchPath?: string;
  readonly executionLearningPatchPath?: string;
  readonly evidencePaths: readonly string[];
  readonly failure?: {
    readonly code: string;
    readonly stage: string;
    readonly message: string;
    readonly recoverable: boolean;
    readonly evidencePaths: readonly string[];
  };
}

/** Early workflow failure before a normal navigation result can be formed. */
export interface IosUiGraphNavigatorFailureResult {
  readonly success: false;
  readonly mode: "workflow_failure";
  readonly planOnly: boolean;
  readonly runId: string;
  readonly outputDir: string;
  readonly graphPath: string;
  readonly resultPath: string;
  readonly goal: string;
  readonly failure: {
    readonly code: string;
    readonly stage: string;
    readonly message: string;
    readonly recoverable: boolean;
    readonly evidencePaths: readonly string[];
  };
}

/** Every result returned by the navigator handler. */
export type IosUiGraphNavigatorOutput =
  IosUiGraphNavigatorResult | IosUiGraphNavigatorFailureResult;
