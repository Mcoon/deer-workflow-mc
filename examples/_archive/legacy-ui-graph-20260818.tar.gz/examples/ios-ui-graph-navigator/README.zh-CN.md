# iOS UI Graph Navigator

[English](./README.md)

这个 Workflow 使用实时的「感知 → 规划 → 行动 → 验证 → 学习」闭环执行任意 iOS UI
目标。

请求不需要命中一个预录 Task。真正复用的是 Graph 中的 Scene、Element 和 Operator；
Task 只是一条可选的历史快捷路径。

## 执行模型

1. 使用 `xcrun devicectl` 严格重启 App，证明旧 PID 已退出、新 PID 已启动。
2. 采集 screenshot、UI dump、Vision OCR 和当前真实可操作候选。
3. 根据真实锚点和可见 Element 对当前 Scene 候选进行排序。
4. Scene 和目标都足够明确时，直接使用确定性的已知 Operator 快路径。
5. 否则让 Agent 同时理解当前 Scene，并且只能从下面两类真实动作里选一步：
   - Graph 中真实存在的 Operator；
   - 当前屏幕真实存在的 candidate id。
6. 执行动作并重新采集 Observation。
7. 一次动作失败不会立即终止；系统会重新感知和规划，获得一次纠偏机会。
8. Agent 可以提出「目标已完成」，但必须提供可执行 Oracle，并由确定性代码验证。
9. 最终由独立 Agent 编译 typed assertions，再由确定性代码执行并给出 verdict。

Agent 不能生成自由坐标、虚构 candidate/Operator，也不能直接输出 PASS。

## 学习

成功证据可以更新 Graph：

- 已知 Operator 记录成功/失败，按 guarded/fast/quarantined 可信度演进；
- 新观察到的 Scene、Element 首次只写成 `candidate`；
- 真实 candidate 动作成功后，可以合成 candidate Operator 和 candidate Task；
- 仍需独立重复证据才能晋级。

设置 `allowLearning: false` 可以完全关闭 Graph 写回。

## 输入

```json
{
  "goal": "从对话页进入相机拍一张照片，并确认预览页标记入口可见",
  "planOnly": true,
  "maxSteps": 12
}
```

也可以传入结构化 `case`，包含 `title`、`precondition`、`step`、`expected`；
Workflow 会保留三段完整语义。

## Plan-only

`planOnly: true`：

- 不重启、不修改 App；
- 只采集当前 UI；
- 排序当前 Scene；
- 选择下一步受约束动作；
- 返回 `needs_review`，因为尚未执行和验证真实业务结果。

```bash
deer-workflow run \
  examples/ios-ui-graph-navigator/workflow.ts \
  --input '{
    "goal": "从对话页进入相机拍一张照片，并确认预览页标记入口可见",
    "planOnly": true
  }'
```

产物统一落在
`/tmp/ios_perf-opt/ios-ui-graph-navigator/<runId>/`。

## 结果

Workflow 始终返回 JSON。业务失败是结构化结果，不会抛成进程异常。

```json
{
  "success": false,
  "mode": "navigation",
  "status": "needs_review",
  "steps": [],
  "observations": [],
  "actions": [],
  "evidencePaths": []
}
```

状态包括 `pass`、`fail`、`needs_review` 和 `blocked`。
