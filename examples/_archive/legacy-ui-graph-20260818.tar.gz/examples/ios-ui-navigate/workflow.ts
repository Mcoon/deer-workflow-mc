import { mkdir, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";

import { phase } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  DEFAULT_ARTIFACT_ROOT,
  assetLayout,
  buildMobilecliActionCommand,
  buildMobilecliPreflightCommand,
  buildMobilecliScreenshotCommand,
  buildMobilecliUiDumpCommand,
  fingerprintUi,
  loadControls,
  loadDeviceProfiles,
  loadPage,
  matchUiElement,
  parseUiDump,
  planNavigation,
  readJson,
  resolvePageReference,
  resolveTapPoint,
  runCommand,
  writeJsonAtomic,
} from "../ios-regression-kit";

import type {
  DeviceProfile,
  NavigationCategory,
  NavigationGraph,
  NavigationGraphEdge,
  NavigationPlan,
  PageIndex,
  UiControl,
  UiElement,
} from "../ios-regression-kit/types";
import type {
  IosUiNavigateInput,
  IosUiNavigateResult,
  NavigationEdgeExecution,
} from "./types";

const DEFAULT_CATEGORIES: NavigationCategory[] = ["navigation"];

export const meta = {
  name: "ios-ui-navigate",
  description:
    "Plans and executes safe cold-start navigation through a compiled iOS UI graph.",
  phases: [
    { title: "Load" },
    { title: "Resolve" },
    { title: "Plan" },
    { title: "Execute" },
    { title: "Report" },
  ],
  exampleArgs: {
    bundleId: "com.bot.doubao",
    targetPage: "图片最终发送确认页",
    allowCategories: ["navigation", "selection"],
    planOnly: true,
  },
};

export default async function iosUiNavigate(
  args: IosUiNavigateInput,
): Promise<IosUiNavigateResult> {
  const input = normalizeInput(args);
  const layout = assetLayout(input.bundleId, input.assetRoot);
  await mkdir(input.outputDir, { recursive: true });

  phase("Load");
  const [graph, pageIndex, controlsCollection, profiles] = await Promise.all([
    readJson<NavigationGraph>(input.graphPath),
    readJson<PageIndex>(input.pageIndexPath),
    loadControls(layout.controlsPath),
    loadDeviceProfiles(layout.deviceProfilesPath),
  ]);
  if (
    graph.bundleId !== input.bundleId ||
    pageIndex.bundleId !== input.bundleId
  ) {
    throw new Error("Navigation graph bundleId does not match the request.");
  }

  phase("Resolve");
  const targetPageId = resolveTargetPageId(input, pageIndex);
  log(
    [
      "## Resolving iOS navigation target",
      `- **Target:** \`${input.targetPageId || input.targetPage}\``,
      `- **Resolved pageId:** \`${targetPageId}\``,
      `- **Plan only:** ${input.planOnly ? "yes" : "no"}`,
    ].join("\n"),
  );

  phase("Plan");
  const plan = planNavigation({
    graph,
    sourcePageId: graph.rootPageId,
    targetPageId,
    allowCategories: input.allowCategories,
  });
  const planPath = join(input.outputDir, "navigation-plan.json");
  await writeJsonAtomic(planPath, plan);
  log(
    [
      `## Navigation plan · ${plan.edges.length} edge(s)`,
      ...plan.edges.map(
        (edge) =>
          `- \`${edge.fromPageId}\` → \`${edge.toPageId}\` · ${edge.category} · ${edge.action.type}`,
      ),
    ].join("\n"),
  );

  phase("Execute");
  const executions = input.planOnly
    ? []
    : await executeNavigationPlan({
        plan,
        input,
        layout,
        controls: controlsCollection.controls,
        profiles: profiles.profiles,
      });

  phase("Report");
  const success =
    input.planOnly ||
    (executions.length === plan.edges.length &&
      executions.every((execution) => execution.success));
  const resultPath = join(input.outputDir, "navigation-result.json");
  const result: IosUiNavigateResult = {
    success,
    planOnly: input.planOnly,
    outputDir: input.outputDir,
    targetPageId,
    planPath,
    resultPath,
    plan,
    executions,
  };
  await writeJsonAtomic(resultPath, result);
  log(
    [
      "## Navigation result",
      `- **Status:** ${success ? "PASS" : "FAIL"}`,
      `- **Plan:** \`${planPath}\``,
      `- **Result:** \`${resultPath}\``,
    ].join("\n"),
  );
  return result;
}

interface NormalizedInput {
  projectRoot: string;
  udid: string;
  bundleId: string;
  assetRoot?: string;
  graphPath: string;
  pageIndexPath: string;
  targetPageId: string;
  targetPage: string;
  allowCategories: NavigationCategory[];
  planOnly: boolean;
  deviceProfileId?: string;
  outputDir: string;
  mobilecliPreflightPath?: string;
}

function normalizeInput(args: IosUiNavigateInput): NormalizedInput {
  if (!args) {
    throw new TypeError("iOS UI Navigate requires input arguments.");
  }
  const bundleId = requiredText(args.bundleId, "bundleId");
  const layout = assetLayout(bundleId, args.assetRoot);
  const planOnly = args.planOnly !== false;
  const udid = args.udid?.trim() || "";
  if (!planOnly && !udid) {
    throw new TypeError("iOS UI Navigate requires udid when planOnly=false.");
  }
  if (!args.targetPageId?.trim() && !args.targetPage?.trim()) {
    throw new TypeError("iOS UI Navigate requires targetPageId or targetPage.");
  }
  const runId = safeSegment(args.runId?.trim() || timestampForPath());
  return {
    projectRoot: resolve(args.projectRoot?.trim() || process.cwd()),
    udid,
    bundleId,
    assetRoot: args.assetRoot?.trim() || undefined,
    graphPath: resolve(args.graphPath?.trim() || layout.graphPath),
    pageIndexPath: resolve(args.pageIndexPath?.trim() || layout.pageIndexPath),
    targetPageId: args.targetPageId?.trim() || "",
    targetPage: args.targetPage?.trim() || "",
    allowCategories: [...new Set(args.allowCategories ?? DEFAULT_CATEGORIES)],
    planOnly,
    deviceProfileId: args.deviceProfileId?.trim() || undefined,
    outputDir: resolve(
      args.outputDir?.trim() ||
        join(DEFAULT_ARTIFACT_ROOT, "ios-ui-navigate", runId),
    ),
    mobilecliPreflightPath: args.mobilecliPreflightPath?.trim() || undefined,
  };
}

function resolveTargetPageId(
  input: NormalizedInput,
  pageIndex: PageIndex,
): string {
  if (input.targetPageId) {
    const resolution = resolvePageReference(input.targetPageId, pageIndex);
    if (resolution.pageId) {
      return resolution.pageId;
    }
    throw new Error(
      `Navigation target pageId could not be resolved: ${input.targetPageId}. Candidates: ${resolution.candidates.join(", ") || "none"}.`,
    );
  }
  const resolution = resolvePageReference(input.targetPage, pageIndex);
  if (resolution.pageId) {
    return resolution.pageId;
  }
  throw new Error(
    `Navigation target is ${resolution.reason}: ${input.targetPage}. Candidates: ${resolution.candidates.join(", ") || "none"}.`,
  );
}

async function executeNavigationPlan(options: {
  plan: NavigationPlan;
  input: NormalizedInput;
  layout: ReturnType<typeof assetLayout>;
  controls: readonly UiControl[];
  profiles: readonly DeviceProfile[];
}): Promise<NavigationEdgeExecution[]> {
  const profile = chooseDeviceProfile(
    options.profiles,
    options.input.deviceProfileId,
  );
  const preflight = await runCommand(
    buildMobilecliPreflightCommand(options.input.mobilecliPreflightPath),
    options.input.projectRoot,
  );
  await writeFile(
    join(options.input.outputDir, "mobilecli-preflight.stdout.txt"),
    preflight.stdout,
    "utf8",
  );
  await writeFile(
    join(options.input.outputDir, "mobilecli-preflight.stderr.txt"),
    preflight.stderr,
    "utf8",
  );
  if (preflight.exitCode !== 0) {
    throw new Error(`mobilecli preflight failed: ${preflight.exitCode}.`);
  }

  const executions: NavigationEdgeExecution[] = [];
  let currentPageId = options.plan.sourcePageId;
  let currentElements: UiElement[] = [];

  for (const [index, edge] of options.plan.edges.entries()) {
    const edgeDirectory = join(
      options.input.outputDir,
      "edges",
      `${String(index + 1).padStart(2, "0")}-${safeSegment(edge.edgeId)}`,
    );
    await mkdir(edgeDirectory, { recursive: true });
    const execution = await executeEdge({
      edge,
      edgeDirectory,
      bundleId: options.input.bundleId,
      udid: options.input.udid,
      controls: options.controls,
      profile,
      pagesDirectory: options.layout.pagesDirectory,
      currentPageId,
      currentElements,
    });
    executions.push(execution.result);
    if (!execution.result.success) {
      break;
    }
    currentPageId = edge.toPageId;
    currentElements = execution.elements;
  }
  return executions;
}

async function executeEdge(options: {
  edge: NavigationGraphEdge;
  edgeDirectory: string;
  bundleId: string;
  udid: string;
  controls: readonly UiControl[];
  profile: DeviceProfile;
  pagesDirectory: string;
  currentPageId: string;
  currentElements: readonly UiElement[];
}): Promise<{ result: NavigationEdgeExecution; elements: UiElement[] }> {
  if (options.edge.fromPageId !== options.currentPageId) {
    return {
      result: failedEdge(
        options.edge,
        `Expected current page ${options.edge.fromPageId}, got ${options.currentPageId}.`,
      ),
      elements: [...options.currentElements],
    };
  }

  let actionSource: string | undefined;
  let command: string[];
  if (options.edge.action.type === "cold_launch") {
    const bundleId = options.edge.action.bundleId ?? options.bundleId;
    const terminate = await runCommand(
      buildMobilecliActionCommand({
        action: {
          actionId: `${options.edge.edgeId}-terminate`,
          type: "terminate_app",
          bundleId,
        },
        udid: options.udid,
        bundleId,
      }),
    );
    await writeFile(
      join(options.edgeDirectory, "terminate.stdout.txt"),
      terminate.stdout,
      "utf8",
    );
    await writeFile(
      join(options.edgeDirectory, "terminate.stderr.txt"),
      terminate.stderr,
      "utf8",
    );
    if (terminate.exitCode !== 0 && !isAlreadyTerminated(terminate)) {
      return {
        result: failedEdge(
          options.edge,
          `Cold-start terminate failed: ${terminate.stderr || terminate.stdout}.`,
        ),
        elements: [],
      };
    }
    command = buildMobilecliActionCommand({
      action: {
        actionId: `${options.edge.edgeId}-launch`,
        type: "launch_app",
        bundleId,
      },
      udid: options.udid,
      bundleId,
    });
    actionSource = "cold_launch";
  } else {
    const before = await verifyPage({
      pageId: options.edge.fromPageId,
      pagesDirectory: options.pagesDirectory,
      controls: options.controls,
      elements: options.currentElements,
      udid: options.udid,
      outputDirectory: options.edgeDirectory,
      prefix: "before",
    });
    if (!before.success) {
      return {
        result: failedEdge(options.edge, before.issue),
        elements: before.elements,
      };
    }
    const resolved = resolveTapPoint({
      action: {
        actionId: options.edge.edgeId,
        type: "tap",
        pageId: options.edge.fromPageId,
        target: { controlId: options.edge.action.controlId },
      },
      controls: options.controls,
      elements: before.elements,
      profile: options.profile,
      currentPageId: options.edge.fromPageId,
    });
    if (!resolved.point) {
      return {
        result: failedEdge(options.edge, resolved.issue ?? "Tap unresolved."),
        elements: before.elements,
      };
    }
    command = buildMobilecliActionCommand({
      action: {
        actionId: options.edge.edgeId,
        type: "tap",
        pageId: options.edge.fromPageId,
        target: { controlId: options.edge.action.controlId },
      },
      udid: options.udid,
      bundleId: options.bundleId,
      tapPoint: resolved.point,
    });
    actionSource = resolved.source;
  }

  const action = await runCommand(command);
  await writeFile(
    join(options.edgeDirectory, "action.stdout.txt"),
    action.stdout,
    "utf8",
  );
  await writeFile(
    join(options.edgeDirectory, "action.stderr.txt"),
    action.stderr,
    "utf8",
  );
  if (action.exitCode !== 0) {
    return {
      result: {
        ...failedEdge(
          options.edge,
          action.stderr || action.stdout || "Navigation action failed.",
        ),
        command,
        actionSource,
      },
      elements: [],
    };
  }
  if (options.edge.settleMs > 0) {
    await Bun.sleep(options.edge.settleMs);
  }
  const after = await verifyPage({
    pageId: options.edge.toPageId,
    pagesDirectory: options.pagesDirectory,
    controls: options.controls,
    elements: [],
    udid: options.udid,
    outputDirectory: options.edgeDirectory,
    prefix: "after",
  });
  return {
    result: {
      edgeId: options.edge.edgeId,
      fromPageId: options.edge.fromPageId,
      toPageId: options.edge.toPageId,
      category: options.edge.category,
      success: after.success,
      actionSource,
      command,
      issue: after.issue,
      screenshotPath: after.screenshotPath,
      uiDumpPath: after.uiDumpPath,
    },
    elements: after.elements,
  };
}

async function verifyPage(options: {
  pageId: string;
  pagesDirectory: string;
  controls: readonly UiControl[];
  elements: readonly UiElement[];
  udid: string;
  outputDirectory: string;
  prefix: string;
}): Promise<{
  success: boolean;
  issue?: string;
  elements: UiElement[];
  screenshotPath: string;
  uiDumpPath: string;
}> {
  const screenshotPath = join(
    options.outputDirectory,
    `${options.prefix}-${safeSegment(options.pageId)}.png`,
  );
  const uiDumpPath = join(
    options.outputDirectory,
    `${options.prefix}-${safeSegment(options.pageId)}.ui.json`,
  );
  let elements = [...options.elements];
  if (elements.length === 0) {
    const screenshot = await runCommand(
      buildMobilecliScreenshotCommand(options.udid, screenshotPath),
    );
    const dump = await runCommand(buildMobilecliUiDumpCommand(options.udid));
    await writeFile(uiDumpPath, dump.stdout, "utf8");
    if (screenshot.exitCode !== 0 || dump.exitCode !== 0) {
      return {
        success: false,
        issue: `Page evidence capture failed: screenshot=${screenshot.exitCode}, uiDump=${dump.exitCode}.`,
        elements: [],
        screenshotPath,
        uiDumpPath,
      };
    }
    elements = parseUiDump(dump.stdout);
  } else {
    await writeFile(uiDumpPath, JSON.stringify({ cached: true }), "utf8");
  }

  const page = await loadPage(options.pagesDirectory, options.pageId);
  if (!page) {
    return {
      success: false,
      issue: `Page asset is missing: ${options.pageId}.`,
      elements,
      screenshotPath,
      uiDumpPath,
    };
  }
  const anchors = page.anchorControlIds
    .map((controlId) =>
      options.controls.find(
        (control) =>
          control.controlId === controlId && control.pageId === options.pageId,
      ),
    )
    .filter((control): control is UiControl => control !== undefined);
  const anchorsMatch =
    anchors.length > 0 &&
    anchors.every((control) => matchUiElement(elements, control.selector));
  const fingerprintMatches = fingerprintUi(elements) === page.fingerprint;
  return {
    success: anchorsMatch || fingerprintMatches,
    issue:
      anchorsMatch || fingerprintMatches
        ? undefined
        : `Current UI does not match page ${options.pageId}.`,
    elements,
    screenshotPath,
    uiDumpPath,
  };
}

function failedEdge(
  edge: NavigationGraphEdge,
  issue: string | undefined,
): NavigationEdgeExecution {
  return {
    edgeId: edge.edgeId,
    fromPageId: edge.fromPageId,
    toPageId: edge.toPageId,
    category: edge.category,
    success: false,
    issue: issue || "Unknown navigation failure.",
  };
}

function isAlreadyTerminated(result: {
  stdout: string;
  stderr: string;
}): boolean {
  return /not running|not found|already terminated|no matching process/i.test(
    `${result.stdout}\n${result.stderr}`,
  );
}

function chooseDeviceProfile(
  profiles: readonly DeviceProfile[],
  requestedId?: string,
): DeviceProfile {
  const profile = requestedId
    ? profiles.find((candidate) => candidate.profileId === requestedId)
    : profiles[0];
  if (!profile) {
    throw new Error(
      requestedId
        ? `Device profile does not exist: ${requestedId}.`
        : "No device profile is available.",
    );
  }
  return profile;
}

function requiredText(value: string | undefined, name: string): string {
  const trimmed = value?.trim();
  if (!trimmed) {
    throw new TypeError(`iOS UI Navigate requires ${name}.`);
  }
  return trimmed;
}

function safeSegment(value: string): string {
  return (
    value.replaceAll(/[^A-Za-z0-9_.-]+/g, "-").replaceAll(/^-+|-+$/g, "") ||
    "item"
  );
}

function timestampForPath(): string {
  return new Date()
    .toISOString()
    .replaceAll(/[^0-9]/g, "")
    .slice(0, 14);
}
