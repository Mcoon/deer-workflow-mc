# iOS UI Navigate

Plans and executes safe navigation from `cold_start` through `graph.json`.

The default is `planOnly: true` and only `navigation` edges are allowed.
Selection, permission, and mutation edges require explicit categories.
