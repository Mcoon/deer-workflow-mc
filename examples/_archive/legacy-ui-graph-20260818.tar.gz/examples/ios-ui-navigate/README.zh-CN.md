# iOS UI Navigate

这个 Workflow 从 `cold_start` 出发，读取 `graph.json` 规划并执行安全页面导航。

只规划：

```bash
deer-workflow run \
  /Users/bytedance/Documents/deer-workflow-mc/examples/ios-ui-navigate/workflow.ts \
  --input '{
    "bundleId": "com.bot.doubao",
    "targetPage": "图片最终发送确认页",
    "allowCategories": ["navigation", "selection"],
    "planOnly": true
  }'
```

真机执行：

```bash
deer-workflow run \
  /Users/bytedance/Documents/deer-workflow-mc/examples/ios-ui-navigate/workflow.ts \
  --input '{
    "projectRoot": "/Users/bytedance/Documents/BDWorkSpace/Dbao/flow_iOS",
    "udid": "00008030-001A286A2229802E",
    "bundleId": "com.bot.doubao",
    "targetPageId": "image_send_ready",
    "allowCategories": ["navigation", "selection"],
    "planOnly": false,
    "deviceProfileId": "iphone-414x896-portrait"
  }'
```

默认只允许 `navigation`。`selection`、`permission`、`mutation` 必须显式允许。
规划器只消费 `active` 边，每一步都验证页面，并记录点击来源是实时 UI dump 还是
device binding。
