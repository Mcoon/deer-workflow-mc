import type {
  NavigationCategory,
  NavigationPlan,
} from "../ios-regression-kit/types";

export interface IosUiNavigateInput {
  readonly projectRoot?: string;
  readonly udid?: string;
  readonly bundleId: string;
  readonly assetRoot?: string;
  readonly graphPath?: string;
  readonly pageIndexPath?: string;
  readonly targetPageId?: string;
  readonly targetPage?: string;
  readonly allowCategories?: readonly NavigationCategory[];
  readonly planOnly?: boolean;
  readonly deviceProfileId?: string;
  readonly runId?: string;
  readonly outputDir?: string;
  readonly mobilecliPreflightPath?: string;
}

export interface NavigationEdgeExecution {
  readonly edgeId: string;
  readonly fromPageId: string;
  readonly toPageId: string;
  readonly category: NavigationCategory;
  readonly success: boolean;
  readonly actionSource?: string;
  readonly command?: readonly string[];
  readonly issue?: string;
  readonly screenshotPath?: string;
  readonly uiDumpPath?: string;
}

export interface IosUiNavigateResult {
  readonly success: boolean;
  readonly planOnly: boolean;
  readonly outputDir: string;
  readonly targetPageId: string;
  readonly planPath: string;
  readonly resultPath: string;
  readonly plan: NavigationPlan;
  readonly executions: readonly NavigationEdgeExecution[];
}
