# iOS UI Discovery

这个 Workflow 使用 `mobilecli` 按预先声明的 route 串行探索 iOS App，并把页面、
控件、设备坐标空间和页面跳转沉淀为长期可复用资产。

它不使用 AI 或 Midscene 主导点击。AI 不参与设备执行；所有 `tap` 都必须来自已有
`controlId`、显式坐标或归一化坐标。

## 运行

```bash
deer-workflow run /Users/bytedance/Documents/deer-workflow-mc/examples/ios-ui-discovery/workflow.ts \
  --input '{
    "projectRoot": "/Users/bytedance/Documents/BDWorkSpace/Dbao/flow_iOS",
    "udid": "00008030-001A286A2229802E",
    "bundleId": "com.bot.doubao",
    "appName": "豆包",
    "controlHints": [
      {
        "pageId": "home",
        "controlId": "home.chat_entry",
        "title": "测试会话入口",
        "selector": { "label": "测试会话" }
      }
    ],
    "routes": [
      {
        "routeId": "launch-home",
        "title": "启动并采集首页",
        "actions": [
          { "actionId": "launch", "type": "launch_app" },
          {
            "actionId": "home",
            "type": "snapshot",
            "pageId": "home",
            "title": "首页",
            "anchorControlIds": ["home.chat_entry"]
          }
        ]
      }
    ]
  }'
```

第一次只能从 `launch_app`、显式坐标和页面 `snapshot` 开始。关键控件被采集为
`controlId` 后，后续 route 可以引用它：

```json
{
  "actionId": "open-chat",
  "type": "tap",
  "pageId": "home",
  "target": { "controlId": "home.chat_entry" },
  "assertBefore": [{ "type": "page", "pageId": "home" }]
}
```

## 资产

运行证据写入：

```text
/tmp/ios_perf-opt/ios-ui-discovery/<run_id>/
```

可复用资产默认写入：

```text
/Users/bytedance/Documents/BDWorkSpace/ios-perf-optimizer/assets/app-regression/<bundle_id>/
  manifest.json
  ui-map/
    pages/
    controls.json
    transitions.json
    device-profiles.json
  baselines/
    pages/<device_profile>/
```

`device-profiles.json` 将截图像素尺寸和 `mobilecli` 交互坐标空间分开保存。
控件优先用当前 UI dump 的 bounds 定位；只有页面已验证且 UI dump 无法命中时，
才允许使用同一设备 profile 的归一化坐标 binding。

## 限制

- 同一设备上的 `mobilecli` 操作严格串行。
- 自动发现的控件 ID 适合建立初始覆盖，核心业务控件应通过 `controlHints` 固化为
  稳定 ID。
- UI dump 无法唯一匹配时不会猜测候选控件。
- 页面或控件尚未探索时，应先补 discovery route，再生成回归 case。
