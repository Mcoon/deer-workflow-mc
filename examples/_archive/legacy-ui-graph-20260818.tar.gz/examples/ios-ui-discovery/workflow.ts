import { copyFile, mkdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";

import { phase } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  DEFAULT_ARTIFACT_ROOT,
  buildMobilecliActionCommand,
  buildMobilecliDeviceInfoCommand,
  buildMobilecliPreflightCommand,
  buildMobilecliScreenshotCommand,
  buildMobilecliUiDumpCommand,
  ensureAssetLayout,
  fingerprintUi,
  loadControls,
  loadDeviceProfiles,
  makeControl,
  matchUiElement,
  mergeControls,
  parseUiDump,
  renderRegressionHtml,
  resolveTapPoint,
  runCommand,
  writeJsonAtomic,
} from "../ios-regression-kit";

import type { AssetLayout } from "../ios-regression-kit";
import type {
  DeviceProfile,
  DeviceProfileCollection,
  RegressionAction,
  UiControl,
  UiControlCollection,
  UiElement,
  UiPage,
  UiTransition,
  UiTransitionCollection,
} from "../ios-regression-kit/types";
import type {
  IosUiDiscoveryInput,
  IosUiDiscoveryResult,
  UiControlHint,
  UiDiscoveryRouteResult,
} from "./types";

const DEFAULT_SETTLE_MS = 700;

export const meta = {
  name: "ios-ui-discovery",
  description:
    "Collects deterministic iOS screenshots, UI dumps, controls, and page transitions with mobilecli.",
  phases: [
    { title: "Prepare" },
    { title: "Preflight" },
    { title: "Explore" },
    { title: "Persist" },
    { title: "Report" },
  ],
  exampleArgs: {
    udid: "00008030-001A286A2229802E",
    bundleId: "com.bot.doubao",
    routes: [
      {
        routeId: "launch-home",
        title: "Launch and capture home",
        actions: [
          { actionId: "launch", type: "launch_app" },
          {
            actionId: "home",
            type: "snapshot",
            pageId: "home",
            title: "首页",
          },
        ],
      },
    ],
  },
};

export default async function iosUiDiscovery(
  args: IosUiDiscoveryInput,
): Promise<IosUiDiscoveryResult> {
  const input = normalizeInput(args);

  phase("Prepare");
  await mkdir(input.outputDir, { recursive: true });
  const { layout } = await ensureAssetLayout({
    bundleId: input.bundleId,
    assetRoot: input.assetRoot,
    appName: input.appName,
  });
  const controlCollection = await loadControls(layout.controlsPath);
  const profileCollection = await loadDeviceProfiles(layout.deviceProfilesPath);
  log(
    [
      "## Preparing iOS UI discovery",
      `- **Bundle:** \`${input.bundleId}\``,
      `- **Device:** \`${input.udid}\``,
      `- **Routes:** ${input.routes.length}`,
      `- **Run artifacts:** \`${input.outputDir}\``,
      `- **Reusable assets:** \`${layout.appRoot}\``,
    ].join("\n"),
  );

  phase("Preflight");
  const preflightCommand = buildMobilecliPreflightCommand(
    input.mobilecliPreflightPath,
  );
  const preflight = await runCommand(preflightCommand, input.projectRoot);
  await writeFile(
    join(input.outputDir, "mobilecli-preflight.stdout.txt"),
    preflight.stdout,
    "utf8",
  );
  await writeFile(
    join(input.outputDir, "mobilecli-preflight.stderr.txt"),
    preflight.stderr,
    "utf8",
  );
  if (preflight.exitCode !== 0) {
    throw new Error(
      `mobilecli preflight failed with exit code ${preflight.exitCode}.`,
    );
  }
  const profileScreenshotPath = join(input.outputDir, "device-profile.png");
  const profileScreenshot = await runCommand(
    buildMobilecliScreenshotCommand(input.udid, profileScreenshotPath),
    input.projectRoot,
  );
  if (profileScreenshot.exitCode !== 0) {
    throw new Error("Unable to capture the device viewport for UI discovery.");
  }
  const screenshotViewport = await readPngSize(profileScreenshotPath);
  const deviceInfo = await runCommand(
    buildMobilecliDeviceInfoCommand(input.udid),
    input.projectRoot,
  );
  await writeFile(
    join(input.outputDir, "device-info.json"),
    deviceInfo.stdout || deviceInfo.stderr,
    "utf8",
  );
  const profileUiDumpPath = join(input.outputDir, "device-profile.ui.json");
  const profileUiDump = await runCommand(
    buildMobilecliUiDumpCommand(input.udid),
    input.projectRoot,
  );
  await writeFile(profileUiDumpPath, profileUiDump.stdout, "utf8");
  if (profileUiDump.exitCode !== 0) {
    throw new Error("Unable to capture the device coordinate space.");
  }
  const profileElements = parseUiDump(profileUiDump.stdout);
  const coordinateViewport =
    deriveCoordinateViewport(profileElements) ??
    parseDeviceInfoViewport(deviceInfo.stdout) ??
    inferCoordinateViewportFromScreenshot(screenshotViewport, profileElements);
  const profile = buildDeviceProfile(
    input,
    profileCollection,
    screenshotViewport,
    coordinateViewport,
  );

  phase("Explore");
  const pages: UiPage[] = [];
  const discoveredControls: UiControl[] = [];
  const transitions: UiTransition[] = [];
  const routeResults: UiDiscoveryRouteResult[] = [];
  let controls = [...controlCollection.controls];

  for (const route of input.routes) {
    const routeDirectory = join(input.outputDir, safeSegment(route.routeId));
    await mkdir(routeDirectory, { recursive: true });
    const routePages: string[] = [];
    const issues: string[] = [];
    let currentPageId: string | undefined;
    let previousPageId: string | undefined;
    let pendingTransition:
      { actionId: string; controlId?: string; fromPageId: string } | undefined;

    for (const [index, action] of route.actions.entries()) {
      if (action.type === "snapshot") {
        const captured = await capturePage({
          action,
          bundleId: input.bundleId,
          routeDirectory,
          index,
          udid: input.udid,
          profile,
          controlHints: input.controlHints,
          autoDiscoverControls: input.autoDiscoverControls,
          layout,
        });
        pages.push(captured.page);
        discoveredControls.push(...captured.controls);
        controls = mergeControls(controls, captured.controls);
        routePages.push(captured.page.pageId);
        previousPageId = currentPageId;
        currentPageId = captured.page.pageId;
        if (pendingTransition) {
          transitions.push({
            schemaVersion: "ios-ui-transition/v1",
            transitionId: `${pendingTransition.fromPageId}-${pendingTransition.actionId}-${currentPageId}`,
            fromPageId: pendingTransition.fromPageId,
            toPageId: currentPageId,
            actionId: pendingTransition.actionId,
            controlId: pendingTransition.controlId,
            observedAt: new Date().toISOString(),
          });
          pendingTransition = undefined;
        }
        continue;
      }

      const execution = await executeAction({
        action,
        bundleId: input.bundleId,
        controls,
        currentPageId,
        index,
        profile,
        routeDirectory,
        udid: input.udid,
      });
      if (!execution.success) {
        issues.push(execution.issue);
        break;
      }
      if (currentPageId && isTransitionTrigger(action)) {
        pendingTransition = transitionFromAction(currentPageId, action);
      }
      if (action.type === "launch_app" || action.type === "terminate_app") {
        previousPageId = currentPageId;
        currentPageId = undefined;
      }
      if (action.type !== "wait" && input.settleMs > 0) {
        await Bun.sleep(input.settleMs);
      }
    }

    routeResults.push({
      routeId: route.routeId,
      title: route.title,
      success: issues.length === 0,
      pages: routePages,
      issues,
    });
    log(
      `- ${issues.length === 0 ? "Captured" : "Stopped"} **${route.title}** · ${routePages.length} page(s)${previousPageId ? ` · from \`${previousPageId}\`` : ""}`,
    );
  }

  phase("Persist");
  const now = new Date().toISOString();
  const mergedControls = mergeControls(
    controlCollection.controls,
    discoveredControls,
  );
  const updatedControlCollection: UiControlCollection = {
    schemaVersion: "ios-ui-controls/v1",
    bundleId: input.bundleId,
    updatedAt: now,
    controls: mergedControls,
  };
  const updatedTransitions = mergeTransitions(
    await readTransitions(layout.transitionsPath, input.bundleId),
    transitions,
  );
  const updatedProfiles = mergeProfiles(
    profileCollection,
    profile,
    input.bundleId,
  );
  await Promise.all([
    writeJsonAtomic(layout.controlsPath, updatedControlCollection),
    writeJsonAtomic(layout.transitionsPath, updatedTransitions),
    writeJsonAtomic(layout.deviceProfilesPath, updatedProfiles),
  ]);

  phase("Report");
  const reportPath = join(input.outputDir, "ui-discovery-report.html");
  const report = renderRegressionHtml({
    title: "iOS UI Discovery",
    subtitle:
      "mobilecli deterministic exploration result. Reusable UI assets are versioned separately from run artifacts.",
    summary: [
      { label: "Routes", value: String(routeResults.length) },
      { label: "Pages", value: String(pages.length) },
      { label: "Controls", value: String(mergedControls.length) },
      { label: "Transitions", value: String(transitions.length) },
    ],
    rows: routeResults.map((route) => ({
      id: route.routeId,
      title: route.title,
      verdict: route.success ? "pass" : "blocked",
      details:
        route.issues.join(" ") ||
        `Captured: ${route.pages.join(", ") || "none"}`,
    })),
  });
  await writeFile(reportPath, report, "utf8");
  await writeJsonAtomic(join(input.outputDir, "summary.json"), {
    schemaVersion: "ios-ui-discovery-result/v1",
    success: routeResults.every((route) => route.success),
    bundleId: input.bundleId,
    deviceProfile: profile,
    pages: pages.map((page) => page.pageId),
    routeResults,
    assetPaths: {
      manifestPath: layout.manifestPath,
      controlsPath: layout.controlsPath,
      transitionsPath: layout.transitionsPath,
      deviceProfilesPath: layout.deviceProfilesPath,
    },
  });

  return {
    success: routeResults.every((route) => route.success),
    outputDir: input.outputDir,
    assetRoot: layout.assetRoot,
    appAssetRoot: layout.appRoot,
    manifestPath: layout.manifestPath,
    controlsPath: layout.controlsPath,
    transitionsPath: layout.transitionsPath,
    deviceProfilesPath: layout.deviceProfilesPath,
    pages,
    controls: mergedControls,
    transitions,
    deviceProfile: profile,
    routes: routeResults,
    reportPath,
  };
}

interface NormalizedInput {
  projectRoot: string;
  udid: string;
  bundleId: string;
  appName?: string;
  outputDir: string;
  assetRoot?: string;
  mobilecliPreflightPath?: string;
  routes: IosUiDiscoveryInput["routes"];
  controlHints: readonly UiControlHint[];
  settleMs: number;
  autoDiscoverControls: boolean;
  deviceProfile: NonNullable<IosUiDiscoveryInput["deviceProfile"]>;
}

function normalizeInput(args: IosUiDiscoveryInput): NormalizedInput {
  if (!args) {
    throw new TypeError("iOS UI Discovery requires input arguments.");
  }
  const udid = requiredText(args.udid, "udid");
  const bundleId = requiredText(args.bundleId, "bundleId");
  if (!args.routes?.length) {
    throw new TypeError("iOS UI Discovery requires at least one route.");
  }
  const runId = safeSegment(args.runId?.trim() || timestampForPath());
  return {
    projectRoot: resolve(args.projectRoot?.trim() || process.cwd()),
    udid,
    bundleId,
    appName: args.appName?.trim() || undefined,
    outputDir: resolve(
      args.outputDir?.trim() ||
        join(DEFAULT_ARTIFACT_ROOT, "ios-ui-discovery", runId),
    ),
    assetRoot: args.assetRoot?.trim() || undefined,
    mobilecliPreflightPath: args.mobilecliPreflightPath?.trim() || undefined,
    routes: args.routes,
    controlHints: args.controlHints ?? [],
    settleMs: boundedInteger(args.settleMs, 0, 10000, DEFAULT_SETTLE_MS),
    autoDiscoverControls: args.autoDiscoverControls !== false,
    deviceProfile: args.deviceProfile ?? {},
  };
}

function buildDeviceProfile(
  input: NormalizedInput,
  existing: DeviceProfileCollection,
  screenshotViewport: { width: number; height: number } | null,
  coordinateViewport: { width: number; height: number } | null,
): DeviceProfile {
  const requestedId = input.deviceProfile.profileId?.trim();
  const previous = requestedId
    ? existing.profiles.find((candidate) => candidate.profileId === requestedId)
    : undefined;
  const viewportWidth =
    input.deviceProfile.viewportWidth ??
    coordinateViewport?.width ??
    previous?.viewportWidth;
  const viewportHeight =
    input.deviceProfile.viewportHeight ??
    coordinateViewport?.height ??
    previous?.viewportHeight;
  if (!viewportWidth || !viewportHeight) {
    throw new Error(
      "Unable to determine the device viewport. Provide deviceProfile viewportWidth/viewportHeight.",
    );
  }
  const profileId =
    requestedId ||
    safeSegment(
      [
        input.deviceProfile.model || "iphone",
        viewportWidth,
        viewportHeight,
        input.deviceProfile.orientation || "portrait",
      ].join("-"),
    );
  const matchedPrevious =
    previous ??
    existing.profiles.find((candidate) => candidate.profileId === profileId);
  return {
    schemaVersion: "ios-device-profile/v1",
    profileId,
    platform: "ios",
    model: input.deviceProfile.model?.trim() || matchedPrevious?.model,
    osVersion:
      input.deviceProfile.osVersion?.trim() || matchedPrevious?.osVersion,
    viewportWidth,
    viewportHeight,
    screenshotWidth:
      screenshotViewport?.width ?? matchedPrevious?.screenshotWidth,
    screenshotHeight:
      screenshotViewport?.height ?? matchedPrevious?.screenshotHeight,
    coordinateSpace: "mobilecli",
    orientation:
      input.deviceProfile.orientation ??
      matchedPrevious?.orientation ??
      (viewportWidth > viewportHeight ? "landscape" : "portrait"),
    displayScale:
      input.deviceProfile.displayScale ?? matchedPrevious?.displayScale,
    updatedAt: new Date().toISOString(),
  };
}

async function capturePage(options: {
  action: Extract<RegressionAction, { type: "snapshot" }>;
  bundleId: string;
  routeDirectory: string;
  index: number;
  udid: string;
  profile: DeviceProfile;
  controlHints: readonly UiControlHint[];
  autoDiscoverControls: boolean;
  layout: AssetLayout;
}): Promise<{ page: UiPage; controls: UiControl[] }> {
  const prefix = `${String(options.index + 1).padStart(2, "0")}-${safeSegment(options.action.pageId)}`;
  const screenshotPath = join(options.routeDirectory, `${prefix}.png`);
  const uiDumpPath = join(options.routeDirectory, `${prefix}.ui.json`);
  const baselineDirectory = join(
    options.layout.baselinesDirectory,
    "pages",
    safeSegment(options.profile.profileId),
  );
  const baselineScreenshotPath = join(
    baselineDirectory,
    `${safeSegment(options.action.pageId)}.png`,
  );
  const baselineUiDumpPath = join(
    baselineDirectory,
    `${safeSegment(options.action.pageId)}.ui.json`,
  );
  const screenshot = await runCommand(
    buildMobilecliScreenshotCommand(options.udid, screenshotPath),
  );
  if (screenshot.exitCode !== 0) {
    throw new Error(
      `Screenshot failed for page ${options.action.pageId}: ${screenshot.stderr}`,
    );
  }
  const dump = await runCommand(buildMobilecliUiDumpCommand(options.udid));
  await writeFile(uiDumpPath, dump.stdout, "utf8");
  if (dump.exitCode !== 0) {
    throw new Error(
      `UI dump failed for page ${options.action.pageId}: ${dump.stderr}`,
    );
  }
  await mkdir(baselineDirectory, { recursive: true });
  await Promise.all([
    copyFile(screenshotPath, baselineScreenshotPath),
    writeFile(baselineUiDumpPath, dump.stdout, "utf8"),
  ]);

  const elements = parseUiDump(dump.stdout);
  const observedAt = new Date().toISOString();
  const hintedControls = controlsFromHints({
    pageId: options.action.pageId,
    hints: options.controlHints,
    elements,
    profile: options.profile,
    observedAt,
  });
  const automaticControls = options.autoDiscoverControls
    ? autoDiscoverControls({
        pageId: options.action.pageId,
        elements,
        profile: options.profile,
        observedAt,
      })
    : [];
  const controls = mergeControls(automaticControls, hintedControls);
  const anchorControlIds =
    options.action.anchorControlIds?.filter((controlId) =>
      controls.some((control) => control.controlId === controlId),
    ) ?? hintedControls.slice(0, 4).map((control) => control.controlId);
  const page: UiPage = {
    schemaVersion: "ios-ui-page/v1",
    pageId: options.action.pageId,
    title: options.action.title,
    bundleId: options.bundleId,
    fingerprint: fingerprintUi(elements),
    observedAt,
    deviceProfileId: options.profile.profileId,
    screenshotPath: baselineScreenshotPath,
    uiDumpPath: baselineUiDumpPath,
    controlIds: controls.map((control) => control.controlId),
    anchorControlIds,
  };
  await writeJsonAtomic(
    join(options.layout.pagesDirectory, `${safeSegment(page.pageId)}.json`),
    page,
  );
  return { page, controls };
}

async function executeAction(options: {
  action: Exclude<RegressionAction, { type: "snapshot" }>;
  bundleId: string;
  controls: readonly UiControl[];
  currentPageId?: string;
  index: number;
  profile: DeviceProfile;
  routeDirectory: string;
  udid: string;
}): Promise<{ success: boolean; issue: string }> {
  let tapPoint: { x: number; y: number } | undefined;
  if (options.action.type === "tap") {
    const dump = await runCommand(buildMobilecliUiDumpCommand(options.udid));
    const beforePath = join(
      options.routeDirectory,
      `${String(options.index + 1).padStart(2, "0")}-${safeSegment(options.action.actionId)}-before.ui.json`,
    );
    await writeFile(beforePath, dump.stdout, "utf8");
    if (dump.exitCode !== 0) {
      return {
        success: false,
        issue: `UI dump before ${options.action.actionId} failed.`,
      };
    }
    const resolved = resolveTapPoint({
      action: options.action,
      controls: options.controls,
      elements: parseUiDump(dump.stdout),
      profile: options.profile,
      currentPageId: options.currentPageId,
    });
    if (!resolved.point) {
      return {
        success: false,
        issue:
          resolved.issue ?? `Unable to resolve ${options.action.actionId}.`,
      };
    }
    tapPoint = resolved.point;
  }
  const command = buildMobilecliActionCommand({
    action: options.action,
    udid: options.udid,
    bundleId: options.bundleId,
    tapPoint,
  });
  const result = await runCommand(command);
  await writeFile(
    join(
      options.routeDirectory,
      `${String(options.index + 1).padStart(2, "0")}-${safeSegment(options.action.actionId)}.stdout.txt`,
    ),
    result.stdout,
    "utf8",
  );
  return {
    success: result.exitCode === 0,
    issue:
      result.exitCode === 0
        ? ""
        : `${options.action.actionId} failed: ${result.stderr || result.stdout}`,
  };
}

function controlsFromHints(options: {
  pageId: string;
  hints: readonly UiControlHint[];
  elements: readonly UiElement[];
  profile: DeviceProfile;
  observedAt: string;
}): UiControl[] {
  return options.hints
    .filter((hint) => hint.pageId === options.pageId)
    .map((hint) => {
      const element = matchUiElement(options.elements, hint.selector);
      if (!element) {
        return null;
      }
      return makeControl({
        controlId: hint.controlId,
        pageId: hint.pageId,
        title: hint.title,
        selector: hint.selector,
        profile: options.profile,
        element,
        observedAt: options.observedAt,
      });
    })
    .filter((control): control is UiControl => control !== null);
}

export function autoDiscoverControls(options: {
  pageId: string;
  elements: readonly UiElement[];
  profile: DeviceProfile;
  observedAt: string;
}): UiControl[] {
  const seen = new Set<string>();
  const controls: UiControl[] = [];
  for (const [index, element] of options.elements.entries()) {
    const selector = bestSelector(element);
    if (!selector || !element.bounds) {
      continue;
    }
    const base = safeSegment(
      element.accessibilityId ||
        element.label ||
        element.text ||
        element.value ||
        element.role ||
        `control-${index + 1}`,
    ).toLocaleLowerCase();
    let controlId = `${safeSegment(options.pageId)}.${base}`;
    let suffix = 2;
    while (seen.has(controlId)) {
      controlId = `${safeSegment(options.pageId)}.${base}-${suffix}`;
      suffix += 1;
    }
    seen.add(controlId);
    controls.push(
      makeControl({
        controlId,
        pageId: options.pageId,
        title:
          element.label ||
          element.text ||
          element.accessibilityId ||
          element.role ||
          controlId,
        selector,
        profile: options.profile,
        element,
        observedAt: options.observedAt,
      }),
    );
  }
  return controls;
}

export function deriveCoordinateViewport(
  elements: readonly UiElement[],
): { width: number; height: number } | null {
  const root = elements
    .filter(
      (element) =>
        element.bounds &&
        element.bounds.x >= -1 &&
        element.bounds.x <= 1 &&
        element.bounds.y >= -1 &&
        element.bounds.y <= 1 &&
        element.bounds.width > 0 &&
        element.bounds.height > 0,
    )
    .sort(
      (left, right) =>
        right.bounds!.width * right.bounds!.height -
        left.bounds!.width * left.bounds!.height,
    )[0];
  return root?.bounds
    ? { width: root.bounds.width, height: root.bounds.height }
    : null;
}

export function parseDeviceInfoViewport(
  input: string,
): { width: number; height: number } | null {
  const trimmed = input.trim();
  if (!trimmed) {
    return null;
  }
  try {
    return findViewportInValue(JSON.parse(trimmed), []);
  } catch {
    return viewportFromText(trimmed);
  }
}

export function inferCoordinateViewportFromScreenshot(
  screenshotViewport: { width: number; height: number } | null,
  elements: readonly UiElement[],
): { width: number; height: number } | null {
  if (!screenshotViewport) {
    return null;
  }
  const bounded = elements.filter((element) => element.bounds);
  for (const scale of [3, 2, 1]) {
    const width = screenshotViewport.width / scale;
    const height = screenshotViewport.height / scale;
    if (!Number.isInteger(width) || !Number.isInteger(height)) {
      continue;
    }
    if (bounded.length === 0) {
      return scale === 1 ? { width, height } : null;
    }
    const inBounds = bounded.filter((element) => {
      const bounds = element.bounds!;
      const centerX = bounds.x + bounds.width / 2;
      const centerY = bounds.y + bounds.height / 2;
      return (
        centerX >= 0 && centerX <= width && centerY >= 0 && centerY <= height
      );
    }).length;
    if (inBounds / bounded.length >= 0.8) {
      return { width, height };
    }
  }
  return null;
}

export function isTransitionTrigger(
  action: Exclude<RegressionAction, { type: "snapshot" }>,
): boolean {
  return (
    action.type === "tap" ||
    action.type === "swipe" ||
    action.type === "button" ||
    action.type === "type_text"
  );
}

function transitionFromAction(
  fromPageId: string,
  action: Exclude<RegressionAction, { type: "snapshot" }>,
): { actionId: string; controlId?: string; fromPageId: string } {
  return {
    actionId: action.actionId,
    controlId: action.type === "tap" ? action.target.controlId : undefined,
    fromPageId,
  };
}

function bestSelector(element: UiElement) {
  if (element.accessibilityId) {
    return { accessibilityId: element.accessibilityId };
  }
  if (element.label) {
    return { label: element.label, role: element.role };
  }
  if (element.text) {
    return { text: element.text, role: element.role };
  }
  if (element.value && element.role) {
    return { value: element.value, role: element.role };
  }
  return undefined;
}

function findViewportInValue(
  value: unknown,
  path: readonly string[],
): { width: number; height: number } | null {
  if (typeof value === "string") {
    return viewportFromText(value);
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const viewport = findViewportInValue(item, path);
      if (viewport) {
        return viewport;
      }
    }
    return null;
  }
  if (!isObject(value)) {
    return null;
  }

  const normalizedPath = path.join(".").toLocaleLowerCase();
  const width = finiteDimension(
    value.width ??
      value.screenWidth ??
      value.screen_width ??
      value.logicalWidth ??
      value.logical_width,
  );
  const height = finiteDimension(
    value.height ??
      value.screenHeight ??
      value.screen_height ??
      value.logicalHeight ??
      value.logical_height,
  );
  if (
    width &&
    height &&
    (path.length === 0 ||
      /(screen|display|viewport|logical|resolution|rect)/.test(normalizedPath))
  ) {
    return { width, height };
  }

  for (const [key, child] of Object.entries(value)) {
    if (
      typeof child === "string" &&
      /(screen|display|viewport|logical|resolution|size)/i.test(key)
    ) {
      const viewport = viewportFromText(child);
      if (viewport) {
        return viewport;
      }
    }
    const viewport = findViewportInValue(child, [...path, key]);
    if (viewport) {
      return viewport;
    }
  }
  return null;
}

function viewportFromText(
  value: string,
): { width: number; height: number } | null {
  const match = value.match(/(\d{2,5})\s*[x×]\s*(\d{2,5})/i);
  if (!match) {
    return null;
  }
  const width = Number(match[1]);
  const height = Number(match[2]);
  return width > 0 && height > 0 ? { width, height } : null;
}

function finiteDimension(value: unknown): number | null {
  const number =
    typeof value === "number"
      ? value
      : typeof value === "string"
        ? Number(value)
        : Number.NaN;
  return Number.isFinite(number) && number > 0 ? number : null;
}

function isObject(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function mergeTransitions(
  existing: UiTransitionCollection,
  incoming: readonly UiTransition[],
): UiTransitionCollection {
  const merged = new Map(
    existing.transitions.map((transition) => [
      transition.transitionId,
      transition,
    ]),
  );
  for (const transition of incoming) {
    merged.set(transition.transitionId, transition);
  }
  return {
    schemaVersion: "ios-ui-transitions/v1",
    bundleId: existing.bundleId,
    updatedAt: new Date().toISOString(),
    transitions: [...merged.values()].sort((left, right) =>
      left.transitionId.localeCompare(right.transitionId),
    ),
  };
}

async function readTransitions(
  path: string,
  bundleId: string,
): Promise<UiTransitionCollection> {
  try {
    return JSON.parse(await Bun.file(path).text()) as UiTransitionCollection;
  } catch {
    return {
      schemaVersion: "ios-ui-transitions/v1",
      bundleId,
      updatedAt: new Date().toISOString(),
      transitions: [],
    };
  }
}

function mergeProfiles(
  existing: DeviceProfileCollection,
  profile: DeviceProfile,
  bundleId: string,
): DeviceProfileCollection {
  const merged = new Map(
    existing.profiles.map((candidate) => [candidate.profileId, candidate]),
  );
  merged.set(profile.profileId, profile);
  return {
    schemaVersion: "ios-device-profiles/v1",
    bundleId,
    updatedAt: new Date().toISOString(),
    profiles: [...merged.values()].sort((left, right) =>
      left.profileId.localeCompare(right.profileId),
    ),
  };
}

function boundedInteger(
  value: number | undefined,
  minimum: number,
  maximum: number,
  fallback: number,
): number {
  if (value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(maximum, Math.max(minimum, Math.trunc(value)));
}

function requiredText(value: string | undefined, name: string): string {
  const trimmed = value?.trim();
  if (!trimmed) {
    throw new TypeError(`iOS UI Discovery requires ${name}.`);
  }
  return trimmed;
}

function safeSegment(value: string): string {
  return (
    value.replaceAll(/[^A-Za-z0-9_.-]+/g, "-").replaceAll(/^-+|-+$/g, "") ||
    "item"
  );
}

function timestampForPath(): string {
  return new Date()
    .toISOString()
    .replaceAll(/[^0-9]/g, "")
    .slice(0, 14);
}

async function readPngSize(
  path: string,
): Promise<{ width: number; height: number } | null> {
  const bytes = await readFile(path);
  if (
    bytes.length < 24 ||
    bytes[0] !== 0x89 ||
    bytes[1] !== 0x50 ||
    bytes[2] !== 0x4e ||
    bytes[3] !== 0x47
  ) {
    return null;
  }
  return {
    width: bytes.readUInt32BE(16),
    height: bytes.readUInt32BE(20),
  };
}
