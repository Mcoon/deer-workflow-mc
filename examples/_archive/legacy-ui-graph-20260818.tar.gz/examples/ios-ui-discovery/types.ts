import type {
  DeviceProfile,
  RegressionAction,
  UiControl,
  UiPage,
  UiSelector,
  UiTransition,
} from "../ios-regression-kit/types";

export interface UiControlHint {
  readonly pageId: string;
  readonly controlId: string;
  readonly title: string;
  readonly selector: UiSelector;
}

export interface UiDiscoveryRoute {
  readonly routeId: string;
  readonly title: string;
  readonly actions: readonly RegressionAction[];
}

export interface IosUiDiscoveryInput {
  readonly projectRoot?: string;
  readonly udid: string;
  readonly bundleId: string;
  readonly appName?: string;
  readonly runId?: string;
  readonly outputDir?: string;
  readonly assetRoot?: string;
  readonly mobilecliPreflightPath?: string;
  readonly deviceProfile?: {
    readonly profileId?: string;
    readonly model?: string;
    readonly osVersion?: string;
    readonly viewportWidth?: number;
    readonly viewportHeight?: number;
    readonly orientation?: "portrait" | "landscape";
    readonly displayScale?: number;
  };
  readonly controlHints?: readonly UiControlHint[];
  readonly routes: readonly UiDiscoveryRoute[];
  readonly settleMs?: number;
  readonly autoDiscoverControls?: boolean;
}

export interface UiDiscoveryRouteResult {
  readonly routeId: string;
  readonly title: string;
  readonly success: boolean;
  readonly pages: readonly string[];
  readonly issues: readonly string[];
}

export interface IosUiDiscoveryResult {
  readonly success: boolean;
  readonly outputDir: string;
  readonly assetRoot: string;
  readonly appAssetRoot: string;
  readonly manifestPath: string;
  readonly controlsPath: string;
  readonly transitionsPath: string;
  readonly deviceProfilesPath: string;
  readonly pages: readonly UiPage[];
  readonly controls: readonly UiControl[];
  readonly transitions: readonly UiTransition[];
  readonly deviceProfile: DeviceProfile;
  readonly routes: readonly UiDiscoveryRouteResult[];
  readonly reportPath: string;
}
