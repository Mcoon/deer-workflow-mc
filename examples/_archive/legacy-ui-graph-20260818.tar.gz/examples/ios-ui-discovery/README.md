# iOS UI Discovery

This Workflow uses serialized `mobilecli` routes to collect reusable iOS page,
control, device-profile, and transition assets. It does not use AI or Midscene
to drive the device.

Run the Chinese guide's example from
[`README.zh-CN.md`](./README.zh-CN.md), replacing the UDID, bundle ID, routes,
and control hints. Run artifacts go to
`/tmp/ios_perf-opt/ios-ui-discovery/<run_id>`, while durable assets go to
`ios-perf-optimizer/assets/app-regression/<bundle_id>`.

Controls are resolved from the live UI dump first. A normalized coordinate
binding may only be used for the same device profile after the expected page
has been verified. Ambiguous matches fail instead of selecting a candidate.
