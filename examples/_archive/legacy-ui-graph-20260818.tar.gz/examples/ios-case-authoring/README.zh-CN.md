# iOS Case Authoring

这个 Workflow 把 iPhone 操作录屏、需求描述或已有文档转换为结构化功能回归 case。
它允许 Agent 理解业务路径，但不允许 Agent 自由决定点击位置。

前置条件是先运行 `ios-ui-discovery`，让相关 `pageId` 和 `controlId` 已经存在。

## 运行

```bash
deer-workflow run /Users/bytedance/Documents/deer-workflow-mc/examples/ios-case-authoring/workflow.ts \
  --input '{
    "bundleId": "com.bot.doubao",
    "recordingPath": "/tmp/ios_perf-opt/manual-demo/message-demo.mp4",
    "requirements": "生成启动、发送文字消息和发送图片消息的 P0/P1 回归 case。",
    "caseSetId": "doubao-message-regression"
  }'
```

Workflow 会：

1. 使用 `ffmpeg` 按间隔抽取有限数量的录屏帧；
2. 把需求、帧路径和已知 UI map 交给 Agent；
3. 要求 Agent 输出严格的 `ios-regression-case-set/v1`；
4. 校验所有 `pageId`、`controlId`、tap guard 和重复 ID；
5. 只有校验通过后才写入长期 case 资产。

## 确定性约束

- 自然语言只描述业务意图，不是执行 selector。
- 每个 `tap` 必须引用已存在的 `controlId`，或者显式提供稳定坐标。
- 每个 `tap` 必须有 `assertBefore`，确认当前页面或目标控件。
- 未经 UI discovery 沉淀的页面或控件会导致 authoring 失败。
- 失败草稿保留在运行目录，不能直接进入回归执行。

## 输出

```text
/tmp/ios_perf-opt/ios-case-authoring/<run_id>/
  frames/
  generated-cases.draft.json
  validation.json
  case-authoring-review.html
  summary.json
```

验证通过的 case 写入：

```text
.../assets/app-regression/<bundle_id>/cases/<case_set_id>.cases.json
```
