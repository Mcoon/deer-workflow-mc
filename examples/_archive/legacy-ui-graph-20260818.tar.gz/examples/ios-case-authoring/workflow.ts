import { mkdir, readdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";

import { agent } from "@deerwork-ai/deer-workflow/agents";
import type { JsonSchema } from "@deerwork-ai/deer-workflow/agents";
import { phase } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  DEFAULT_ARTIFACT_ROOT,
  ensureAssetLayout,
  fileExists,
  loadControls,
  loadPages,
  renderRegressionHtml,
  runCommand,
  validateCaseSet,
  writeJsonAtomic,
} from "../ios-regression-kit";

import type { RegressionCaseSet, UiControl } from "../ios-regression-kit/types";
import type { IosCaseAuthoringInput, IosCaseAuthoringResult } from "./types";

const DEFAULT_FRAME_INTERVAL_SECONDS = 2;
const DEFAULT_MAX_FRAMES = 24;

export const meta = {
  name: "ios-case-authoring",
  description:
    "Turns an iPhone recording or requirements into validated structured regression cases grounded in the UI map.",
  phases: [
    { title: "Prepare" },
    { title: "Extract" },
    { title: "Author" },
    { title: "Validate" },
    { title: "Review" },
  ],
  exampleArgs: {
    bundleId: "com.bot.doubao",
    recordingPath: "/tmp/ios_perf-opt/manual-demo/message-demo.mp4",
    requirements: "覆盖启动、发送文字消息和发送图片消息。",
  },
};

export const regressionCaseSetSchema = JSON.parse(
  JSON.stringify({
    type: "object",
    properties: {
      schemaVersion: { const: "ios-regression-case-set/v1" },
      caseSetId: { type: "string" },
      title: { type: "string" },
      bundleId: { type: "string" },
      generatedAt: { type: "string" },
      source: {
        type: "object",
        properties: {
          kind: {
            type: "string",
            enum: ["recording", "requirements", "mixed", "manual"],
          },
          recordingPath: { type: "string" },
          requirementsPath: { type: "string" },
        },
        required: ["kind"],
        additionalProperties: false,
      },
      cases: {
        type: "array",
        minItems: 1,
        items: {
          type: "object",
          properties: {
            caseId: { type: "string" },
            title: { type: "string" },
            priority: { type: "string", enum: ["P0", "P1", "P2"] },
            tags: { type: "array", items: { type: "string" } },
            preconditions: {
              type: "array",
              items: regressionAssertionSchema(),
            },
            actions: {
              type: "array",
              minItems: 1,
              items: regressionActionSchema(),
            },
            expected: {
              type: "array",
              items: regressionAssertionSchema(),
            },
          },
          required: [
            "caseId",
            "title",
            "priority",
            "tags",
            "preconditions",
            "actions",
            "expected",
          ],
          additionalProperties: false,
        },
      },
    },
    required: [
      "schemaVersion",
      "caseSetId",
      "title",
      "bundleId",
      "generatedAt",
      "source",
      "cases",
    ],
    additionalProperties: false,
  }),
) as JsonSchema;

export default async function iosCaseAuthoring(
  args: IosCaseAuthoringInput,
): Promise<IosCaseAuthoringResult> {
  const input = normalizeInput(args);

  phase("Prepare");
  await mkdir(input.outputDir, { recursive: true });
  const { layout } = await ensureAssetLayout({
    bundleId: input.bundleId,
    assetRoot: input.assetRoot,
    appName: input.appName,
  });
  const controls = (await loadControls(layout.controlsPath)).controls;
  const pages = await loadPages(layout.pagesDirectory);
  const requirements = await loadRequirements(input);
  if (!input.recordingPath && !requirements.trim()) {
    throw new TypeError(
      "iOS Case Authoring requires recordingPath, requirements, or requirementsPath.",
    );
  }
  log(
    [
      "## Preparing regression case authoring",
      `- **Bundle:** \`${input.bundleId}\``,
      `- **UI controls:** ${controls.length}`,
      `- **Recording:** \`${input.recordingPath || "none"}\``,
      `- **Output:** \`${input.outputDir}\``,
    ].join("\n"),
  );

  phase("Extract");
  const framePaths = input.recordingPath
    ? await extractFrames({
        recordingPath: input.recordingPath,
        outputDir: input.framesDirectory,
        intervalSeconds: input.frameIntervalSeconds,
        maxFrames: input.maxFrames,
      })
    : [];
  log(
    `- Extracted **${framePaths.length}** review frame(s) from the recording.`,
  );

  phase("Author");
  const prompt = buildAuthoringPrompt({
    input,
    controls,
    requirements,
    framePaths,
  });
  const caseSet = await agent<RegressionCaseSet>(prompt, {
    cwd: input.cwd,
    model: input.model,
    sandbox: "read-only",
    schema: regressionCaseSetSchema,
  });

  phase("Validate");
  const normalizedCaseSet: RegressionCaseSet = {
    ...caseSet,
    schemaVersion: "ios-regression-case-set/v1",
    caseSetId: input.caseSetId || caseSet.caseSetId,
    bundleId: input.bundleId,
    generatedAt: new Date().toISOString(),
    source: {
      kind:
        input.recordingPath && requirements.trim()
          ? "mixed"
          : input.recordingPath
            ? "recording"
            : "requirements",
      recordingPath: input.recordingPath || undefined,
      requirementsPath: input.requirementsPath || undefined,
    },
  };
  const validation = validateCaseSet(
    normalizedCaseSet,
    controls,
    new Set(pages.map((page) => page.pageId)),
  );
  const draftPath = join(input.outputDir, "generated-cases.draft.json");
  await writeJsonAtomic(draftPath, normalizedCaseSet);
  if (!validation.valid) {
    await writeJsonAtomic(join(input.outputDir, "validation.json"), validation);
    throw new Error(
      [
        "Generated regression cases failed deterministic validation.",
        ...validation.issues.map((issue) => `- ${issue}`),
        `Draft: ${draftPath}`,
      ].join("\n"),
    );
  }
  const caseSetPath = join(layout.casesDirectory, input.caseFileName);
  await writeJsonAtomic(caseSetPath, normalizedCaseSet);

  phase("Review");
  const reviewPath = join(input.outputDir, "case-authoring-review.html");
  const review = renderRegressionHtml({
    title: "iOS Regression Case Review",
    subtitle:
      "Cases are grounded in pageId/controlId assets. Natural language descriptions are never the only tap target.",
    summary: [
      { label: "Cases", value: String(normalizedCaseSet.cases.length) },
      { label: "UI Controls", value: String(controls.length) },
      { label: "Recording Frames", value: String(framePaths.length) },
      { label: "Validation", value: "PASS" },
    ],
    rows: normalizedCaseSet.cases.map((regressionCase) => ({
      id: regressionCase.caseId,
      title: regressionCase.title,
      verdict: "pass",
      details: `${regressionCase.priority} · ${regressionCase.actions.length} actions · ${regressionCase.tags.join(", ")}`,
    })),
  });
  await writeFile(reviewPath, review, "utf8");
  await writeJsonAtomic(join(input.outputDir, "summary.json"), {
    schemaVersion: "ios-case-authoring-result/v1",
    success: true,
    bundleId: input.bundleId,
    caseSetPath,
    reviewPath,
    framePaths,
    caseCount: normalizedCaseSet.cases.length,
  });

  return {
    success: true,
    outputDir: input.outputDir,
    assetRoot: layout.assetRoot,
    appAssetRoot: layout.appRoot,
    caseSetPath,
    reviewPath,
    framesDirectory: input.recordingPath ? input.framesDirectory : undefined,
    framePaths,
    caseSet: normalizedCaseSet,
    validationIssues: [],
  };
}

interface NormalizedInput {
  bundleId: string;
  appName?: string;
  recordingPath: string;
  requirements: string;
  requirementsPath: string;
  assetRoot?: string;
  outputDir: string;
  framesDirectory: string;
  frameIntervalSeconds: number;
  maxFrames: number;
  caseSetId: string;
  caseFileName: string;
  cwd: string;
  model?: string;
}

function normalizeInput(args: IosCaseAuthoringInput): NormalizedInput {
  if (!args) {
    throw new TypeError("iOS Case Authoring requires input arguments.");
  }
  const bundleId = requiredText(args.bundleId, "bundleId");
  const runId = safeSegment(args.runId?.trim() || timestampForPath());
  const outputDir = resolve(
    args.outputDir?.trim() ||
      join(DEFAULT_ARTIFACT_ROOT, "ios-case-authoring", runId),
  );
  const caseSetId =
    args.caseSetId?.trim() || `${safeSegment(bundleId)}-regression`;
  const caseFileName =
    safeSegment(
      args.caseFileName?.trim().replace(/\.json$/i, "") || caseSetId,
    ) + ".cases.json";
  return {
    bundleId,
    appName: args.appName?.trim() || undefined,
    recordingPath: args.recordingPath ? resolve(args.recordingPath) : "",
    requirements: args.requirements?.trim() || "",
    requirementsPath: args.requirementsPath
      ? resolve(args.requirementsPath)
      : "",
    assetRoot: args.assetRoot?.trim() || undefined,
    outputDir,
    framesDirectory: join(outputDir, "frames"),
    frameIntervalSeconds: boundedNumber(
      args.frameIntervalSeconds,
      0.2,
      30,
      DEFAULT_FRAME_INTERVAL_SECONDS,
    ),
    maxFrames: boundedInteger(args.maxFrames, 1, 100, DEFAULT_MAX_FRAMES),
    caseSetId,
    caseFileName,
    cwd: resolve(args.cwd?.trim() || process.cwd()),
    model: args.model?.trim() || undefined,
  };
}

async function loadRequirements(input: NormalizedInput): Promise<string> {
  if (!input.requirementsPath) {
    return input.requirements;
  }
  if (!(await fileExists(input.requirementsPath))) {
    throw new Error(
      `Requirements file does not exist: ${input.requirementsPath}`,
    );
  }
  const fileContent = await readFile(input.requirementsPath, "utf8");
  return [input.requirements, fileContent].filter(Boolean).join("\n\n");
}

export function buildExtractFramesCommand(options: {
  recordingPath: string;
  outputPattern: string;
  intervalSeconds: number;
  maxFrames: number;
}): string[] {
  return [
    "ffmpeg",
    "-hide_banner",
    "-loglevel",
    "error",
    "-i",
    options.recordingPath,
    "-vf",
    `fps=1/${options.intervalSeconds}`,
    "-frames:v",
    String(options.maxFrames),
    "-q:v",
    "2",
    options.outputPattern,
  ];
}

async function extractFrames(options: {
  recordingPath: string;
  outputDir: string;
  intervalSeconds: number;
  maxFrames: number;
}): Promise<string[]> {
  if (!(await fileExists(options.recordingPath))) {
    throw new Error(`Recording does not exist: ${options.recordingPath}`);
  }
  await mkdir(options.outputDir, { recursive: true });
  const outputPattern = join(options.outputDir, "frame-%03d.jpg");
  const command = buildExtractFramesCommand({
    ...options,
    outputPattern,
  });
  const result = await runCommand(command);
  if (result.exitCode !== 0) {
    throw new Error(`ffmpeg frame extraction failed: ${result.stderr}`);
  }
  return (await readdir(options.outputDir))
    .filter((name) => /^frame-\d+\.jpg$/i.test(name))
    .sort()
    .map((name) => join(options.outputDir, name));
}

export function buildAuthoringPrompt(options: {
  input: NormalizedInput;
  controls: readonly UiControl[];
  requirements: string;
  framePaths: readonly string[];
}): string {
  return [
    "Create a deterministic iOS functional regression case set.",
    "Return only the JSON object required by the supplied schema.",
    "",
    "Hard rules:",
    "1. Natural language is descriptive only. Every tap must use target.controlId from the supplied UI controls, unless the requirement explicitly provides a stable point.",
    "2. Every tap must declare pageId and include assertBefore that proves the current page or target control before execution.",
    "3. Do not invent controlId or pageId values. If the UI map is insufficient, omit that case instead of guessing.",
    "4. Keep device execution serial. Do not encode parallel device actions.",
    "5. Prefer small independent P0/P1 cases for launch, text message, image message, and navigation when the evidence supports them.",
    "6. Use structured assertions: page, control_visible, text_visible, foreground_bundle, ui_not_empty.",
    "7. Prefer one navigate action for known multi-page routes instead of reproducing every navigation tap. Navigate defaults to navigation-only; include selection only when the requested target requires choosing a fixture.",
    "8. Use snapshot actions after important mutations so regression evidence can be captured.",
    "",
    `Bundle ID: ${options.input.bundleId}`,
    `Requested caseSetId: ${options.input.caseSetId}`,
    `Requirements:\n${options.requirements || "(none)"}`,
    `Recording: ${options.input.recordingPath || "(none)"}`,
    `Extracted frame paths: ${JSON.stringify(options.framePaths)}`,
    `Known UI controls: ${JSON.stringify(
      options.controls.map((control) => ({
        controlId: control.controlId,
        pageId: control.pageId,
        title: control.title,
        role: control.role,
        selector: control.selector,
      })),
    )}`,
    "",
    "You may inspect the listed local recording frames with available image tools when needed.",
  ].join("\n");
}

function regressionAssertionSchema() {
  return {
    oneOf: [
      {
        type: "object",
        properties: {
          type: { const: "page" },
          pageId: { type: "string" },
        },
        required: ["type", "pageId"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          type: { const: "control_visible" },
          pageId: { type: "string" },
          controlId: { type: "string" },
        },
        required: ["type", "pageId", "controlId"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          type: { const: "text_visible" },
          text: { type: "string" },
        },
        required: ["type", "text"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          type: { const: "foreground_bundle" },
          bundleId: { type: "string" },
        },
        required: ["type"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          type: { const: "ui_not_empty" },
        },
        required: ["type"],
        additionalProperties: false,
      },
    ],
  };
}

function actionBaseProperties() {
  return {
    actionId: { type: "string" },
    description: { type: "string" },
    assertBefore: {
      type: "array",
      items: regressionAssertionSchema(),
    },
    assertAfter: {
      type: "array",
      items: regressionAssertionSchema(),
    },
  };
}

function regressionActionSchema() {
  const base = actionBaseProperties();
  return {
    oneOf: [
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "launch_app" },
          bundleId: { type: "string" },
        },
        required: ["actionId", "type"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "terminate_app" },
          bundleId: { type: "string" },
        },
        required: ["actionId", "type"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "tap" },
          pageId: { type: "string" },
          target: {
            type: "object",
            properties: {
              controlId: { type: "string" },
              point: pointSchema(),
              normalizedPoint: pointSchema(),
            },
            additionalProperties: false,
          },
        },
        required: ["actionId", "type", "pageId", "target"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "type_text" },
          text: { type: "string" },
        },
        required: ["actionId", "type", "text"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "swipe" },
          from: pointSchema(),
          to: pointSchema(),
          durationMs: { type: "number" },
        },
        required: ["actionId", "type", "from", "to"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "button" },
          button: { type: "string" },
        },
        required: ["actionId", "type", "button"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "wait" },
          durationMs: { type: "number" },
        },
        required: ["actionId", "type", "durationMs"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "snapshot" },
          pageId: { type: "string" },
          title: { type: "string" },
          anchorControlIds: {
            type: "array",
            items: { type: "string" },
          },
        },
        required: ["actionId", "type", "pageId", "title"],
        additionalProperties: false,
      },
      {
        type: "object",
        properties: {
          ...base,
          type: { const: "navigate" },
          targetPageId: { type: "string" },
          targetPage: { type: "string" },
          sourcePageId: { const: "cold_start" },
          allowCategories: {
            type: "array",
            items: {
              type: "string",
              enum: ["navigation", "selection", "permission", "mutation"],
            },
          },
        },
        required: ["actionId", "type"],
        additionalProperties: false,
      },
    ],
  };
}

function pointSchema() {
  return {
    type: "object",
    properties: {
      x: { type: "number" },
      y: { type: "number" },
    },
    required: ["x", "y"],
    additionalProperties: false,
  };
}

function boundedInteger(
  value: number | undefined,
  minimum: number,
  maximum: number,
  fallback: number,
): number {
  if (value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(maximum, Math.max(minimum, Math.trunc(value)));
}

function boundedNumber(
  value: number | undefined,
  minimum: number,
  maximum: number,
  fallback: number,
): number {
  if (value === undefined || !Number.isFinite(value)) {
    return fallback;
  }
  return Math.min(maximum, Math.max(minimum, value));
}

function requiredText(value: string | undefined, name: string): string {
  const trimmed = value?.trim();
  if (!trimmed) {
    throw new TypeError(`iOS Case Authoring requires ${name}.`);
  }
  return trimmed;
}

function safeSegment(value: string): string {
  return (
    value.replaceAll(/[^A-Za-z0-9_.-]+/g, "-").replaceAll(/^-+|-+$/g, "") ||
    "item"
  );
}

function timestampForPath(): string {
  return new Date()
    .toISOString()
    .replaceAll(/[^0-9]/g, "")
    .slice(0, 14);
}
