import type { RegressionCaseSet } from "../ios-regression-kit/types";

export interface IosCaseAuthoringInput {
  readonly bundleId: string;
  readonly appName?: string;
  readonly recordingPath?: string;
  readonly requirements?: string;
  readonly requirementsPath?: string;
  readonly assetRoot?: string;
  readonly runId?: string;
  readonly outputDir?: string;
  readonly frameIntervalSeconds?: number;
  readonly maxFrames?: number;
  readonly caseSetId?: string;
  readonly caseFileName?: string;
  readonly cwd?: string;
  readonly model?: string;
}

export interface IosCaseAuthoringResult {
  readonly success: boolean;
  readonly outputDir: string;
  readonly assetRoot: string;
  readonly appAssetRoot: string;
  readonly caseSetPath: string;
  readonly reviewPath: string;
  readonly framesDirectory?: string;
  readonly framePaths: readonly string[];
  readonly caseSet: RegressionCaseSet;
  readonly validationIssues: readonly string[];
}
