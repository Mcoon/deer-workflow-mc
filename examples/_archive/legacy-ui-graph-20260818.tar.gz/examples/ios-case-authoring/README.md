# iOS Case Authoring

This Agent-backed Workflow converts an iPhone recording or requirements into a
strict `ios-regression-case-set/v1` asset. Run `ios-ui-discovery` first: every
page and control referenced by generated cases must already exist in the UI
map.

Natural language is descriptive only. Every tap must have a structured target
and a page/control precondition. Drafts that invent pages, controls, or
unguarded taps fail deterministic validation and are not promoted to the
durable case asset directory.

See [`README.zh-CN.md`](./README.zh-CN.md) for a complete command.
