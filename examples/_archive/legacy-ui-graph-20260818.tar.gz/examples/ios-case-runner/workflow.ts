import { mkdir } from "node:fs/promises";
import { dirname, isAbsolute, join, resolve } from "node:path";

import { phase, getWorkflowContext } from "@deerwork-ai/deer-workflow/flow";
import { log } from "@deerwork-ai/deer-workflow/logging";

import {
  DEFAULT_ARTIFACT_ROOT,
  readJson,
  writeJsonAtomic,
} from "../ios-regression-kit";
import iosUiGraphNavigator from "../ios-ui-graph-navigator/workflow";

import type {
  CaseRunResult,
  CaseRunSummary,
  CaseVerdict,
  IosCaseRunnerFailureResult,
  IosCaseRunnerInput,
  IosCaseRunnerOutput,
  IosCaseRunnerResult,
  NavigatorHandlerResult,
  StructuredCase,
} from "./types";
import type { IosUiGraphNavigatorInput } from "../ios-ui-graph-navigator/types";

const DEFAULT_WORKFLOW_ROOT = resolve(dirname(import.meta.path), "../..");

/**
 * Sets the active progress phase when running inside a Workflow. A no-op when
 * called outside one, so the core can also be driven directly from unit tests.
 */
function setPhase(title: string): void {
  if (getWorkflowContext()) {
    phase(title);
  }
}

/**
 * Emits a progress message when running inside a Workflow. A no-op outside one.
 */
function logProgress(message: string): void {
  if (getWorkflowContext()) {
    log(message);
  }
}

/**
 * The reused experiment handler. Injectable so unit tests can exercise verdict
 * normalization and aggregation without touching a device.
 */
export type NavigatorRunner = (
  args: IosUiGraphNavigatorInput,
) => Promise<NavigatorHandlerResult>;

export const meta = {
  name: "ios-case-runner",
  description:
    "Runs structured iOS test cases on device by driving the verified UI graph engine and emitting strict per-case verdicts.",
  phases: [
    { title: "Load" },
    { title: "Parse Cases" },
    { title: "Run Cases" },
    { title: "Aggregate" },
    { title: "Report" },
  ],
  exampleArgs: {
    case: {
      case_id: 1,
      priority: "P0",
      tags: ["P0", "E2E_AUTO"],
      title: "预览页显示标记入口",
      precondition:
        "1. 起始页固定为对话页，可看到底部聊天输入区，以及左下角的相机入口。\n2. 如当前不在对话页，先执行冷启动恢复：结束并重新启动 app，等待首页稳定；若启动后落在其他页面，连续点击返回直到重新看到对话页输入区和左下角相机入口。",
      step: "1. 从对话页点击左下角相机入口，进入可拍摄照片的相机页。\n2. 在相机页确认底部圆形快门按钮可见后，点击快门拍摄一张照片。\n3. 等待约 3s，让拍摄完成并自动进入预览页。",
      expected:
        "1. 能从对话页正常进入相机页并完成单张拍摄，全程无闪退、无卡死。\n2. 拍摄完成后自动进入图片预览页，可看到刚拍摄的照片。\n3. 预览页右上角清晰可见铅笔形状的「标记」或带[A]的入口图标。",
    },
    planOnly: true,
  },
};

/**
 * Runs one or more structured iOS test cases and returns a strict aggregate
 * verdict.
 *
 * @param args - Case source plus device and graph forwarding options.
 * @returns A structured run result, or a structured failure result. This
 *   handler never throws for business failures.
 */
export default async function iosCaseRunner(
  args: IosCaseRunnerInput,
): Promise<IosCaseRunnerOutput> {
  return runIosCaseRunner(args, iosUiGraphNavigator);
}

/**
 * Testable core. Accepts an injectable experiment runner so verdict
 * normalization, selection, and aggregation can be exercised without a device.
 */
export async function runIosCaseRunner(
  args: IosCaseRunnerInput,
  navigatorRunner: NavigatorRunner,
): Promise<IosCaseRunnerOutput> {
  const planOnly = args?.planOnly === true;
  const runId = safeSegment(args?.runId?.trim() || timestampForPath());
  const outputDir = resolve(
    args?.outputDir?.trim() ||
      join(DEFAULT_ARTIFACT_ROOT, "ios-case-runner", runId),
  );

  setPhase("Load");
  await mkdir(outputDir, { recursive: true });

  setPhase("Parse Cases");
  let cases: StructuredCase[];
  try {
    cases = await loadCases(args);
  } catch (error) {
    return writeFailure({
      outputDir,
      runId,
      planOnly,
      code: "case_source_unreadable",
      stage: "Parse Cases",
      message: error instanceof Error ? error.message : String(error),
      recoverable: true,
    });
  }

  const selected = selectCases(cases, {
    tags: normalizeStringSet(args?.filterTags),
    caseIds: normalizeStringSet(
      args?.filterCaseIds?.map((id) => normalizeCaseId(id)),
    ),
  });

  if (selected.length === 0) {
    return writeFailure({
      outputDir,
      runId,
      planOnly,
      code: "no_cases_selected",
      stage: "Parse Cases",
      message:
        cases.length === 0
          ? "No structured cases were supplied via case, cases, or caseSetPath."
          : "Every supplied case was filtered out by filterTags/filterCaseIds.",
      recoverable: true,
    });
  }
  logProgress(
    `Parsed ${cases.length} case(s); ${selected.length} selected to run.`,
  );

  setPhase("Run Cases");
  const allowDiscovery = args?.allowDiscovery !== false;
  const results: CaseRunResult[] = [];
  for (const structuredCase of selected) {
    const caseResult = await runSingleCase({
      structuredCase,
      args,
      runOutputDir: outputDir,
      planOnly,
      allowDiscovery,
      navigatorRunner,
    });
    results.push(caseResult);
    logProgress(
      `Case ${caseResult.caseId}: ${caseResult.verdict} — ${caseResult.reason}`,
    );
  }

  setPhase("Aggregate");
  const summary = aggregateSummary(results);
  const success = summary.total > 0 && summary.pass === summary.total;

  setPhase("Report");
  const reportPath = join(outputDir, "report.json");
  const resultPath = join(outputDir, "result.json");
  const result: IosCaseRunnerResult = {
    success,
    mode: "case_run",
    planOnly,
    runId,
    outputDir,
    summary,
    cases: results,
    reportPath,
    resultPath,
  };
  await writeJsonAtomic(reportPath, {
    schemaVersion: "ios-case-runner-report/v1",
    runId,
    generatedAt: new Date().toISOString(),
    planOnly,
    summary,
    cases: results,
  });
  await writeJsonAtomic(resultPath, result);
  logResult(result);
  return result;
}

interface RunSingleCaseOptions {
  readonly structuredCase: StructuredCase;
  readonly args: IosCaseRunnerInput;
  readonly runOutputDir: string;
  readonly planOnly: boolean;
  readonly allowDiscovery: boolean;
  readonly navigatorRunner: NavigatorRunner;
}

async function runSingleCase(
  options: RunSingleCaseOptions,
): Promise<CaseRunResult> {
  const { structuredCase, args, runOutputDir, planOnly, allowDiscovery } =
    options;
  const caseId = normalizeCaseId(structuredCase.case_id);
  const caseOutputDir = join(runOutputDir, "cases", safeSegment(caseId));
  const navigatorOutputDir = join(caseOutputDir, "navigator");
  const startedAt = new Date().toISOString();
  const goal = buildCaseGoal(structuredCase);

  await mkdir(caseOutputDir, { recursive: true });

  const navigatorInput: IosUiGraphNavigatorInput = {
    goal,
    planOnly,
    outputDir: navigatorOutputDir,
    graphPath: args.graphPath,
    projectRoot: args.projectRoot,
    udid: args.udid,
    model: args.model,
    agentTimeoutMs: args.agentTimeoutMs,
    allowLearning: allowDiscovery,
  };

  let navigatorResult: NavigatorHandlerResult;
  try {
    navigatorResult = await options.navigatorRunner(navigatorInput);
  } catch (error) {
    // The experiment handler self-wraps failures, but guard defensively so one
    // bad case never aborts the whole run.
    return {
      caseId,
      title: structuredCase.title,
      priority: structuredCase.priority,
      tags: structuredCase.tags ?? [],
      verdict: "blocked",
      goal,
      startedAt,
      finishedAt: new Date().toISOString(),
      caseOutputDir,
      discoveryTriggered: false,
      evidencePaths: [],
      reason: `Navigator handler threw: ${
        error instanceof Error ? error.message : String(error)
      }`,
      failure: {
        code: "navigator_threw",
        stage: "Run Cases",
        message: error instanceof Error ? error.message : String(error),
        recoverable: true,
      },
    };
  }

  return normalizeCaseResult({
    caseId,
    structuredCase,
    goal,
    startedAt,
    caseOutputDir,
    navigatorResult,
  });
}

interface NormalizeCaseResultOptions {
  readonly caseId: string;
  readonly structuredCase: StructuredCase;
  readonly goal: string;
  readonly startedAt: string;
  readonly caseOutputDir: string;
  readonly navigatorResult: NavigatorHandlerResult;
}

/**
 * Maps an experiment result into a strict per-case verdict.
 *
 * @remarks
 * Pure and exported for unit testing. Verdict rules:
 * - `workflow_failure` before execution → `blocked`.
 * - `targeted_discovery` that did not complete the goal → `needs_review`
 *   (Graph gap surfaced), else `pass` when its verifier passed.
 * - a full experiment result → `pass`/`fail`/`needs_review` based on
 *   `success`, the agent verifier classification, and final verification.
 */
export function normalizeCaseResult(
  options: NormalizeCaseResultOptions,
): CaseRunResult {
  const { caseId, structuredCase, goal, startedAt, caseOutputDir } = options;
  const navigatorResult = options.navigatorResult;
  const finishedAt = new Date().toISOString();
  const base = {
    caseId,
    title: structuredCase.title,
    priority: structuredCase.priority,
    tags: structuredCase.tags ?? [],
    goal,
    startedAt,
    finishedAt,
    caseOutputDir,
  } as const;

  if (navigatorResult.mode === "workflow_failure") {
    return {
      ...base,
      verdict: "blocked",
      experimentMode: "workflow_failure",
      experimentResultPath: navigatorResult.resultPath,
      discoveryTriggered: false,
      evidencePaths: navigatorResult.failure.evidencePaths,
      reason: navigatorResult.failure.message,
      failure: {
        code: navigatorResult.failure.code,
        stage: navigatorResult.failure.stage,
        message: navigatorResult.failure.message,
        recoverable: navigatorResult.failure.recoverable,
      },
    };
  }

  const verdict: CaseVerdict = navigatorResult.status;
  return {
    ...base,
    verdict,
    experimentMode: "navigation",
    experimentResultPath: navigatorResult.resultPath,
    discoveryTriggered: navigatorResult.actions.length > 0,
    evidencePaths: navigatorResult.evidencePaths,
    reason: describeNavigatorVerdict(navigatorResult),
    failure: navigatorResult.failure
      ? {
          code: navigatorResult.failure.code,
          stage: navigatorResult.failure.stage,
          message: navigatorResult.failure.message,
          recoverable: navigatorResult.failure.recoverable,
        }
      : undefined,
  };
}

function describeNavigatorVerdict(
  result: Extract<NavigatorHandlerResult, { mode: "navigation" }>,
): string {
  if (result.planOnly) {
    return "Plan-only: the navigator perceived the current UI and planned the next constrained action; on-device mutation was not run.";
  }
  if (result.agentVerifier) {
    return `Agent verifier classified the outcome as ${result.agentVerifier.classification}.`;
  }
  return (
    result.failure?.message ?? `Navigator completed with ${result.status}.`
  );
}

/**
 * Builds a deterministic semantic goal from a structured case.
 *
 * @remarks
 * Pure and exported for unit testing. Preserves the case's step and expected
 * prose verbatim so step constraints (for example "点击快门拍摄") and assertion
 * text (for example "右上角可见铅笔标记") are not lost. Precondition prose is
 * appended as an explicit cold-start recovery hint rather than flattened away.
 */
export function buildCaseGoal(structuredCase: StructuredCase): string {
  const segments: string[] = [];
  segments.push(`测试用例：${structuredCase.title.trim()}`);
  if (structuredCase.precondition?.trim()) {
    segments.push(
      `前置条件（含冷启动恢复）：\n${structuredCase.precondition.trim()}`,
    );
  }
  segments.push(`执行步骤：\n${structuredCase.step.trim()}`);
  segments.push(
    `预期结果（必须逐条验证）：\n${structuredCase.expected.trim()}`,
  );
  return segments.join("\n\n");
}

/**
 * Loads structured cases from the input in priority order: inline `case`, then
 * inline `cases`, then a JSON file at `caseSetPath` (array or `{ cases: [] }`).
 * Returns an empty array when no source is supplied; the caller reports that as
 * an empty selection.
 *
 * @throws When `caseSetPath` is set but the file cannot be read or parsed.
 */
export async function loadCases(
  args: IosCaseRunnerInput,
): Promise<StructuredCase[]> {
  if (args?.case) {
    return [args.case];
  }
  if (args?.cases && args.cases.length > 0) {
    return [...args.cases];
  }
  if (args?.caseSetPath?.trim()) {
    const path = isAbsolute(args.caseSetPath)
      ? args.caseSetPath
      : resolve(DEFAULT_WORKFLOW_ROOT, args.caseSetPath);
    const parsed = await readJson<unknown>(path);
    return parseCaseSet(parsed);
  }
  return [];
}

/**
 * Parses a caseset document that is either a bare array or an object exposing a
 * `cases` array.
 *
 * @throws When the shape is neither an array nor a `{ cases: [] }` object.
 */
export function parseCaseSet(document: unknown): StructuredCase[] {
  if (Array.isArray(document)) {
    return document as StructuredCase[];
  }
  if (
    document &&
    typeof document === "object" &&
    Array.isArray((document as { cases?: unknown }).cases)
  ) {
    return (document as { cases: StructuredCase[] }).cases;
  }
  throw new Error(
    "Caseset JSON must be an array of cases or an object with a `cases` array.",
  );
}

/**
 * Filters cases by tag and case-id allowlists. An empty allowlist matches all.
 *
 * @remarks Pure and exported for unit testing.
 */
export function selectCases(
  cases: readonly StructuredCase[],
  filters: { readonly tags: Set<string>; readonly caseIds: Set<string> },
): StructuredCase[] {
  return cases.filter((structuredCase) => {
    const matchesTag =
      filters.tags.size === 0 ||
      (structuredCase.tags ?? []).some((tag) => filters.tags.has(tag));
    const matchesId =
      filters.caseIds.size === 0 ||
      filters.caseIds.has(normalizeCaseId(structuredCase.case_id));
    return matchesTag && matchesId;
  });
}

/**
 * Aggregates per-case verdicts into summary counts.
 *
 * @remarks Pure and exported for unit testing.
 */
export function aggregateSummary(
  results: readonly CaseRunResult[],
): CaseRunSummary {
  const summary = {
    total: results.length,
    pass: 0,
    fail: 0,
    needsReview: 0,
    blocked: 0,
  };
  for (const result of results) {
    switch (result.verdict) {
      case "pass":
        summary.pass += 1;
        break;
      case "fail":
        summary.fail += 1;
        break;
      case "needs_review":
        summary.needsReview += 1;
        break;
      case "blocked":
        summary.blocked += 1;
        break;
    }
  }
  return summary;
}

/** Normalizes a case id (string or number) to trimmed text. */
export function normalizeCaseId(caseId: string | number): string {
  return String(caseId).trim();
}

function normalizeStringSet(values?: readonly string[]): Set<string> {
  const set = new Set<string>();
  for (const value of values ?? []) {
    const trimmed = value.trim();
    if (trimmed) {
      set.add(trimmed);
    }
  }
  return set;
}

async function writeFailure(options: {
  outputDir: string;
  runId: string;
  planOnly: boolean;
  code: string;
  stage: string;
  message: string;
  recoverable: boolean;
}): Promise<IosCaseRunnerFailureResult> {
  const resultPath = join(options.outputDir, "result.json");
  const result: IosCaseRunnerFailureResult = {
    success: false,
    mode: "workflow_failure",
    planOnly: options.planOnly,
    runId: options.runId,
    outputDir: options.outputDir,
    resultPath,
    failure: {
      code: options.code,
      stage: options.stage,
      message: options.message,
      recoverable: options.recoverable,
      evidencePaths: [resultPath],
    },
  };
  await writeJsonAtomic(resultPath, result);
  logProgress(
    [
      "## iOS case runner result",
      "- **Status:** FAIL",
      `- **Failure:** \`${options.code}\` at ${options.stage}`,
      `- **Message:** ${options.message}`,
      `- **Result:** \`${resultPath}\``,
    ].join("\n"),
  );
  return result;
}

function logResult(result: IosCaseRunnerResult): void {
  const lines = [
    "## iOS case runner result",
    `- **Status:** ${result.success ? "PASS" : "ATTENTION"}`,
    `- **Cases:** ${result.summary.total} · pass ${result.summary.pass} · fail ${result.summary.fail} · review ${result.summary.needsReview} · blocked ${result.summary.blocked}`,
    `- **Report:** \`${result.reportPath}\``,
    `- **Result:** \`${result.resultPath}\``,
  ];
  logProgress(lines.join("\n"));
}

function safeSegment(value: string): string {
  const normalized = value
    .trim()
    .replace(/[^A-Za-z0-9._-]+/g, "-")
    .replace(/^-+|-+$/g, "");
  return normalized || "unnamed";
}

function timestampForPath(): string {
  return new Date().toISOString().replace(/[:.]/g, "-");
}
