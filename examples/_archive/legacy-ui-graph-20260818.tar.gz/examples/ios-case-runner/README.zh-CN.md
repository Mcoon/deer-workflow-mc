# iOS Case Runner

[English](./README.md)

这个 Workflow 接收结构化的人工测试用例，在真机上逐条执行并输出严格的逐条判定和汇总
报告。它不重写设备自动化：每条 case 会被桥接成一个语义 goal，进程内交给已验证的
[iOS UI Graph Navigator](../ios-ui-graph-navigator/) handler 执行。

## 为什么需要它

UI Graph 实验只接收一句自然语言 `goal`，但结构化测试用例带有三段有真实语义的字段：
`precondition`、`step`、`expected`。把整条 case 压成一句模糊 goal 会丢失步骤约束
（例如「点击快门拍摄」）和断言原文（例如「右上角可见铅笔标记入口」）。本 runner 保留
这三段原文，让引擎执行真实步骤并验证真实预期。

## 输入

按优先级提供其中一种 case 来源：

- `case` — 单条结构化 case 对象。
- `cases` — 内联 case 数组。
- `caseSetPath` — JSON 文件，可以是纯数组或 `{ "cases": [] }`。

结构化 case 沿用源用例表的字段名：

```json
{
  "case_id": 1,
  "priority": "P0",
  "tags": ["P0", "E2E_AUTO"],
  "path": ["1. 入口与设置", "标记入口与Settings开关"],
  "title": "预览页显示标记入口",
  "precondition": "1. 起始页固定为对话页……",
  "step": "1. 从对话页点击左下角相机入口……",
  "expected": "1. 能从对话页正常进入相机页并完成单张拍摄……"
}
```

`case_id` 兼容字符串和数字，统一归一化为文本。

可选字段：

- `filterTags` — 只运行带有任一列出 tag 的 case。
- `filterCaseIds` — 只运行列出的 case id（字符串或数字）。
- `udid`、`projectRoot`、`graphPath`、`model`、`agentTimeoutMs` — 原样转发给实验
  handler。
- `outputDir`、`runId` — 产物位置控制。
- `planOnly` — 只规划每条 case，不碰设备。
- `allowDiscovery` — 默认 `true`；当某条 case 的 Graph 能力不完整时，转入实验的定向
  探索路径，让 Graph 先演进，再给出严格判定。

## 管线

`Load → Parse Cases → Run Cases → Aggregate → Report`

每条 case 内部：

1. **Case → 语义 goal。** 确定性拼接 `title`、`step`、`expected`；`precondition`
   作为显式冷启动恢复提示追加。任何原文都不丢弃。
2. **进程内执行。** Navigator 每一步先理解真实当前 UI，优先复用已知
   Scene/Element/Operator，只有下一步歧义或未知时才调用 Agent。
3. **判定归一。** 把 Navigator 结果映射为严格判定：
   - `pass` — 编译出的 Oracle/断言全部成立。
   - `fail` — 路径执行到了但预期断言不满足。
   - `needs_review` — verifier 不确定、oracle 陈旧，或 Graph 无法严格证明预期。
   - `blocked` — 早期失败（reset、preflight 或其它执行前阶段）阻止了执行。
4. **Graph 演进。** 开启 `allowDiscovery` 时，成功的真实证据可写入 candidate
   Scene/Element/Operator，并更新已知 Operator 的执行可信度。

## 结果

每次 run 都返回结构化 JSON（业务失败绝不抛异常）：

```json
{
  "success": false,
  "mode": "case_run",
  "planOnly": false,
  "runId": "...",
  "outputDir": "/tmp/ios_perf-opt/ios-case-runner/...",
  "summary": {
    "total": 1,
    "pass": 0,
    "fail": 0,
    "needsReview": 1,
    "blocked": 0
  },
  "cases": [
    {
      "caseId": "1",
      "verdict": "needs_review",
      "goal": "...",
      "evidencePaths": ["..."]
    }
  ],
  "reportPath": "/tmp/ios_perf-opt/ios-case-runner/.../report.json",
  "resultPath": "/tmp/ios_perf-opt/ios-case-runner/.../result.json"
}
```

只有当每条执行的 case 都 pass 时 `success` 才为 true。逐条产物位于
`<outputDir>/cases/<case_id>/`，转发的实验 run 写入
`<outputDir>/cases/<case_id>/experiment/`。

## 命令

仅规划冒烟（不碰设备）：

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input '{"case":{"case_id":1,"title":"预览页显示标记入口","step":"...","expected":"..."},"planOnly":true}'
```

真机单条（需 App 空闲并显式授权）：

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input '{"case":{ ... },"planOnly":false}'
```

从文件读 caseset：

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input-file cases.json
```
