import type {
  IosUiGraphNavigatorFailureResult,
  IosUiGraphNavigatorResult,
} from "../ios-ui-graph-navigator/types";

/**
 * The two result variants returned by the step-wise UI Graph navigator.
 */
export type NavigatorHandlerResult =
  IosUiGraphNavigatorResult | IosUiGraphNavigatorFailureResult;

/**
 * A structured, human-authored iOS test case.
 *
 * @remarks
 * The field names deliberately mirror the source case table
 * (`case_id`, `precondition`, `step`, `expected`) so an existing caseset can be
 * fed in verbatim. `case_id` accepts a string or a number; historically numeric
 * ids have been silently required elsewhere, so both forms are normalized.
 */
export interface StructuredCase {
  /** Stable identifier; accepts a string or number and is normalized to text. */
  readonly case_id: string | number;
  /** Reader-facing case title. */
  readonly title: string;
  /** Optional priority label such as `P0`. */
  readonly priority?: string;
  /** Optional tags such as `E2E_AUTO`. */
  readonly tags?: readonly string[];
  /** Optional breadcrumb path describing where the case lives. */
  readonly path?: readonly string[];
  /** Optional precondition prose, including cold-start recovery expectations. */
  readonly precondition?: string;
  /** Required step prose describing the actions to perform. */
  readonly step: string;
  /** Required expected-result prose describing the pass criteria. */
  readonly expected: string;
}

/**
 * Input for the iOS case-runner Workflow.
 *
 * @remarks
 * Exactly one case source is expected in priority order: `case`, then `cases`,
 * then `caseSetPath`. Device and graph fields are forwarded to the reused
 * experiment handler unchanged.
 */
export interface IosCaseRunnerInput {
  /** A single structured case. */
  readonly case?: StructuredCase;
  /** An inline array of structured cases. */
  readonly cases?: readonly StructuredCase[];
  /**
   * Absolute or relative path to a JSON caseset. The file may be a bare array
   * of cases or an object exposing a `cases` array.
   */
  readonly caseSetPath?: string;
  /** Optional tag allowlist; a case runs when it carries any listed tag. */
  readonly filterTags?: readonly string[];
  /** Optional case-id allowlist; string or numeric ids are compared as text. */
  readonly filterCaseIds?: readonly (string | number)[];
  /** Target device UDID; forwarded to the experiment handler. */
  readonly udid?: string;
  /** Project root; forwarded to the experiment handler. */
  readonly projectRoot?: string;
  /** Graph path; forwarded to the experiment handler. */
  readonly graphPath?: string;
  /** Output directory root for this run's artifacts. */
  readonly outputDir?: string;
  /** Stable run identifier; a timestamp is generated when omitted. */
  readonly runId?: string;
  /** When true, only plan each case without executing on device. */
  readonly planOnly?: boolean;
  /**
   * When true (default), a case whose Graph capability is incomplete is retried
   * through the experiment handler's targeted-discovery path so the Graph can
   * evolve before a strict verdict is produced.
   */
  readonly allowDiscovery?: boolean;
  /** Optional model override; forwarded to the experiment handler. */
  readonly model?: string;
  /** Optional per-case agent timeout in milliseconds; forwarded unchanged. */
  readonly agentTimeoutMs?: number;
}

/**
 * Strict per-case verdict.
 *
 * @remarks
 * - `pass`: the compiled Oracles/assertions all held.
 * - `fail`: the path executed but the expected assertions did not hold.
 * - `needs_review`: the verifier was uncertain, or the Graph could not strictly
 *   prove the expected result even after discovery.
 * - `blocked`: an early failure (reset, preflight, or another pre-execution
 *   stage) prevented the case from executing.
 */
export type CaseVerdict = "pass" | "fail" | "needs_review" | "blocked";

/** Result of running a single structured case. */
export interface CaseRunResult {
  /** Normalized case id (always text). */
  readonly caseId: string;
  /** Reader-facing case title. */
  readonly title: string;
  /** Priority label when supplied. */
  readonly priority?: string;
  /** Tags when supplied. */
  readonly tags: readonly string[];
  /** Strict verdict. */
  readonly verdict: CaseVerdict;
  /** The deterministic semantic goal derived from the case. */
  readonly goal: string;
  /** ISO timestamp when the case started. */
  readonly startedAt: string;
  /** ISO timestamp when the case finished. */
  readonly finishedAt: string;
  /** Directory holding this case's runner-side artifacts. */
  readonly caseOutputDir: string;
  /** The mode of the reused experiment result, when one was produced. */
  readonly experimentMode?: "navigation" | "workflow_failure";
  /** Path to the reused experiment result JSON, when persisted. */
  readonly experimentResultPath?: string;
  /** Whether targeted discovery was triggered for this case. */
  readonly discoveryTriggered: boolean;
  /** Evidence artifact paths supporting the verdict. */
  readonly evidencePaths: readonly string[];
  /** Human-readable reason for the verdict. */
  readonly reason: string;
  /** Structured failure detail for `blocked`/`needs_review` cases. */
  readonly failure?: {
    readonly code: string;
    readonly stage: string;
    readonly message: string;
    readonly recoverable: boolean;
  };
}

/** Aggregate counts across all cases in a run. */
export interface CaseRunSummary {
  readonly total: number;
  readonly pass: number;
  readonly fail: number;
  readonly needsReview: number;
  readonly blocked: number;
}

/** Successful (well-formed) run result; `success` reflects the verdicts. */
export interface IosCaseRunnerResult {
  /** True only when every executed case passed. */
  readonly success: boolean;
  /** Discriminator distinguishing this from an early workflow failure. */
  readonly mode: "case_run";
  /** Whether the run was plan-only. */
  readonly planOnly: boolean;
  /** Stable run id. */
  readonly runId: string;
  /** Root output directory for this run. */
  readonly outputDir: string;
  /** Aggregate counts. */
  readonly summary: CaseRunSummary;
  /** Per-case results in input order. */
  readonly cases: readonly CaseRunResult[];
  /** Absolute path to the persisted aggregate report JSON. */
  readonly reportPath: string;
  /** Absolute path to the persisted result JSON. */
  readonly resultPath: string;
}

/**
 * Early or unexpected failure result.
 *
 * @remarks
 * Returned when the run cannot even begin (no case source, unreadable caseset,
 * empty selection). Mirrors the experiment handler's convention of returning a
 * structured JSON failure instead of throwing.
 */
export interface IosCaseRunnerFailureResult {
  readonly success: false;
  readonly mode: "workflow_failure";
  readonly planOnly: boolean;
  readonly runId: string;
  readonly outputDir: string;
  readonly resultPath: string;
  readonly failure: {
    readonly code: string;
    readonly stage: string;
    readonly message: string;
    readonly recoverable: boolean;
    readonly evidencePaths: readonly string[];
  };
}

/** Either variant returned by the case-runner handler. */
export type IosCaseRunnerOutput =
  IosCaseRunnerResult | IosCaseRunnerFailureResult;
