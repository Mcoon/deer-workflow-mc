# iOS Case Runner

[简体中文](./README.zh-CN.md)

This Workflow runs structured, human-authored iOS test cases on a real device
and emits a strict per-case verdict plus an aggregate report. It does not
reimplement device automation: each case is bridged to a semantic goal and run
through the live
[iOS UI Graph Navigator](../ios-ui-graph-navigator/) handler in-process.

## Why

The UI Graph experiment accepts a natural-language `goal`, but a structured
test case carries three distinct fields — `precondition`, `step`, and
`expected` — with real semantics. Flattening a whole case into one vague goal
loses step constraints (for example "tap the shutter to capture") and assertion
text (for example "the pencil mark entry is visible in the top-right"). This
runner preserves those three segments verbatim so the engine can execute the
real steps and verify the real expected outcome.

## Input

Provide exactly one case source, in priority order:

- `case` — a single structured case object.
- `cases` — an inline array of cases.
- `caseSetPath` — a JSON file that is either a bare array or `{ "cases": [] }`.

A structured case uses the source table field names:

```json
{
  "case_id": 1,
  "priority": "P0",
  "tags": ["P0", "E2E_AUTO"],
  "path": ["1. 入口与设置", "标记入口与Settings开关"],
  "title": "预览页显示标记入口",
  "precondition": "1. 起始页固定为对话页……",
  "step": "1. 从对话页点击左下角相机入口……",
  "expected": "1. 能从对话页正常进入相机页并完成单张拍摄……"
}
```

`case_id` accepts a string or a number and is normalized to text.

Optional fields:

- `filterTags` — run only cases carrying any listed tag.
- `filterCaseIds` — run only listed case ids (string or numeric).
- `udid`, `projectRoot`, `graphPath`, `model`, `agentTimeoutMs` — forwarded to
  the experiment handler unchanged.
- `outputDir`, `runId` — artifact location controls.
- `planOnly` — plan each case without touching the device.
- `allowDiscovery` — default `true`; when a case's Graph capability is
  incomplete, retry through the experiment's targeted-discovery path so the
  Graph can evolve before a strict verdict.

## Pipeline

`Load → Parse Cases → Run Cases → Aggregate → Report`

For each case:

1. **Case → semantic goal.** `title`, `step`, and `expected` are joined
   deterministically; `precondition` is appended as an explicit cold-start
   recovery hint. No prose is discarded.
2. **In-process execution.** The navigator perceives the live UI before every
   step, reuses known Scene/Element/Operator knowledge, and asks an Agent only
   when the next step is ambiguous or unknown.
3. **Verdict normalization.** The navigator result is mapped to a strict
   verdict:
   - `pass` — the compiled Oracles/assertions all held.
   - `fail` — the path executed but the expected assertions did not hold.
   - `needs_review` — the verifier was uncertain, the oracle was stale, or the
     Graph could not strictly prove the expected result.
   - `blocked` — an early failure (reset, preflight, or another pre-execution
     stage) prevented execution.
4. **Graph evolution.** When `allowDiscovery` is on, successful live evidence
   can add candidate Scenes, Elements, and Operators and can update known
   Operator execution trust.

## Result

Every run returns a structured JSON result (business failures are never
thrown):

```json
{
  "success": false,
  "mode": "case_run",
  "planOnly": false,
  "runId": "...",
  "outputDir": "/tmp/ios_perf-opt/ios-case-runner/...",
  "summary": {
    "total": 1,
    "pass": 0,
    "fail": 0,
    "needsReview": 1,
    "blocked": 0
  },
  "cases": [
    {
      "caseId": "1",
      "verdict": "needs_review",
      "goal": "...",
      "evidencePaths": ["..."]
    }
  ],
  "reportPath": "/tmp/ios_perf-opt/ios-case-runner/.../report.json",
  "resultPath": "/tmp/ios_perf-opt/ios-case-runner/.../result.json"
}
```

`success` is true only when every executed case passed. Per-case artifacts live
under `<outputDir>/cases/<case_id>/`, and the forwarded experiment run writes
into `<outputDir>/cases/<case_id>/experiment/`.

## Commands

Plan-only smoke (no device):

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input '{"case":{"case_id":1,"title":"预览页显示标记入口","step":"...","expected":"..."},"planOnly":true}'
```

Single case on device (requires an idle app and explicit authorization):

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input '{"case":{ ... },"planOnly":false}'
```

Caseset from a file:

```bash
deer-workflow run examples/ios-case-runner/workflow.ts \
  --input-file cases.json
```
