import { describe, expect, test } from "bun:test";

import {
  buildUnifiedUiGraph,
  renderNavigationMapHtml,
} from "../../examples/ios-ui-map-report/workflow";

import type {
  NavigationGraph,
  PageIndex,
  UiControl,
} from "../../examples/ios-regression-kit/types";

describe("iOS UI Map report", () => {
  test("renders a self-contained searchable graph without unsafe HTML", () => {
    const graph: NavigationGraph = {
      schemaVersion: "ios-ui-navigation-graph/v1",
      bundleId: "com.bot.<doubao>",
      generatedAt: "2026-08-13T00:00:00.000Z",
      rootPageId: "cold_start",
      defaultStartPageId: "chat",
      nodes: [
        {
          pageId: "cold_start",
          title: "冷启动",
          aliases: ["cold"],
          status: "active",
          anchorControlIds: [],
          controlIds: [],
          variants: {},
        },
        {
          pageId: "chat",
          title: "<script>alert(1)</script>",
          aliases: ["会话页"],
          status: "active",
          anchorControlIds: [],
          controlIds: [],
          variants: {},
        },
      ],
      edges: [],
    };
    const control: UiControl = {
      schemaVersion: "ios-ui-control/v1",
      controlId: "chat.more",
      pageId: "chat",
      title: "更多",
      role: "Button",
      selector: { accessibilityId: "更多" },
      bindings: [],
      updatedAt: graph.generatedAt,
    };
    const messageText: UiControl = {
      schemaVersion: "ios-ui-control/v1",
      controlId: "chat.00-09",
      pageId: "chat",
      title: "00:09",
      role: "StaticText",
      selector: { accessibilityId: "00:09" },
      bindings: [],
      updatedAt: graph.generatedAt,
    };
    const index: PageIndex = {
      schemaVersion: "ios-ui-page-index/v1",
      bundleId: graph.bundleId,
      generatedAt: graph.generatedAt,
      pages: [
        {
          pageId: "chat",
          title: "<script>alert(1)</script>",
          aliases: ["会话页"],
          status: "active",
        },
      ],
    };
    const unifiedGraph = buildUnifiedUiGraph({
      graph,
      controls: [control, messageText],
    });
    expect(
      unifiedGraph.nodes.some((node) => node.id === "control:chat.more"),
    ).toBe(true);
    expect(
      unifiedGraph.nodes.some((node) => node.id === "control:chat.00-09"),
    ).toBe(false);
    const html = renderNavigationMapHtml(graph, index, unifiedGraph);
    expect(html).toContain("iOS UI Navigation Map");
    expect(html).toContain('id="graph-data"');
    expect(html).toContain('id="unified-graph-data"');
    expect(html).toContain('id="page-index-data"');
    expect(html).toContain("搜索 pageId / controlId / 标题");
    expect(html).toContain("统一图详情");
    expect(html).toContain("control:chat.more");
    expect(html).toContain("outcome:chat.more:unexplored");
    expect(html).not.toContain("control:chat.00-09");
    expect(html).toContain("cursor:pointer");
    expect(html).toContain("function closestNodeElement(target)");
    expect(html).toContain("nodeAtPoint(event.clientX,event.clientY)");
    expect(html).toContain("selectNode(node.dataset.nodeId)");
    expect(html).not.toContain("<script>alert(1)</script>");
    expect(html).toContain("\\u003cscript");

    const scripts = Array.from(
      html.matchAll(/<script(?: [^>]*)?>([\s\S]*?)<\/script>/g),
      (match) => match[1] ?? "",
    );
    expect(scripts).toHaveLength(4);
    expect(() => new Function(scripts.at(-1) ?? "")).not.toThrow();
  });
});
