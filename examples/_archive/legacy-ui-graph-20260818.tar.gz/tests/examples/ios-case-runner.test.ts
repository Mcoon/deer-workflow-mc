import { mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, beforeEach, describe, expect, test } from "bun:test";

import {
  aggregateSummary,
  buildCaseGoal,
  loadCases,
  meta,
  normalizeCaseId,
  normalizeCaseResult,
  parseCaseSet,
  runIosCaseRunner,
  selectCases,
} from "../../examples/ios-case-runner/workflow";

import type { NavigatorRunner } from "../../examples/ios-case-runner/workflow";
import type {
  CaseRunResult,
  StructuredCase,
} from "../../examples/ios-case-runner/types";
import type {
  IosUiGraphNavigatorFailureResult,
  IosUiGraphNavigatorResult,
} from "../../examples/ios-ui-graph-navigator/types";

const cameraCase: StructuredCase = {
  case_id: 1,
  priority: "P0",
  tags: ["P0", "E2E_AUTO"],
  title: "预览页显示标记入口",
  precondition: "起始页固定为对话页，可看到左下角相机入口。",
  step: "点击左下角相机入口，点击快门拍摄一张照片。",
  expected: "预览页右上角清晰可见铅笔形状的标记入口图标。",
};

function navigatorResult(
  overrides: Partial<IosUiGraphNavigatorResult> = {},
): IosUiGraphNavigatorResult {
  return {
    success: true,
    mode: "navigation",
    planOnly: false,
    status: "pass",
    runId: "run",
    outputDir: "/tmp/x",
    graphPath: "/tmp/graph.json",
    resultPath: "/tmp/x/result.json",
    reportPath: "/tmp/x/report.json",
    goal: "g",
    stepsUsed: 0,
    steps: [],
    observations: [],
    actions: [],
    commands: [],
    completionEvidence: [],
    evidencePaths: ["/tmp/x/result.json"],
    ...overrides,
  };
}

function workflowFailure(
  overrides: Partial<IosUiGraphNavigatorFailureResult> = {},
): IosUiGraphNavigatorFailureResult {
  return {
    success: false,
    mode: "workflow_failure",
    planOnly: false,
    runId: "run",
    outputDir: "/tmp/x",
    graphPath: "/tmp/graph.json",
    resultPath: "/tmp/x/result.json",
    goal: "g",
    failure: {
      code: "reset_failed",
      stage: "Reset",
      message: "device reset failed",
      recoverable: true,
      evidencePaths: ["/tmp/x/reset.json"],
    },
    ...overrides,
  };
}

function normalize(
  result: IosUiGraphNavigatorResult | IosUiGraphNavigatorFailureResult,
): CaseRunResult {
  return normalizeCaseResult({
    caseId: "1",
    structuredCase: cameraCase,
    goal: "g",
    startedAt: new Date().toISOString(),
    caseOutputDir: "/tmp/x/cases/1",
    navigatorResult: result,
  });
}

describe("iOS Case Runner workflow", () => {
  test("declares the case-run phases", () => {
    expect(meta.name).toBe("ios-case-runner");
    expect(meta.phases.map((phase) => phase.title)).toEqual([
      "Load",
      "Parse Cases",
      "Run Cases",
      "Aggregate",
      "Report",
    ]);
  });

  test("normalizes numeric and string case ids to text", () => {
    expect(normalizeCaseId(1)).toBe("1");
    expect(normalizeCaseId(" abc ")).toBe("abc");
  });

  test("builds a goal that preserves step and expected prose", () => {
    const goal = buildCaseGoal(cameraCase);
    expect(goal).toContain("点击快门拍摄");
    expect(goal).toContain("右上角清晰可见铅笔形状的标记入口");
    expect(goal).toContain("前置条件");
    expect(goal).toContain("执行步骤");
    expect(goal).toContain("预期结果");
  });

  test("parses caseset arrays and { cases } objects", () => {
    expect(parseCaseSet([cameraCase])).toHaveLength(1);
    expect(parseCaseSet({ cases: [cameraCase] })).toHaveLength(1);
    expect(() => parseCaseSet({ nope: true })).toThrow();
  });

  test("loadCases honors priority: case over cases over path", async () => {
    const other: StructuredCase = { ...cameraCase, case_id: 2 };
    expect(await loadCases({ case: cameraCase, cases: [other] })).toEqual([
      cameraCase,
    ]);
    expect(await loadCases({ cases: [other] })).toEqual([other]);
    expect(await loadCases({})).toEqual([]);
  });

  test("selects cases by tag and id allowlists", () => {
    const cases: StructuredCase[] = [
      cameraCase,
      { ...cameraCase, case_id: 2, tags: ["P1"] },
    ];
    expect(
      selectCases(cases, {
        tags: new Set(["E2E_AUTO"]),
        caseIds: new Set(),
      }).map((item) => item.case_id),
    ).toEqual([1]);
    expect(
      selectCases(cases, {
        tags: new Set(),
        caseIds: new Set(["2"]),
      }).map((item) => item.case_id),
    ).toEqual([2]);
  });

  test("verdict: passing navigator maps to pass", () => {
    const result = normalize(navigatorResult());
    expect(result.verdict).toBe("pass");
  });

  test("verdict: failed navigator maps to fail", () => {
    const result = normalize(
      navigatorResult({
        success: false,
        status: "fail",
      }),
    );
    expect(result.verdict).toBe("fail");
  });

  test("verdict: uncertain navigator maps to needs_review", () => {
    const result = normalize(
      navigatorResult({
        success: false,
        status: "needs_review",
      }),
    );
    expect(result.verdict).toBe("needs_review");
  });

  test("verdict: plan-only maps to needs_review", () => {
    const result = normalize(
      navigatorResult({
        success: false,
        planOnly: true,
        status: "needs_review",
      }),
    );
    expect(result.verdict).toBe("needs_review");
  });

  test("verdict: early workflow failure maps to blocked", () => {
    const result = normalize(workflowFailure());
    expect(result.verdict).toBe("blocked");
    expect(result.failure?.code).toBe("reset_failed");
  });

  test("records live candidate actions as discovery", () => {
    const result = normalize(
      navigatorResult({
        actions: [{} as IosUiGraphNavigatorResult["actions"][number]],
      }),
    );
    expect(result.discoveryTriggered).toBe(true);
  });

  test("aggregates verdict counts", () => {
    const summary = aggregateSummary([
      { verdict: "pass" } as CaseRunResult,
      { verdict: "fail" } as CaseRunResult,
      { verdict: "needs_review" } as CaseRunResult,
      { verdict: "blocked" } as CaseRunResult,
      { verdict: "pass" } as CaseRunResult,
    ]);
    expect(summary).toEqual({
      total: 5,
      pass: 2,
      fail: 1,
      needsReview: 1,
      blocked: 1,
    });
  });
});

describe("iOS Case Runner end-to-end (fake navigator handler)", () => {
  let outputDir: string;

  beforeEach(async () => {
    outputDir = await mkdtemp(join(tmpdir(), "ios-case-runner-test-"));
  });

  afterEach(async () => {
    await rm(outputDir, { recursive: true, force: true });
  });

  test("runs a caseset and aggregates a success result", async () => {
    const fake: NavigatorRunner = async () => navigatorResult();
    const result = await runIosCaseRunner(
      {
        cases: [cameraCase, { ...cameraCase, case_id: 2 }],
        outputDir,
      },
      fake,
    );
    expect(result.mode).toBe("case_run");
    if (result.mode !== "case_run") return;
    expect(result.success).toBe(true);
    expect(result.summary).toEqual({
      total: 2,
      pass: 2,
      fail: 0,
      needsReview: 0,
      blocked: 0,
    });
    // The aggregate report and result are persisted as JSON.
    const report = JSON.parse(await readFile(result.reportPath, "utf8"));
    expect(report.schemaVersion).toBe("ios-case-runner-report/v1");
    const persisted = JSON.parse(await readFile(result.resultPath, "utf8"));
    expect(persisted.summary.pass).toBe(2);
  });

  test("returns a structured failure when no case source is supplied", async () => {
    const fake: NavigatorRunner = async () => navigatorResult();
    const result = await runIosCaseRunner({ outputDir }, fake);
    expect(result.success).toBe(false);
    expect(result.mode).toBe("workflow_failure");
    if (result.mode !== "workflow_failure") return;
    expect(result.failure.code).toBe("no_cases_selected");
    // A JSON result is written even on failure.
    const persisted = JSON.parse(await readFile(result.resultPath, "utf8"));
    expect(persisted.failure.code).toBe("no_cases_selected");
  });

  test("reads a caseset from a JSON file path", async () => {
    const caseSetPath = join(outputDir, "cases.json");
    await writeFile(
      caseSetPath,
      JSON.stringify({ cases: [cameraCase] }),
      "utf8",
    );
    const fake: NavigatorRunner = async () => navigatorResult();
    const result = await runIosCaseRunner({ caseSetPath, outputDir }, fake);
    expect(result.mode).toBe("case_run");
    if (result.mode !== "case_run") return;
    expect(result.summary.total).toBe(1);
  });

  test("a case whose handler throws is recorded as blocked, not aborting the run", async () => {
    let call = 0;
    const fake: NavigatorRunner = async () => {
      call += 1;
      if (call === 1) {
        throw new Error("boom");
      }
      return navigatorResult();
    };
    const result = await runIosCaseRunner(
      {
        cases: [cameraCase, { ...cameraCase, case_id: 2 }],
        outputDir,
      },
      fake,
    );
    expect(result.mode).toBe("case_run");
    if (result.mode !== "case_run") return;
    expect(result.summary.blocked).toBe(1);
    expect(result.summary.pass).toBe(1);
  });
});
