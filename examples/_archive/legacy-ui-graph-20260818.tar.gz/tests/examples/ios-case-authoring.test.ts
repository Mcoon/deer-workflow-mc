import { describe, expect, test } from "bun:test";

import {
  buildExtractFramesCommand,
  meta,
  regressionCaseSetSchema,
} from "../../examples/ios-case-authoring/workflow";

describe("iOS Case Authoring workflow", () => {
  test("uses Agent authoring between deterministic extraction and validation", () => {
    expect(meta.name).toBe("ios-case-authoring");
    expect(meta.phases.map((phase) => phase.title)).toEqual([
      "Prepare",
      "Extract",
      "Author",
      "Validate",
      "Review",
    ]);
    expect(regressionCaseSetSchema).toEqual(
      expect.objectContaining({
        type: "object",
        additionalProperties: false,
      }),
    );
  });

  test("extracts a bounded number of frames with ffmpeg", () => {
    expect(
      buildExtractFramesCommand({
        recordingPath: "/tmp/demo.mp4",
        outputPattern: "/tmp/frames/frame-%03d.jpg",
        intervalSeconds: 2,
        maxFrames: 24,
      }),
    ).toEqual([
      "ffmpeg",
      "-hide_banner",
      "-loglevel",
      "error",
      "-i",
      "/tmp/demo.mp4",
      "-vf",
      "fps=1/2",
      "-frames:v",
      "24",
      "-q:v",
      "2",
      "/tmp/frames/frame-%03d.jpg",
    ]);
  });
});
