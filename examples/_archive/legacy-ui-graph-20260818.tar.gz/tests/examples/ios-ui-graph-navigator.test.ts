import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { describe, expect, test } from "bun:test";

import {
  buildRelevantOperatorCards,
  buildSceneCandidates,
  chooseDeterministicOperator,
  meta,
  navigatorStatusFromVerifier,
  nextActionFailureState,
  normalizeNavigatorDecision,
  runIosUiGraphNavigator,
  shouldPersistLearning,
} from "../../examples/ios-ui-graph-navigator/workflow";

import type {
  ExecutableUiGraphExperiment,
  TargetedDiscoveryObservation,
} from "../../examples/ios-ui-graph-experiment/types";

const graph: ExecutableUiGraphExperiment = {
  schemaVersion: "ios-executable-ui-graph-experiment/v1",
  graphId: "test",
  bundleId: "com.test",
  appName: "Test",
  deviceProfiles: [
    {
      profileId: "phone",
      viewportWidth: 400,
      viewportHeight: 800,
    },
  ],
  defaultDeviceProfileId: "phone",
  defaultResetStrategyId: "reset",
  resetStrategies: [
    {
      strategyId: "reset",
      entrySceneId: "chat.detail",
      steps: [],
    },
  ],
  scenes: [
    {
      sceneId: "chat.detail",
      title: "会话页",
      aliases: ["聊天"],
      status: "verified",
      anchorElementIds: ["chat.camera"],
      visualTextAnchors: ["发消息或按住说话"],
      referenceAssets: [],
    },
    {
      sceneId: "camera.photo_preview",
      title: "相机预览页",
      aliases: ["拍照后预览"],
      status: "verified",
      anchorElementIds: ["camera.mark"],
      visualTextAnchors: ["裁剪", "下载"],
      referenceAssets: [],
    },
  ],
  elements: [
    {
      elementId: "chat.camera",
      sceneId: "chat.detail",
      title: "相机",
      semanticRole: "camera_entry",
      selector: {
        accessibilityId: "btn:ic_camera",
        label: "相机",
        role: "Button",
      },
      bindings: [],
    },
    {
      elementId: "camera.mark",
      sceneId: "camera.photo_preview",
      title: "标记",
      semanticRole: "mark_entry",
      selector: {
        accessibilityId: "btn:ugc_gallery_top_item_mark",
        label: "ugc gallery top item mark",
        role: "Button",
      },
      bindings: [],
    },
  ],
  operators: [
    {
      operatorId: "chat.open_camera",
      title: "打开相机",
      fromSceneId: "chat.detail",
      toSceneId: "camera.capture",
      operation: { type: "tap", elementId: "chat.camera" },
      settleMs: 900,
      risk: "navigation",
      status: "verified",
      reliability: 0.9,
      effects: [],
      postconditions: [],
    },
  ],
  tasks: [],
};

const chatObservation: TargetedDiscoveryObservation = {
  observationId: "observation-00",
  screenshotPath: "/tmp/chat.png",
  uiDumpPath: "/tmp/chat.json",
  ocrPath: "/tmp/chat-ocr.json",
  // Deliberately wrong, mirroring the real bug.
  matchedSceneId: "camera.photo_preview",
  candidateSceneId: "camera.photo_preview",
  candidateSceneTitle: "相机预览页",
  visualTextAnchors: ["发消息或按住说话"],
  candidates: [
    {
      candidateId: "ui-camera",
      source: "ui_dump",
      role: "Button",
      accessibilityId: "btn:ic_camera",
      label: "相机",
      bounds: { x: 10, y: 700, width: 44, height: 44 },
    },
    {
      candidateId: "ocr-composer",
      source: "vision_ocr",
      role: "TextObservation",
      text: "发消息或按住说话.",
      bounds: { x: 60, y: 700, width: 200, height: 30 },
    },
  ],
};

describe("iOS UI Graph Navigator", () => {
  test("declares the live loop phases", () => {
    expect(meta.name).toBe("ios-ui-graph-navigator");
    expect(meta.phases.map((phase) => phase.title)).toEqual([
      "Load",
      "Preflight",
      "Reset",
      "Perceive",
      "Plan",
      "Act",
      "Verify",
      "Learn",
      "Report",
    ]);
  });

  test("ranks the real element-backed Scene above a wrong deterministic hint", () => {
    const candidates = buildSceneCandidates(graph, chatObservation);
    expect(candidates[0]?.sceneId).toBe("chat.detail");
    expect(
      candidates.find((candidate) => candidate.sceneId === "chat.detail")
        ?.score,
    ).toBeGreaterThan(
      candidates.find(
        (candidate) => candidate.sceneId === "camera.photo_preview",
      )?.score ?? 0,
    );
  });

  test("offers only Operators relevant to current live Scenes or elements", () => {
    const cards = buildRelevantOperatorCards(graph, chatObservation, [
      "chat.detail",
    ]);
    expect(cards.map((card) => card.operatorId)).toEqual(["chat.open_camera"]);
    expect(cards[0]?.elementVisible).toBe(true);
  });

  test("uses the deterministic fast path for an unambiguous known camera entry", () => {
    const sceneCandidates = buildSceneCandidates(graph, chatObservation);
    const selected = chooseDeterministicOperator({
      graph,
      goal: "从对话页点击左下角相机入口进入相机页",
      observation: chatObservation,
      sceneCandidates,
      previousSteps: [],
    });
    expect(selected?.perception).toMatchObject({
      sceneId: "chat.detail",
      source: "deterministic",
      agentUsed: false,
    });
    expect(selected?.plan).toMatchObject({
      kind: "known_operator",
      operatorId: "chat.open_camera",
      agentUsed: false,
    });
  });

  test("allows Agent perception to correct the wrong Scene and choose a real Operator", () => {
    const sceneCandidates = buildSceneCandidates(graph, chatObservation);
    const operatorCards = buildRelevantOperatorCards(
      graph,
      chatObservation,
      sceneCandidates.map((candidate) => candidate.sceneId),
    );
    const result = normalizeNavigatorDecision({
      graph,
      observation: chatObservation,
      sceneCandidates,
      operatorCards,
      decision: {
        sceneId: "chat.detail",
        sceneConfidence: 0.98,
        decision: "operator",
        operatorId: "chat.open_camera",
        candidateId: "",
        actionType: "tap",
        inputValue: "",
        durationMs: 800,
        targetElementTitle: "相机",
        targetSemanticRole: "camera_entry",
        operatorTitle: "打开相机",
        risk: "navigation",
        expectedOutcome: "进入相机拍摄页",
        expectedSceneTitle: "相机拍摄页",
        visualTextAnchors: [],
        completionEvidence: [],
        completionOracleType: "none",
        completionOracleValue: "",
        reason: "相机入口真实可见。",
      },
    });
    expect(result.perception.sceneId).toBe("chat.detail");
    expect(result.perception.source).toBe("agent");
    expect(result.plan).toMatchObject({
      kind: "known_operator",
      operatorId: "chat.open_camera",
    });
  });

  test("rejects an invented candidate id", () => {
    const sceneCandidates = buildSceneCandidates(graph, chatObservation);
    const result = normalizeNavigatorDecision({
      graph,
      observation: chatObservation,
      sceneCandidates,
      operatorCards: [],
      decision: {
        sceneId: "chat.detail",
        sceneConfidence: 0.95,
        decision: "candidate",
        operatorId: "",
        candidateId: "ui-does-not-exist",
        actionType: "tap",
        inputValue: "",
        durationMs: 800,
        targetElementTitle: "不存在",
        targetSemanticRole: "unknown",
        operatorTitle: "tap",
        risk: "interaction",
        expectedOutcome: "unknown",
        expectedSceneTitle: "unknown",
        visualTextAnchors: [],
        completionEvidence: [],
        completionOracleType: "none",
        completionOracleValue: "",
        reason: "invented",
      },
    });
    expect(result.plan.kind).toBe("blocked");
  });

  test("requires an executable oracle before accepting Agent completion", () => {
    const sceneCandidates = buildSceneCandidates(graph, chatObservation);
    const result = normalizeNavigatorDecision({
      graph,
      observation: chatObservation,
      sceneCandidates,
      operatorCards: [],
      decision: {
        sceneId: "chat.detail",
        sceneConfidence: 0.9,
        decision: "complete",
        operatorId: "",
        candidateId: "",
        actionType: "tap",
        inputValue: "",
        durationMs: 800,
        targetElementTitle: "",
        targetSemanticRole: "",
        operatorTitle: "",
        risk: "interaction",
        expectedOutcome: "",
        expectedSceneTitle: "",
        visualTextAnchors: [],
        completionEvidence: [],
        completionOracleType: "none",
        completionOracleValue: "",
        reason: "done",
      },
    });
    expect(result.plan).toMatchObject({
      kind: "blocked",
      reason: "Agent completion did not include an executable oracle.",
    });
  });

  test("maps verifier outcomes to stable navigator verdicts", () => {
    expect(navigatorStatusFromVerifier("pass")).toBe("pass");
    expect(navigatorStatusFromVerifier("oracle_stale")).toBe("pass");
    expect(navigatorStatusFromVerifier("path_failed")).toBe("fail");
    expect(navigatorStatusFromVerifier("uncertain")).toBe("needs_review");
    expect(
      navigatorStatusFromVerifier(
        "evidence_insufficient",
        "Two consecutive actions failed",
      ),
    ).toBe("blocked");
  });

  test("allows one failed action to re-perceive and blocks the second consecutive failure", () => {
    expect(nextActionFailureState(0, 1)).toEqual({
      consecutiveFailures: 1,
      canRecover: true,
    });
    expect(nextActionFailureState(1, 1)).toEqual({
      consecutiveFailures: 2,
      canRecover: false,
    });
    expect(nextActionFailureState(1, 0)).toEqual({
      consecutiveFailures: 0,
      canRecover: true,
    });
  });

  test("persists reusable knowledge only for proven passing evidence", () => {
    expect(
      shouldPersistLearning({
        status: "pass",
        allowLearning: true,
        hasEvidence: true,
      }),
    ).toBe(true);
    expect(
      shouldPersistLearning({
        status: "needs_review",
        allowLearning: true,
        hasEvidence: true,
      }),
    ).toBe(false);
    expect(
      shouldPersistLearning({
        status: "pass",
        allowLearning: false,
        hasEvidence: true,
      }),
    ).toBe(false);
  });

  test("returns and persists structured JSON when Graph loading fails", async () => {
    const outputDir = await mkdtemp(
      join(tmpdir(), "ios-ui-graph-navigator-failure-"),
    );
    try {
      const result = await runIosUiGraphNavigator({
        goal: "打开相机",
        graphPath: join(outputDir, "missing-graph.json"),
        outputDir,
        planOnly: true,
      });
      expect(result).toMatchObject({
        success: false,
        mode: "workflow_failure",
        failure: {
          code: "load_failed",
          stage: "Load",
          recoverable: false,
        },
      });
      const persisted = JSON.parse(
        await readFile(join(outputDir, "result.json"), "utf8"),
      );
      expect(persisted).toEqual(result);
    } finally {
      await rm(outputDir, { recursive: true, force: true });
    }
  });
});
