import { describe, expect, test } from "bun:test";

import {
  autoDiscoverControls,
  deriveCoordinateViewport,
  inferCoordinateViewportFromScreenshot,
  isTransitionTrigger,
  meta,
  parseDeviceInfoViewport,
} from "../../examples/ios-ui-discovery/workflow";

describe("iOS UI Discovery workflow", () => {
  test("declares deterministic mobilecli discovery phases", () => {
    expect(meta.name).toBe("ios-ui-discovery");
    expect(meta.phases.map((phase) => phase.title)).toEqual([
      "Prepare",
      "Preflight",
      "Explore",
      "Persist",
      "Report",
    ]);
  });

  test("creates stable auto controls from accessibility IDs", () => {
    const controls = autoDiscoverControls({
      pageId: "chat",
      profile: {
        schemaVersion: "ios-device-profile/v1",
        profileId: "iphone-test",
        platform: "ios",
        viewportWidth: 390,
        viewportHeight: 844,
        coordinateSpace: "mobilecli",
        orientation: "portrait",
        updatedAt: "2026-08-12T00:00:00.000Z",
      },
      observedAt: "2026-08-12T00:00:00.000Z",
      elements: [
        {
          role: "XCUIElementTypeButton",
          accessibilityId: "chat.send",
          label: "发送",
          bounds: { x: 340, y: 760, width: 42, height: 42 },
        },
      ],
    });

    expect(controls).toEqual([
      expect.objectContaining({
        controlId: "chat.chat.send",
        pageId: "chat",
        selector: { accessibilityId: "chat.send" },
        bindings: [
          expect.objectContaining({
            deviceProfileId: "iphone-test",
            normalizedPoint: {
              x: 361 / 390,
              y: 781 / 844,
            },
          }),
        ],
      }),
    ]);
  });

  test("derives the interaction viewport from the UI root instead of PNG pixels", () => {
    expect(
      deriveCoordinateViewport([
        {
          role: "XCUIElementTypeApplication",
          bounds: { x: 0, y: 0, width: 390, height: 844 },
        },
        {
          role: "XCUIElementTypeButton",
          bounds: { x: 340, y: 760, width: 42, height: 42 },
        },
      ]),
    ).toEqual({ width: 390, height: 844 });
  });

  test("reads a logical viewport from mobilecli device info", () => {
    expect(
      parseDeviceInfoViewport(
        JSON.stringify({
          status: "ok",
          data: { screen: { width: 414, height: 896 } },
        }),
      ),
    ).toEqual({ width: 414, height: 896 });
    expect(parseDeviceInfoViewport("Screen Size: 414x896")).toEqual({
      width: 414,
      height: 896,
    });
  });

  test("infers a 2x iOS logical viewport when the dump omits a root node", () => {
    expect(
      inferCoordinateViewportFromScreenshot({ width: 828, height: 1792 }, [
        {
          role: "Icon",
          bounds: { x: 30, y: 798, width: 68, height: 68 },
        },
        {
          role: "Icon",
          bounds: { x: 316, y: 798, width: 68, height: 68 },
        },
        {
          role: "SearchField",
          bounds: { x: 441, y: 70, width: 360, height: 48 },
        },
        {
          role: "StaticText",
          bounds: { x: 20, y: 15, width: 46, height: 19 },
        },
        {
          role: "Image",
          bounds: { x: 187, y: 740, width: 11, height: 11 },
        },
      ]),
    ).toEqual({ width: 414, height: 896 });
  });

  test("keeps waits from replacing the action that triggered a transition", () => {
    expect(
      isTransitionTrigger({
        actionId: "tap-input",
        type: "tap",
        pageId: "chat_detail",
        target: { controlId: "chat_detail.message_input" },
      }),
    ).toBeTrue();
    expect(
      isTransitionTrigger({
        actionId: "wait-keyboard",
        type: "wait",
        durationMs: 800,
      }),
    ).toBeFalse();
  });
});
